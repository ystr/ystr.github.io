using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;

class ChanListView : ListView
{
	public event Action<string> ChannelInvoked = (c) => {};
	
	ColumnHeader nameCol = new ColumnHeader();
	ColumnHeader usersCol = new ColumnHeader();
	ColumnHeader topicCol = new ColumnHeader();
	
	void Localize ()
	{
		nameCol.Text = Own.Line("Channel");
		usersCol.Text = Own.Line("Users");
		topicCol.Text = Own.Line("Topic");
	}
	
	public ChanListView ()
	{
		DoubleBuffered = true;
		
		View = View.Details;
		AllowColumnReorder = false;
		FullRowSelect = true;
		MultiSelect = false;
		
		ListViewItemSorter = new NumColSorter(1);
		ColumnClick += (o, e) => SortByCol(e.Column);
		
		nameCol.Width = 128;
		usersCol.Width = 64;
		
		Columns.Add(nameCol);
		Columns.Add(usersCol);
		Columns.Add(topicCol);
		
		Own.LocaleChanged += Localize;
		Localize();
		
		Resize += (o, e) => FitCols();
		
		DoubleClick += (o, e) => InvokeChannel();
		KeyDown += (o, e) => { if (e.KeyCode == Keys.Enter) InvokeChannel(); };
		
		FitCols();
	}
	
	void InvokeChannel ()
	{
		if (SelectedItems.Count == 1)
		{
			ChannelInvoked(SelectedItems[0].Text);
		}
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
	
	void SortByCol (int colIndex)
	{
		if (colIndex == 1) ListViewItemSorter = new NumColSorter(colIndex);
		else ListViewItemSorter = new StrColSorter(colIndex);
		
		Sort();
	}
	
	void FitCols ()
	{
		topicCol.Width = ClientSize.Width - (usersCol.Width + nameCol.Width);
	}
	
	class ColSorter
	{
		public readonly int ColIndex;
		public ColSorter (int ci) { ColIndex = ci; }
	}
	
	class NumColSorter : ColSorter, IComparer
	{
		public NumColSorter (int ci) : base (ci) { }
		
		public int Compare (object o0, object o1)
		{
			int n0 = int.Parse((o0 as ListViewItem).SubItems[ColIndex].Text);
			int n1 = int.Parse((o1 as ListViewItem).SubItems[ColIndex].Text);
			
			if (n0 < n1) return +1;
			else if (n0 > n1) return -1;
			else return 0;
		}
	}
	
	class StrColSorter : ColSorter, IComparer
	{
		public StrColSorter (int ci) : base (ci) { }
		
		public int Compare (object o0, object o1)
		{
			string t0 = (o0 as ListViewItem).SubItems[ColIndex].Text;
			string t1 = (o1 as ListViewItem).SubItems[ColIndex].Text;
			
			return string.Compare(t0, t1);
		}
	}
}