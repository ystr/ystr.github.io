#include "Sys.h"

#include <tgmath.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "Sugar.c"
#include "Math.c"
#include "Noise.c"
#include "Rect.c"
#include "Color.c"
#include "Raster.c"
#include "Fx.c"
#include "Eye.c"
#include "Pos.c"
#include "Thing.c"
#include "Units.c"
#include "Cosmos.c"
#include "Hull.c"
#include "Cube.c"
#include "Sky.c"
#include "World.c"




#define TOY_NAME "1P"
#define TOY_START Terroid
#define TOY_MIN_ELEV 2
#define TOY_MIN_SPEED 5 KH
#define TOY_MOVE_SPEED 1
#define TOY_TURN_SPEED 1
#define TOY_START_NORM 1.5
#define TOY_ATLAS_SIDE 32
#define TOY_RES 256
#define TOY_RATE 60




typedef struct ACo3 ACo3;
typedef struct Feature Feature;
typedef struct Occurence Occurence;
typedef struct Atlas Atlas;

typedef void FeatureSampler (real* n, Rgb*, const Hull*, const Feature*, const Xyz*);

struct Feature { FeatureSampler* Sample; };
struct Occurence { const Feature* Feature; Occurence* Next; };
struct Atlas { Occurence* Grid[P3(TOY_ATLAS_SIDE)]; };
struct ACo3 { fs8 X, Y, Z; };

ACo3 ACoFromUp (const Xyz* up)
{
	return (ACo3) {
		floor((1 + up->X) * (TOY_ATLAS_SIDE / 2 - 1)),
		floor((1 + up->Y) * (TOY_ATLAS_SIDE / 2 - 1)),
		floor((1 + up->Z) * (TOY_ATLAS_SIDE / 2 - 1)),
	};
}

Occurence** AtlasRefCell (Atlas* a, fs8 x, fs8 y, fs8 z)
{
	return a->Grid + z * P2(TOY_ATLAS_SIDE) + y * TOY_ATLAS_SIDE + x;
}

void AtlasMapFeature (Atlas* a, const Feature* f, const Xyz* center, real radius)
{
	Xyz c0 = { center->X - radius, center->Y - radius, center->Z - radius };
	Xyz c1 = { center->X + radius, center->Y + radius, center->Z + radius };
	
	ACo3 aco0 = ACoFromUp(&c0);
	ACo3 aco1 = ACoFromUp(&c1);
	
	for (fs8 z = MAX(0, aco0.Z), z1 = MIN(aco1.Z, TOY_ATLAS_SIDE - 1); z <= z1; z++)
	for (fs8 y = MAX(0, aco0.Y), y1 = MIN(aco1.Y, TOY_ATLAS_SIDE - 1); y <= y1; y++)
	for (fs8 x = MAX(0, aco0.X), x1 = MIN(aco1.X, TOY_ATLAS_SIDE - 1); x <= x1; x++)
	{
		Occurence** cell = AtlasRefCell(a, x, y, z);
		Occurence* o = NEW(Occurence);
		o->Feature = f;
		o->Next = *cell;
		*cell = o;
	}
}

void AtlasSampleOccurence (real* n, Rgb* s, const Hull* p, const Occurence* o, const Xyz* v)
{
	if (!o) return;
	o->Feature->Sample(n, s, p, o->Feature, v);
	AtlasSampleOccurence(n, s, p, o->Next, v);
}

void AtlasSample (real* n, Rgb* s, const Atlas* a, const Hull* p, const Xyz* v)
{
	ACo3 aco = ACoFromUp(v);
	AtlasSampleOccurence(n, s, p, *AtlasRefCell((Atlas*)a, aco.X, aco.Y, aco.Z), v);
}

void InitAtlas (Atlas* a)
{
	memset(a->Grid, 0, sizeof(a->Grid));
}


typedef struct {
	
	Feature Feature;
	
	Xyz Center;
	
	real Radius;
	real Depth;

} Crater;

void SampleCrater (real* n, Rgb* s, const Hull* b, const Feature* f, const Xyz* up)
{
	const Crater* c = (Crater*) f;
	
	real outer2 = P2(c->Radius);
	real qis = Qis(c->Center, *up);
	if (qis > outer2) return;
	
	real inner2 = pow (
		c->Radius * (0.8 +
			0.1 * Noise3R(up->X * 200, up->Y * 200, up->Z * 200, b->Seed)
		),
	2 );
	
	real re = 0;
	
	if (qis < inner2) re = (2 * pow(qis / inner2, 2) - 1);
	else re = pow(1 - (qis - inner2) / (outer2 - inner2), 2);
	
	*n += re * c->Depth;
	
	fake rc = re * -0.25;
	
	s->R += rc;
	s->G += rc;
	s->B += rc;
}




real SampleJovoidGround (HTexel* ot, Xyz up, fu32 res, const void* w, const Hull* h)
{
	if (ot)
	{
		ot->R = (0.75 + Noise1R(up.Z * 11, h->Seed) * 0.1) * 0xFF;
		ot->G = (0.75 + Noise1R(up.Z * 55, h->Seed) * 0.1) * 0xFF;
		ot->B = (0.75 + Noise1R(up.Z * 99, h->Seed) * 0.1) * 0xFF;
		ot->A = 0xFF;
	}
	
	return h->Radius;
}

real SampleTerroidGround (HTexel* ot, Xyz up, fu32 res, const void* w, const Hull* h)
{
	real elv = 0;
	real m0 = 2 KM;
	real m1 = 1;
	
	for (fu32 d = 1; d <= res; d *= 2)
	{
		elv += Noise3R(up.X * d, up.Y * d, up.Z * d, h->Seed) * (m0 + m1);
		
		m0 *= 0.5;
		m1 *= d > 4096 ? 0.5 : 1.5;
	}
	
	if (ot)
	{
		if (elv < 0)
		{
			ot->R = 0;
			ot->G = 0x22 + 0x44 * (1 - Min(1, -elv * 0.01));
			ot->B = 0x88 + Max(elv * 0.001, -1) * 0x44;
		}
		else
		{
			real e0 = 0, e1 = 0, m0 = 1;
			
			for (fu32 de = 1; de <= res; de *= 2)
			{
				real v = Noise3R(up.X * de, up.Y * de, up.Z * de, h->Seed);
				e0 += v * m0, e1 += v, m0 *= 0.5;
			}
			
			fake r = 0.25 + e0 * 0.5 + e1 * 0.1;
			fake g = 0.2 + e0 * e1 * 0.5;
			fake b = 0.2 - r * g;
			
			ot->R = CLAMP(0, r, 1) * 0xFF;
			ot->G = CLAMP(0, g, 1) * 0xFF;
			ot->B = CLAMP(0, b, 1) * 0xFF;
		}
		
		ot->A = 0xFF;
	}
	
	return h->Radius + MAX(0, elv);
}

real SampleTerroidClouds (HTexel* ot, Xyz up, fu32 res, const void* w, const Hull* h)
{
	real a = 0;
	
	for (fu32 r = 1; r <= res; r *= 2)
	{
		a += Noise3R(up.X * r, up.Y * r, up.Z * r, h->Seed);
	}
	
	if (ot)
	{
		ot->A = Clamf(0, 0.5 + a * 0.5, 1) * 0xFF;
		
		ot->R = ot->A;
		ot->G = ot->A;
		ot->B = ot->A;
	}
	
	return h->Radius;
}

void PaintTerroid (HTexel* ot, Xyz u, Xyz p, Xyz n, const void* tag, const Hull* h)
{
	Rgb c = {0};
	const World* w = (World*) tag;
	
	for EACHC (const Lamp*, l, w->TestLiting->Lamps)
	{
		fake dir = Dot(n, l->Point);
		fake amb = Dot(u, n);
		
		if (dir < 0) dir = 0;
		if (amb < 0) amb = 0;
		
		fake zen = Dot(u, l->Point);
		fake tan = zen < 0.1 ? Weigf(0, zen, 0.1) : Weigf(1, zen, 0.1);
		
		if (zen < 0) zen = 0;
		if (tan < 0) tan = 0;
		
		fake zenDir = zen * dir;
		fake tanDir = tan * dir;
		fake zenAmb = zen * amb;
		fake tanAmb = tan * amb;
		
		fake zr = zenDir * h->ZenDir.R + tanDir * h->TanDir.R;
		fake zg = zenDir * h->ZenDir.G + tanDir * h->TanDir.G;
		fake zb = zenDir * h->ZenDir.B + tanDir * h->TanDir.B;
		
		fake ar = zenAmb * h->ZenAmb.R + tanAmb * h->TanAmb.R;
		fake ag = zenAmb * h->ZenAmb.G + tanAmb * h->TanAmb.G;
		fake ab = zenAmb * h->ZenAmb.B + tanAmb * h->TanAmb.B;
		
		c.R += l->Light.R * (zr + ar);
		c.G += l->Light.G * (zg + ag);
		c.B += l->Light.B * (zb + ab);
	}
	
	ot->R *= MIN(c.R, 1);
	ot->G *= MIN(c.G, 1);
	ot->B *= MIN(c.B, 1);
}

void ShadeTerroidGround (Syxel* o, Pixel* p, const Apex* a, const void* t)
{
	if (a->Z < p->Z) return;
	const HTexel* tp = HRefTexel(t, a->U, a->V);
	
	fu8 clear = 0xFF - a->W;
	
	o->R = M8(tp->R, clear) + (fu8) a->R;
	o->G = M8(tp->G, clear) + (fu8) a->G;
	o->B = M8(tp->B, clear) + (fu8) a->B;
	
	p->Z = a->Z;
}

void ShadeTerroidClouds (Syxel* o, Pixel* p, const Apex* a, const void* t)
{
	if (a->Z < p->Z) return;
	const HTexel* tp = HRefTexel(t, a->U, a->V);
	if (!tp->A) return;
	
	fu8 clear = 0xFF - a->W;
	fu8 trans = 0xFF - tp->A;
	
	o->R = M8(o->R, trans) + M8(tp->R, clear) + M8(a->R, tp->A);
	o->G = M8(o->G, trans) + M8(tp->G, clear) + M8(a->G, tp->A);
	o->B = M8(o->B, trans) + M8(tp->B, clear) + M8(a->B, tp->A);
}


typedef struct {
	
	World World;
	Atlas Atlas;
	
} Lunoid;

real SampleLunoidGround (HTexel* ot, Xyz up, fu32 res, const void* w, const Hull* h)
{
	real norm = h->Radius;
	Rgb c = {0};
	
	const Lunoid* l = (Lunoid*) w;
	AtlasSample(&norm, &c, &l->Atlas, h, &up);
	
	real rel = 0;
	real mul = 0.1;
	real rr0 = 0;
	
	for (fu32 r = res; r > 0; r /= 2)
	{
		real v = Noise3R(up.X * r, up.Y * r, up.Z * r, h->Seed);
		
		rr0 += Noise1R(v * r, h->Seed);
		rel += v;
		
		if (r > 128)
		{
			norm += v * mul;
			mul *= 2;
		}
	}
	
	if (ot)
	{
		fake sv = 0.6 + rel * 0.15;
		
		c.R += sv + rr0 * 0.03;
		c.G += sv + rr0 * 0.02;
		c.B += sv;
		
		c.R = CLAMP(0, c.R, 1);
		c.G = CLAMP(0, c.G, 1);
		c.B = CLAMP(0, c.B, 1);
		
		ot->R = c.R * 0xFF;
		ot->G = c.G * 0xFF;
		ot->B = c.B * 0xFF;
		ot->A = 0xFF;
	}
	
	return norm;
}

void PaintLunoid (HTexel* ot, Xyz u, Xyz p, Xyz n, const void* tag, const Hull* h)
{
	Rgb c = {0};
	const World* w = (World*) tag;
	
	for EACHC (const Lamp*, l, w->TestLiting->Lamps)
	{
		fake sph = Dot(u, l->Point);
		if (sph < 0) continue;
		
		c.R += l->Light.R * sph;
		c.G += l->Light.G * sph;
		c.B += l->Light.B * sph;
	}
	
	ot->R *= MIN(c.R, 1);
	ot->G *= MIN(c.G, 1);
	ot->B *= MIN(c.B, 1);
}

void MakeTestAtlas (Atlas* a, Hull* h)
{
	InitAtlas(a);
	
	Seed seq = h->Seed;
	
	for (uint i = 0; i < 100; i++)
	{
		Crater* c = NEW(Crater);
		
		c->Center = Spherand(1, &seq);
		c->Radius = 0.01 + 0.1 * R0R(RN(&seq));
		c->Depth = h->Radius * 0.05 * c->Radius;
		c->Feature.Sample = SampleCrater;
		
		AtlasMapFeature(a, &c->Feature, &c->Center, c->Radius);
	}
}


real SampleSoloid (HTexel* ot, Xyz up, fu32 res, const void* w, const Hull* h)
{
	if (ot) *ot = RGBA8(0xFF, 0xFF, 0xFF, 0xFF);
	return h->Radius;
}

void PaintSoloid (HTexel* ot, Xyz u, Xyz p, Xyz n, const void* w, const Hull* h)
{
	
}




struct {
	
	Eye Eye;
	fu16 Res;
	
	Cosmos Cosmos;
	
	World Soloid;
	World Terroid;
	World Jovoid;
	Lunoid Lunoid;
	
	Pov Pov;
	real MoveSpeed;
	
	Thing* Base;
	World* Start;
	
	Liting TestLiting;
	
} Toy = {
	
	.Res = TOY_RES,
	.Pov = IDENPOS,
	.MoveSpeed = 1,
	
	.Base = &Toy.Cosmos.Thing,
	.Start = &Toy.TOY_START,
	
	.TestLiting = {
		.Lamps = (Lamp[]) {
			{ .Light = { 1, 1, 1 }, .Point = { .Z = +1 } }
		}, .LampsCount = 1
	},
	
	.Soloid = {
		
		.Radius = 1 SR,
		.Thing.Pos.Loc.Z = 1 AU,
		.Emit = { 1, 1, 1 },
		.TestLiting = &(Liting) {0},
		
		.HullsCount = 1,
		.Hulls = (Hull[]) { {
				.Seed = 11111,
				.Radius = 1 SR,
				.MinDepth = 2,
				.MaxDepth = 25,
				.FogMul = 1E-8,
				.FogMax = 1,
				.Glow = { 1, 1, 1 },
				.ZenFog = { 1, 1, 1 }, .ZenDir = { 1, 1, 1 }, .ZenAmb = { 1, 1, 1 },
				.TanFog = { 1, 1, 1 }, .TanDir = { 1, 1, 1 }, .TanAmb = { 1, 1, 1 },
				.ShadeFront = ShadeTerroidGround,
				.Sample = SampleSoloid,
				.Paint = PaintSoloid,
			},
		},
		
		.Sky = &(Sky) {
			
			.Radius = 1 SR,
			.Height = 10000 KM,
			
			.ZenFog = { 1, 1, 1 },
			.TanFog = { 1, 1, 1 },
			
			.ZenOpacity = 1, .ZenScatter = 1,
			.TanOpacity = 1, .TanScatter = 1,
			
			.Glow = { 1, 1, 1 },
			.AirFilter = { 0, 0, 0 },
		},
	},
	
	.Terroid = {
		
		.Radius = 1 ER,
		.TestLiting = &Toy.TestLiting,
		.Albedo = { 0.5, 0.5, 1 },
		
		.HullsCount = 2,
		.Hulls = (Hull[]) { {
				.Seed = 12345,
				.Radius = 1 ER,
				.MinDepth = 2,
				.MaxDepth = 25,
				.FogMul = 1E-8,
				.FogMax = 1,
				.ZenFog = { 0, 0, 1 }, .ZenDir = { 1, 1, 1 }, .ZenAmb = { 0.25, 0.25, 0.5 },
				.TanFog = { 1, 0, 1 }, .TanDir = { 1, 0, 1 }, .TanAmb = { 0.25, 0, 0.25 },
				.ShadeFront = ShadeTerroidGround,
				.Sample = SampleTerroidGround,
				.Paint = PaintTerroid,
			}, {
				.Seed = 54321,
				.Radius = 1 ER + 3 KM,
				.MinCutoff = 200 KM,
				.MinDepth = 2,
				.MaxDepth = 25,
				.FogMul = 1E-9,
				.FogMax = 1,
				.ZenFog = { 0, 0, 1 }, .ZenDir = { 1, 1, 1 }, .ZenAmb = { 0, 0, 0 },
				.TanFog = { 1, 0, 1 }, .TanDir = { 1, 0, 1 }, .TanAmb = { 0.25, 0, 0.25 },
				.ShadeBack = ShadeTerroidClouds,
				.ShadeFront = ShadeTerroidClouds,
				.Sample = SampleTerroidClouds,
				.Paint = PaintTerroid,
			},
		},
		
		.Sky = &(Sky) {
			
			.Radius = 1 ER,
			.Height = 100 KM,
			
			.ZenFog = { 0, 0, 1 },
			.TanFog = { 0, 0, 0 },
			
			.TanOpacity = 1, .TanScatter = 1,
			.ZenOpacity = 0, .ZenScatter = 0.5,
			
			.AirFilter = { 1, 0, 0 },
		},
	},
	
	.Jovoid = {
		
		.Radius = 25362 KM,
		.Thing.Pos.Loc.Y = 88888 KM,
		.TestLiting = &Toy.TestLiting,
		.Albedo = { 0.5, 0.5, 0.5 },
		
		.HullsCount = 1,
		.Hulls = (Hull[]) { {
				.Seed = 56789,
				.Radius = 25362 KM,
				.MinDepth = 3,
				.MaxDepth = 25,
				.FogMul = 1E-8,
				.FogMax = 1,
				.ZenFog = { 0.8, 0.8, 0.8 }, .ZenDir = { 0, 0, 0 }, .ZenAmb = { 1, 1, 1 },
				.TanFog = { 0, 0, 0 }, .TanDir = { 0, 0, 0 }, .TanAmb = { 0, 0, 0 },
				.ShadeFront = ShadeTerroidGround,
				.Sample = SampleJovoidGround,
				.Paint = PaintTerroid,
			},
		},
		
		.Sky = &(Sky) {
			
			.Radius = 25362 KM,
			.Height = 200 KM,
			
			.ZenFog = { 0.8, 0.8, 0.8 },
			.TanFog = { 0, 0, 0 },
			
			.ZenOpacity = 1, .ZenScatter = 1,
			.TanOpacity = 1, .TanScatter = 1,
			
			.AirFilter = { 0, 0, 0 },
		},
	},
	
	.Lunoid = {
		.World = {
			
			.Radius = 6378 KM,
			.Thing.Pos.Loc.X = 55555 KM,
			.TestLiting = &Toy.TestLiting,
			.Albedo = { 0.5, 0.5, 0.5 },
			
			.HullsCount = 1,
			.Hulls = (Hull[]) { {
					.Seed = 98765,
					.Radius = 6378 KM,
					.ZenDir = { 1, 1, 1 }, .TanDir = { 1, 1, 1 },
					.MinDepth = 2,
					.MaxDepth = 25,
					.MinCutoff = 500 KM,
					.ShadeFront = ShadeTerroidGround,
					.Sample = SampleLunoidGround,
					.Paint = PaintLunoid,
				},
			},
		},
	},
};




void ToyMove (real x, real y, real z)
{
	Xyz rm = XyzRot((Xyz){x, y, z}, Toy.Pov.Rot);
	Toy.Pov.Loc = Add(Toy.Pov.Loc, rm);
}

void ToyTurn (real x, real y, real z)
{
	Rot tr = RotFromAxis((Xyz){x, y, z});
	Toy.Pov.Rot = NormRot(RotRot(Toy.Pov.Rot, tr));
}

void ToyZoom (real dz)
{
	EyeSetZoom(&Toy.Eye, Toy.Eye.Zoom * pow(2, dz));
}




int ToyOnStart (int argc, char** argv)
{
	InitEye(&Toy.Eye);
	
	InitFakeCosmos(&Toy.Cosmos, 0);
	
	MakeWorld(&Toy.Soloid);
	MakeWorld(&Toy.Jovoid);
	MakeWorld(&Toy.Terroid);
	MakeWorld(&Toy.Lunoid.World);
	
	MakeTestAtlas(&Toy.Lunoid.Atlas, Toy.Lunoid.World.Hulls + 0);
	
	ThingAddChild(&Toy.Cosmos.Thing, &Toy.Soloid.Thing);
	ThingAddChild(&Toy.Cosmos.Thing, &Toy.Jovoid.Thing);
	ThingAddChild(&Toy.Cosmos.Thing, &Toy.Terroid.Thing);
	ThingAddChild(&Toy.Cosmos.Thing, &Toy.Lunoid.World.Thing);
	
	Toy.Pov.Loc.Z = Toy.Start->Radius * TOY_START_NORM;
	
	return 0;
}

void ToyOnSize (int w, int h)
{
	int pw = w > h ? Toy.Res * w / h : Toy.Res;
	int ph = h > w ? Toy.Res * h / w : Toy.Res;
	
	Rect clip = Lbwh(-pw / 2, -ph / 2, pw, ph);
	SetEye(&Toy.Eye, &clip);
	SysSetResolution(pw, ph);
}

void ToyOnPaint (Syxel* raw, int bpr, double dt)
{
	real lowest = INFINITY;
	
	for (Thing* t = Toy.Base->Children; t; t = t->Next)
	{
		if (t->Render != RenderWorld) continue;
		
		const World* w = (World*) t;
		const Hull* h = w->Hulls + 0;
		
		Xyz lup = Norm(LocP2CPos(Toy.Pov.Loc, &t->Pos), 1);
		real len = h->Sample(0, lup, h->GeometryRes, w, h);
		real elv = Dis(Toy.Pov.Loc, t->Pos.Loc) - len;
		
		if (TOY_MIN_ELEV && elv < TOY_MIN_ELEV)
			Toy.Pov.Loc = LocC2PPos(Norm(lup, len + (elv = TOY_MIN_ELEV)), &t->Pos);
		if (elv < lowest) lowest = elv;
	}
	
	real moveSpeed = dt * MAX(TOY_MIN_SPEED, lowest) * TOY_MOVE_SPEED * Toy.MoveSpeed;
	real turnSpeed = dt * TOY_TURN_SPEED / Toy.Eye.Zoom;
	
	if (SysIsKeyDown(SYS_KEY_A)) ToyMove(-moveSpeed, 0, 0);
	if (SysIsKeyDown(SYS_KEY_D)) ToyMove(+moveSpeed, 0, 0);
	if (SysIsKeyDown(SYS_KEY_Q)) ToyMove(0, -moveSpeed, 0);
	if (SysIsKeyDown(SYS_KEY_E)) ToyMove(0, +moveSpeed, 0);
	if (SysIsKeyDown(SYS_KEY_W)) ToyMove(0, 0, -moveSpeed);
	if (SysIsKeyDown(SYS_KEY_S)) ToyMove(0, 0, +moveSpeed);
	if (SysIsKeyDown(SYS_KEY_LEFT)) ToyTurn(0, +turnSpeed, 0);
	if (SysIsKeyDown(SYS_KEY_RIGHT)) ToyTurn(0, -turnSpeed, 0);
	if (SysIsKeyDown(SYS_KEY_DOWN)) ToyTurn(-turnSpeed, 0, 0);
	if (SysIsKeyDown(SYS_KEY_UP)) ToyTurn(+turnSpeed, 0, 0);
	if (SysIsKeyDown(SYS_KEY_Z)) ToyTurn(0, 0, +dt);
	if (SysIsKeyDown(SYS_KEY_C)) ToyTurn(0, 0, -dt);
	if (SysIsKeyDown(SYS_KEY_PGUP)) ToyZoom(+dt);
	if (SysIsKeyDown(SYS_KEY_PGDN)) ToyZoom(-dt);
	if (SysIsKeyDown(SYS_KEY_HOME)) Toy.MoveSpeed *= pow(2, +dt);
	if (SysIsKeyDown(SYS_KEY_END)) Toy.MoveSpeed *= pow(2, -dt);
	
	Raster to; InitRasterFor (
		&to, sizeof(Syxel), bpr, &Toy.Eye.Pixels.Clip, raw
	); EyeBindScreen(&Toy.Eye, &to);
	
	EyeClear(&Toy.Eye, (Rgba8){ .A = 0xFF });
	RecurseThing(CollectThing, 0, Toy.Base, &Toy.Pov, &Toy.Eye);
	RecurseThing(RenderThing, 0, Toy.Base, &Toy.Pov, &Toy.Eye);
	EyePost(&Toy.Eye);
}

void ToyOnKeyDown (SysKey k, SysMods m)
{
	switch (k | m)
	{
		case SYS_KEY_ESCAPE: SysQuit(); break;
	}
}




struct SysApp SysApp =
{
	.Title = TOY_NAME,
	.Rate = TOY_RATE,
	
	.W = TOY_RES * 2,
	.H = TOY_RES * 2,
	
	.OnStart = ToyOnStart,
	.OnPaint = ToyOnPaint,
	.OnKeyDown = ToyOnKeyDown,
	.OnSize = ToyOnSize,
	
	#ifdef WINDOWED
		.Windowed = true,
	#endif
};
