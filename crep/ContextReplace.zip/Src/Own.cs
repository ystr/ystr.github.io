using System;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.Globalization;
using System.Collections.Generic;
using System.Text.RegularExpressions;

internal static class Own
{
	public static readonly string Place;
	
	public static readonly string Name = null;
	public static readonly string Author = null;
	
	static Assembly ass = Assembly.GetExecutingAssembly();
	static string tongue;
	
	public static bool AllowInternal = true;
	public static bool AllowExternal = true;
	
	public static string Tongue {
		get { return tongue; }
		set { tongue = value; Prepare(); }
	}
	
	static Own ()
	{
		object[] atts = ass.GetCustomAttributes(false);
		
		foreach (object att in atts)
		{
			if (att.GetType() == typeof(AssemblyProductAttribute))
				Name = (att as AssemblyProductAttribute).Product;
			
			if (att.GetType() == typeof(AssemblyCompanyAttribute))
				Author = (att as AssemblyCompanyAttribute).Company;
		}
		
		tongue = CultureInfo.CurrentUICulture.ToString().Split('-')[0];
		Place = Path.GetDirectoryName(ass.CodeBase).Replace("file:\\", "");
		
		Prepare();
	}
	
	public static string[] Items
	{
		get
		{
			string[] res;
			
			if (AllowInternal) res = ass.GetManifestResourceNames();
			else res = new String[0];
			
			if (!AllowExternal) return res;
			
			FileInfo[] files = new DirectoryInfo(Place).GetFiles();
			string[] items = new string[files.Length + res.Length];
			for (int i = 0; i < files.Length; i++) items[i] = files[i].Name;
			Array.Copy(res, 0, items, files.Length, res.Length);
			return items;
		}
	}
	
	public static Dictionary<string, string> Tongues
	{
		get
		{
			Dictionary<string, string> tongues = new Dictionary<string, string>();
			
			string[] all = Items;
			
			foreach (string one in all)
			{
				if (one.EndsWith(".tongue"))
				{
					using (StreamReader r = new StreamReader(Get(one)))
					{
						tongues[one.Substring(0, one.Length - 7)] = r.ReadLine().Trim();
					}
				}
			}
			
			return tongues;
		}
	}
	
	static Stream Load (string name)
	{
		if (AllowExternal) {
			try {
				return new FileStream(Place + "\\" + name, FileMode.Open);
			} catch {}
		}
		
		if (AllowInternal) return ass.GetManifestResourceStream(name);
		
		return null;
	}
	
	public static Stream Get (string name)
	{
		Stream s = Load(tongue + "." + name);
		if (s == null) s = Load(name);
		return s;
	}
	
	static string Fix (string name, string type)
	{
		if (name.Contains(".")) return name;
		return name + "." + type;
	}
	
	static Stream Get (string name, string type)
	{
		return Get(Fix(name, type));
	}
	
	public static Icon Icon (string name)
	{
		return new Icon(Get(name, "ico"));
	}
	
	public static Image Image (string name)
	{
		return System.Drawing.Image.FromStream(Get(name, "png"));
	}
	
	public static string Read (string name)
	{
		using (StreamReader r = new StreamReader(Get(name))) return r.ReadToEnd();
	}
	
	public static string Text (string name)
	{
		using (StreamReader r = new StreamReader(Get(name, "txt"))) return r.ReadToEnd();
	}
	
	static Dictionary<string, string> lines;
	
	static void Prepare ()
	{
		lines = new Dictionary<string, string>();
		List<string> list = new List<string>();
		
		try { list.AddRange(Regex.Split(Read("tongue"), "\r\n")); } catch {}
		try { list.AddRange(Regex.Split(Read("Lines.ini"), "\r\n")); } catch {}
		
		foreach (string line in list)
		{
			if (line.Contains("="))
			{
				string[] pair = line.Split('=');
				lines[pair[0].Trim()] = pair[1].Trim();
			}
		}
	}
	
	public static string Line (string key)
	{
		if (lines.ContainsKey(key)) return lines[key];
		return key;
	}
}