using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Media;
using System.Windows.Forms;


class Face : Window
{
	ToolBar toolbar = null;
	StatusBar statusbar = null;
	
	ContextMenu ctxMenu = null;
	Menu numCtxMenu = null;
	MarksMenu marksMenu = null;
	
	ContextMenu CtxMenu { get { if (ctxMenu == null) ctxMenu = new ContextMenu(this); return ctxMenu; } }
	MarksMenu MarksMenu { get { if (marksMenu == null) marksMenu = new MarksMenu(E); return marksMenu; } }
	
	Menu NumCtxMenu {
		get {
			
			if (numCtxMenu == null)
			{
				numCtxMenu = new Menu();
				Row hideNumbersRow = new Row("Hide Numbers", "F9");
				hideNumbersRow.Clicked += () => E.Numbers = false;
				numCtxMenu.Items.Add(hideNumbersRow);
			}
			
			return numCtxMenu;
		}
	}
	
	public readonly Editor E;
	public readonly Document D;
	
	Scroller.Vertical vScroll;
	
	class UnfocusableHScroller : HScrollBar { public UnfocusableHScroller () { SetStyle(ControlStyles.Selectable, false); } }
	UnfocusableHScroller hScroll;
	
	Box box;
	Grippie grip;
	
	bool altcombo = false;
	
	#region Options
		
		public static bool DefaultShowToolbar = true;
		public static bool DefaultShowStatusbar = true;
		
		public static readonly Option <bool> ShowTips = new Option <bool> (true) { Name = "Show Tooltips" };
		public static readonly Option <bool> ConfirmExit = new Option <bool> (true) { Name = "Confirm Exit" };
		public static readonly Option <bool> Overview = new Option <bool> (true) { Name = "Overview" };
		public readonly Option <bool> ShowToolbar = new Option <bool> (DefaultShowToolbar);
		public readonly Option <bool> ShowStatusbar = new Option <bool> (DefaultShowStatusbar);
		
	#endregion
	
	public Face (Document doc)
	{
		SuspendLayout();
		
		
		#region Options
			
			ShowToolbar.Changed += (show) => { SetToolbar(show); AdaptLayout(); };
			ShowStatusbar.Changed += (show) => { SetStatusbar(show); AdaptLayout(); };
			
		#endregion
		
		
		D = doc;
		
		D.SavingFailed += OnSavingFailed;
		D.OverwritingModified += OnOverwritingModified;
		
		NormalSize = Config.Get("WindowSize", new Size(640, 480));
		Maximized = Config.Get("Maximized", false);
		
		KeyPreview = true;
		
		box = new Box();
		Controls.Add(box);
		
		E = new Editor(D);
		E.Size = ClientSize;
		box.Controls.Add(E);
		
		E.NumbersContextRequested += OnNumbersContextRequested;
		E.ContextRequested += OnContextRequested;
		
		SetToolbar(ShowToolbar.Value);
		SetStatusbar(ShowStatusbar.Value);
		
		vScroll = new Scroller.Vertical();
		hScroll = new UnfocusableHScroller();
		hScroll.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
		vScroll.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
		vScroll.Location = new Point(box.ClientSize.Width - vScroll.Width, 0);
		hScroll.Location = new Point(0, box.ClientSize.Height - hScroll.Height);
		hScroll.SmallChange = 1;
		box.Controls.Add(vScroll);
		box.Controls.Add(hScroll);
		
		grip = new Grippie(this);
		grip.Location = new Point(vScroll.Left, hScroll.Top);
		grip.Size = new Size(vScroll.Width, hScroll.Height);
		box.Controls.Add(grip);
		
		vScroll.ChangeRequested += E.VScrollTo;
		vScroll.OnTrackPaint += E.PaintTrack;
		vScroll.Overview = Overview.Value;
		
		hScroll.ValueChanged += (o, e) => E.HScrollTo(hScroll.Value);
		
		D.FilePathChanged += OnFilePathChanged;
		D.UnsavedChanged += UpdateTitle;
		E.ViewChanged += AdaptScrollbars;
		E.Rendered += vScroll.Invalidate;
		
		Overview.Changed += OnOverviewChanged;
		
		Shown += (o, r) => Summon();
		Resize += (o, e) => { if (!Minimized) AdaptLayout(); };
		
		AllowDrop = true;
		
		DragEnter += (o, e) => {
			if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
			else e.Effect = DragDropEffects.None;
		};
		
		DragDrop += (o, e) => {
			if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
				Open(((string[])e.Data.GetData(DataFormats.FileDrop))[0]);
			}
		};
		
		MouseWheel += (o, e) =>
		{
			if (Control.ModifierKeys == Keys.Control)
			{
				if (e.Delta > 0) ZoomIn();
				else ZoomOut();
			}
			else
			{
				if (Control.ModifierKeys != Keys.None) return;
				int delta = -e.Delta / 120;
				int sl = SystemInformation.MouseWheelScrollLines;
				if (sl == -1) E.VScrollPage(delta);
				else E.VScroll(delta * sl);
			}
		};
		
		KeyUp += (o, e) =>
		{
			if (e.KeyCode == Keys.Menu)
			{
				if (!altcombo) Toolbar.Focus();
				
				e.Handled = true;
				altcombo = false;
			}
		};
		
		KeyDown += (o, e) =>
		{
			if (e.Alt && (e.Control || e.Shift)) altcombo = true;
			
			bool ctrl = (e.Modifiers == Keys.Control);
			bool altShift = (e.Modifiers == (Keys.Shift | Keys.Alt));
			bool ctrlShift = (e.Modifiers == (Keys.Control | Keys.Shift));
			
			switch (e.KeyCode)
			{
				case Keys.D: if (ctrl) E.DuplicateLine(); else return; break;
				case Keys.G: if (ctrl) ShowGo(); else return; break;
				case Keys.H:
					if (ctrl) Toolbar.ReplaceSelected();
					else if (ctrlShift) Toolbar.More = false;
					else return;
				break;
				case Keys.F:
					if (ctrl) SearchSelected();
					else if (ctrlShift) E.Search = null;
					else return;
				break;
				case Keys.I: if (ctrl) E.ShowSpace =! E.ShowSpace; else return; break;
				case Keys.M:
					if (ctrl) {
						if (D.Marks.Count > 0) MarksMenu.Show(E, new Point(0, 0));
					} else return;
				break;
				case Keys.N: if (ctrl) NewInstance(); else return; break;
				case Keys.O: if (ctrl) ShowOpen(); else return; break;
				case Keys.S:
					if (ctrl) Save();
					else if (ctrlShift) ShowSaveAs();
					else if (altShift) ShowSaveCopy();
					else return;
				break;
				case Keys.W: if (ctrl) E.Wrap =! E.Wrap; else return; break;
				case Keys.Y: if (ctrl) D.Redo(); else return; break;
				case Keys.Z: if (ctrl) D.Undo(); else return; break;
				
				case Keys.Space:
					if (ctrl) E.ToggleMark();
					else if (ctrlShift) D.ClearMarks();
					else return;
				break;
				
				case Keys.OemOpenBrackets:
					if (ctrl) E.SearchCaseInvariant = false;
					else if (ctrlShift) E.SearchCaseInvariant = true;
					else return;
				break;
				case Keys.OemCloseBrackets:
					if (ctrl) E.SearchWords = true;
					else if (ctrlShift) E.SearchWords = false;
					else return;
				break;
				case Keys.OemPipe:
					if (ctrl) E.SearchUnescape = true;
					else if (ctrlShift) E.SearchUnescape = false;
					else return;
				break;
				
				case Keys.D0: case Keys.NumPad0: if (ctrl) ResetZoom(); else return; break;
				
				case Keys.D1: if (ctrl) E.GoToMark(0); else return; break;
				case Keys.D2: if (ctrl) E.GoToMark(1); else return; break;
				case Keys.D3: if (ctrl) E.GoToMark(2); else return; break;
				case Keys.D4: if (ctrl) E.GoToMark(3); else return; break;
				case Keys.D5: if (ctrl) E.GoToMark(4); else return; break;
				case Keys.D6: if (ctrl) E.GoToMark(5); else return; break;
				case Keys.D7: if (ctrl) E.GoToMark(6); else return; break;
				case Keys.D8: if (ctrl) E.GoToMark(7); else return; break;
				case Keys.D9: if (ctrl) E.GoToMark(8); else return; break;
				
				case Keys.F1: Help(); break;
				case Keys.F3: E.SelectNextFound(e.Shift ? -1 : +1); break;
				case Keys.F5: Reload(); break;
				case Keys.F7: SaveConfig(); break;
				case Keys.F9: E.Numbers =! E.Numbers; break;
				case Keys.F11: ShowToolbar.Value =! ShowToolbar.Value; break;
				case Keys.F12: ShowStatusbar.Value =! ShowStatusbar.Value; break;
				
				case Keys.Escape: E.Focus(); break;
				case Keys.Oemtilde: if (ctrl) E.GoToCaret(); else return; break;
				case Keys.Insert: E.Overwrite =! E.Overwrite; break;
				case Keys.PageUp: E.MoveCaretVerticalPage(-1, e.Shift); break;
				case Keys.PageDown: E.MoveCaretVerticalPage(+1, e.Shift); break;
				case Keys.Home: E.GoToStart(); break;
				case Keys.End: E.GoToEnd(); break;
				case Keys.Subtract: case Keys.OemMinus: if (ctrl) ZoomOut(); else return; break;
				case Keys.Add: if (ctrl) ZoomIn(); else return; break;
				case Keys.Oemplus: if (ctrlShift) ZoomIn(); else return; break;
				
				case Keys.F2:
					GC.Collect();
					GC.WaitForPendingFinalizers();
				break;
				
				default: return;
			}
			
			e.Handled = true;
		};
		
		FormClosing += (o, e) =>
		{
			if (
				D.Unsaved && ConfirmExit.Value &&
				Nawtpad.CountInstances(D) == 1
			) {
				DialogResult save = MessageBox.Show
				(
					Own.Line("Save before closing?"),
					Own.Line("Exit"),
					MessageBoxButtons.YesNoCancel,
					MessageBoxIcon.Information
				);
				
				switch (save)
				{
					case DialogResult.Cancel: e.Cancel = true; break;
					case DialogResult.Yes: if (!Save()) e.Cancel = true; break;
				}
			}
		};
		
		Own.SkinChanged += Skinize;
		Skinize();
		
		UpdateTitle();
		AdaptLayout();
		
		ShowTips.Changed += SetShowTips;
		SetShowTips(ShowTips.Value);
		
		ResumeLayout();
	}
	
	static Face ()
	{
		ShowTips.Value = Config.Get("ShowTips", true);
		ConfirmExit.Value = Config.Get("ConfirmExit", true);
		Overview.Value = Config.Get("Overview", true);
	}
	
	protected override void Dispose (bool disposing)
	{
		D.SavingFailed -= OnSavingFailed;
		D.OverwritingModified -= OnOverwritingModified;
		D.FilePathChanged -= OnFilePathChanged;
		D.UnsavedChanged -= UpdateTitle;
		
		E.ViewChanged -= AdaptScrollbars;
		E.ContextRequested -= OnContextRequested;
		E.NumbersContextRequested -= OnNumbersContextRequested;
		E.Rendered -= vScroll.Invalidate;
		
		vScroll.OnTrackPaint -= E.PaintTrack;
		
		Own.SkinChanged -= Skinize;
		ShowTips.Changed -= SetShowTips;
		Overview.Changed -= OnOverviewChanged;
		
		if (ctxMenu != null) ctxMenu.Dispose();
		if (marksMenu != null) marksMenu.Dispose();
		if (numCtxMenu != null) numCtxMenu.Dispose();
		vScroll.Dispose();
		
		base.Dispose(disposing);
	}
	
	void Skinize ()
	{
		#if !DEBUG
			Icon = Own.Icon("Main");
		#endif
	}
	
	public void ZoomIn () { E.FontSize *= 1.025F; }
	public void ZoomOut () { E.FontSize /= 1.025F; }
	public void ResetZoom () { E.FontSize = Editor.DefaultFontSize; }
	
	void OnOverviewChanged (bool ovr)
	{
		vScroll.Overview = ovr;
	}
	
	void OnFilePathChanged (string op, string np)
	{
		UpdateTitle();
	}
	
	void OnSavingFailed (Exception e)
	{
		Fail(Own.Line("Unable to save %0", D.FileName), e.Message);
	}
	
	bool OnOverwritingModified ()
	{
		return MessageBox.Show (
			Own.Line("The file was modified externally. Overwrite?"),
			Own.Line(D.FileName), MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
			MessageBoxDefaultButton.Button2
		) == DialogResult.Yes;
	}
	
	void AdaptLayout ()
	{
		SuspendLayout();
		
		int top = toolbar != null ? toolbar.Bottom : 0;
		box.Location = new Point(0, top);
		
		int h = ClientSize.Height - box.Top;
		if (statusbar != null) h -= statusbar.Height;
		
		box.Size = new Size(ClientSize.Width, h);
		
		AdaptScrollbars();
		
		ResumeLayout();
	}
	
	void AdaptScrollbars ()
	{
		SuspendLayout();
		
		E.Width = box.ClientSize.Width - (E.VScrollRequired ? vScroll.Width : 0);
		E.Height = box.ClientSize.Height - (E.HScrollRequired ? hScroll.Height : 0);
		
		if (E.VScrollRequired) vScroll.Height = E.Height;
		if (E.HScrollRequired) hScroll.Width = E.Width;
		
		vScroll.Visible = vScroll.Enabled = E.VScrollRequired;
		hScroll.Visible = hScroll.Enabled = E.HScrollRequired;
		
		if (vScroll.Enabled)
		{
			vScroll.Maximum = E.VScrollMax;
			vScroll.Span = E.VPageScrollSpan;
			vScroll.Start = E.VScrollPos;
		}
		
		if (hScroll.Enabled)
		{
			hScroll.Maximum = E.HScrollMax;
			hScroll.LargeChange = E.HPageScrollSpan;
			hScroll.Value = E.HScrollPos;
		}
		
		grip.Visible = (statusbar == null) && vScroll.Enabled && hScroll.Enabled;
		
		ResumeLayout();
	}
	
	void UpdateTitle ()
	{
		Text = (
			(D.Unsaved ? "* " : "") + D.FileName +
			(D.FilePath != null ? (" | " +
				Path.GetDirectoryName(D.FilePath)
			) : "") + " | " + Own.Name
		);
	}
	
	public bool ShowSaveAs ()
	{
		SaveFileDialog saver = new SaveFileDialog();
		saver.Filter = Own.Line("All files") + "|*.*";
		if (saver.ShowDialog() != DialogResult.OK) return false;
		return D.SaveAs(saver.FileName);
	}
	
	public bool ShowSaveCopy ()
	{
		SaveFileDialog saver = new SaveFileDialog();
		saver.Filter = Own.Line("All files") + "|*.*";
		if (saver.ShowDialog() != DialogResult.OK) return false;
		return D.SaveTo(saver.FileName);
	}
	
	public void Reload ()
	{
		try { D.Reload(); }
		catch (Exception e) {
			Fail(Own.Line("Unable to reload %0", D.FileName), e.Message);
		}
	}
	
	public void Open (string path)
	{
		try { D.Open(path); }
		catch (Exception e) { Fail(Own.Line("Unable to open %0", path), e.Message); }
	}
	
	public bool Save ()
	{
		if (D.FilePath == null) return ShowSaveAs();
		else return D.Save();
	}
	
	public void ShowOpen ()
	{
		OpenFileDialog opener = new OpenFileDialog();
		opener.FileOk += (o, e) => Open(opener.FileName);
		opener.ShowDialog();
	}
	
	public void NewInstance ()
	{
		Nawtpad.Instantiate(D);
	}
	
	public void ShowGo ()
	{
		Statusbar.ShowGo();
	}
	
	void SetStatusbar (bool show)
	{
		SuspendLayout();
		
		if (statusbar == null && show)
		{
			statusbar = new StatusBar(this);
			statusbar.Dock = DockStyle.Bottom;
			statusbar.ShowItemToolTips = ShowTips.Value;
			Controls.Add(statusbar);
		}
		else if (statusbar != null && !show)
		{
			statusbar.Dispose();
			statusbar = null;
		}
		
		ResumeLayout();
	}
	
	void SetToolbar (bool show)
	{
		SuspendLayout();
		
		if (toolbar == null && show)
		{
			toolbar = new ToolBar(this);
			toolbar.ShowItemToolTips = ShowTips.Value;
			Controls.Add(toolbar);
		}
		else if (toolbar != null && !show)
		{
			toolbar.Dispose();
			toolbar = null;
		}
		
		ResumeLayout();
	}
	
	protected ToolBar Toolbar {
		get {
			if (toolbar == null) { SetToolbar(ShowToolbar.Value = true); AdaptLayout(); }
			return toolbar;
		}
	}
	
	protected StatusBar Statusbar {
		get {
			if (statusbar == null) { SetStatusbar(ShowStatusbar.Value = true); AdaptLayout(); }
			return statusbar;
		}
	}
	
	void SetShowTips (bool show)
	{
		if (toolbar != null) toolbar.ShowItemToolTips = show;
		if (statusbar != null) statusbar.ShowItemToolTips = show;
	}
	
	void OnContextRequested (Point p)
	{
		CtxMenu.Show(E, p);
	}
	
	void OnNumbersContextRequested (Point p)
	{
		NumCtxMenu.Show(E, p);
	}
	
	void Fail (string title, string message)
	{
		MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
	}
	
	public void SearchSelected ()
	{
		Toolbar.SearchSelected();
	}
	
	public void ReplaceSelected ()
	{
		Toolbar.ReplaceSelected();
	}
	
	public void SaveConfig ()
	{
		Config.Set("WindowSize", NormalSize);
		Config.Set("Maximized", Maximized);
		
		//Config.Set("ShowTips", ShowTips);
		//Config.Set("Overview", Overview);
		//Config.Set("ConfirmExit", ConfirmExit);
		
		Config.SemaSet(this);
		
		DefaultShowToolbar = Config.Set("ShowToolbar", ShowToolbar.Value);
		DefaultShowStatusbar = Config.Set("ShowStatusbar", ShowStatusbar.Value);
		
		Editor.DefaultAutoPasteIndent = Config.Set("AutoPasteIndent", E.AutoPasteIndent);
		Editor.DefaultAltSearchEnabled = Config.Set("AltSearchEnabled", E.AltSearchEnabled);
		Editor.DefaultFontSize = Config.Set("FontSize", E.FontSize);
		Editor.DefaultFontName = Config.Set("FontName", E.FontName);
		Editor.DefaultNumbers = Config.Set("Numbers", E.Numbers);
		Editor.DefaultOverwrite = Config.Set("Overwrite", E.Overwrite);
		Editor.DefaultShowControl = Config.Set("ShowControl", E.ShowControl);
		Editor.DefaultSearchCaseInvariant = Config.Set("SearchCaseInvariant", E.SearchCaseInvariant);
		Editor.DefaultSearchUnescape = Config.Set("SearchUnescape", E.SearchUnescape);
		Editor.DefaultSearchWords = Config.Set("SearchWords", E.SearchWords);
		Editor.DefaultSearchIncremental = Config.Set("SearchIncremental", E.SearchIncremental);
		Editor.DefaultShowSpace = Config.Set("ShowSpace", E.ShowSpace);
		Editor.DefaultTabKeyFunction = Config.Set("TabKeyFunction", E.TabKeyFunction);
		Editor.DefaultWrap = Config.Set("Wrap", E.Wrap);
		Editor.DefaultWrapIndent = Config.Set("WrapIndent", E.WrapIndent);
		Editor.DefaultWrapIndentExtra = Config.Set("WrapIndentExtra", E.WrapIndentExtra);
		Editor.DefaultGuides = Config.Set("Guides", E.Guides);
		Editor.DefaultBraceMatching = Config.Set("BraceMatching", E.BraceMatching);
		
		Config.Set("IndentWithSpaces", Document.DefaultIndentWithSpaces);
		Config.Set("IndentSize", Document.DefaultIndentSize);
		Config.Set("DetectIndent", Document.DetectIndent);
		Config.Set("DefaultEncoding", Document.DefaultEncoding);
		
		Config.Set("Skin", Own.Skin);
		Config.Set("Locale", Own.Locale);
		Config.Set("Remain", Nawtpad.Remain);
		
		Config.Set("Associations", Scheme.ExportAssocs());
		
		try { Config.Save(); }
		catch (Exception e) { Fail("Unable to save config", e.Message); }
	}
	
	public static void Help ()
	{
		string hp = Own.Locate("Help.txt");
		
		if (hp != null) Process.Start(Own.ExePath, "\"" + hp + "\"");
		else MessageBox.Show (
			Own.Line("Help file not found"), Own.Line("Help"),
			MessageBoxButtons.OK, MessageBoxIcon.Error
		);
	}
}
