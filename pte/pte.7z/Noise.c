typedef u32 Seed;
Seed BadSeed = 666;


#define SEED0(S) ((u32)(S) * 1664525 + 1013904223)
#define SEED1(S) ((u32)(S) * 5642122 + 9811162227)
#define SEED2(S) ((u32)(S) * 1947412 + 4311230375)


#define SEED SEED0
#define NOISESTEP Smooth


u32 R32 (Seed s) { return SEED(s); }
u16 R16 (Seed s) { u32 r = R32(s); return r ^ (r >> 16); }
u8 R8 (Seed s) { u32 r = R32(s); return r ^ (r >> 24); }

Seed RS (Seed s) { return R32(s); }
Seed RN (Seed* s) { return *s = RS(*s); }

real R0R (Seed s) { return R32(s) * (1.0 / UINT32_MAX); }
real RRR (Seed s) { return R32(s) * (2.0 / UINT32_MAX) - 1; }


real Noise1R (real x, Seed s)
{
	s32 x0 = floor(x), x1 = x0 + 1;
	real wx1 = NOISESTEP(x - x0), wx0 = 1 - wx1;
	Seed sx0 = SEED0(x0), sx1 = SEED0(x1);
	
	return (
		RRR(sx0 ^ s) * wx0 +
		RRR(sx1 ^ s) * wx1
	);
}

real Noise2R (real x, real y, Seed s)
{
	s32 x0 = floor(x), x1 = x0 + 1;
	s32 y0 = floor(y), y1 = y0 + 1;
	
	real wx1 = NOISESTEP(x - x0), wx0 = 1 - wx1;
	real wy1 = NOISESTEP(y - y0), wy0 = 1 - wy1;
	
	Seed sx0 = SEED0(x0), sx1 = SEED0(x1);
	Seed sy0 = SEED1(y0), sy1 = SEED1(y1);
	
	return (
		RRR(sx0 ^ sy0 ^ s) * wx0 * wy0 +
		RRR(sx0 ^ sy1 ^ s) * wx0 * wy1 +
		RRR(sx1 ^ sy0 ^ s) * wx1 * wy0 +
		RRR(sx1 ^ sy1 ^ s) * wx1 * wy1
	);
}

real Noise3R (real x, real y, real z, Seed s)
{
	s32 x0 = floor(x), x1 = x0 + 1;
	s32 y0 = floor(y), y1 = y0 + 1;
	s32 z0 = floor(z), z1 = z0 + 1;
	
	real wx1 = NOISESTEP(x - x0), wx0 = 1 - wx1;
	real wy1 = NOISESTEP(y - y0), wy0 = 1 - wy1;
	real wz1 = NOISESTEP(z - z0), wz0 = 1 - wz1;
	
	Seed sx0 = SEED0(x0), sx1 = SEED0(x1);
	Seed sy0 = SEED1(y0), sy1 = SEED1(y1);
	Seed sz0 = SEED2(z0), sz1 = SEED2(z1);
	
	return (
		RRR(sx0 ^ sy0 ^ sz0 ^ s) * wx0 * wy0 * wz0 +
		RRR(sx0 ^ sy0 ^ sz1 ^ s) * wx0 * wy0 * wz1 +
		RRR(sx0 ^ sy1 ^ sz0 ^ s) * wx0 * wy1 * wz0 +
		RRR(sx0 ^ sy1 ^ sz1 ^ s) * wx0 * wy1 * wz1 +
		RRR(sx1 ^ sy0 ^ sz0 ^ s) * wx1 * wy0 * wz0 +
		RRR(sx1 ^ sy0 ^ sz1 ^ s) * wx1 * wy0 * wz1 +
		RRR(sx1 ^ sy1 ^ sz0 ^ s) * wx1 * wy1 * wz0 +
		RRR(sx1 ^ sy1 ^ sz1 ^ s) * wx1 * wy1 * wz1
	);
}

Xyz Spherand (real rad, Seed* seed)
{
	real z = RRR(RN(seed));
	real a = R0R(RN(seed)) * TAU;
	real r = sqrt(1 - P2(z));
	
	return (Xyz) {
		r * cos(a) * rad,
		r * sin(a) * rad,
		z * rad
	};
}
