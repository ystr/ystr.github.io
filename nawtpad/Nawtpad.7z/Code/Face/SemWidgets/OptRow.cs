class OptRow : System.Windows.Forms.ToolStripMenuItem
{
	public readonly Entry Option = null;
	
	public readonly Option <bool> BoolOption = null;
	
	void Localize ()
	{
		Text = Own.Line(Option.Name);
	}
	
	void Skinize ()
	{
		if (Option.Icon == null) return;
		else Image = Own.Image(Option.Icon);
	}
	
	void Initialize ()
	{
		if (Option.Keys != null) ShortcutKeyDisplayString = "(" + Option.Keys + ")";
		
		Own.LocaleChanged += Localize;
		Own.SkinChanged += Skinize;
		
		Localize();
		Skinize();
		
		Update();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		Own.SkinChanged -= Skinize;
		
		DropDown.Dispose();
		
		base.Dispose(disposing);
	}
	
	public OptRow (Option <bool> option)
	{
		this.Option = option;
		this.BoolOption = option;
		
		Initialize();
	}
	
	protected override void OnClick (System.EventArgs e)
	{
		DoClick(false);
	}
	
	public void OnKeyUp (System.Windows.Forms.KeyEventArgs e)
	{
		if (e.KeyCode == System.Windows.Forms.Keys.Space) DoClick(true);
	}
	
	protected override void OnMouseUp (System.Windows.Forms.MouseEventArgs a)
	{
		if (a.Button == System.Windows.Forms.MouseButtons.Right) DoClick(true);
	}
	
	void DoClick (bool noclose)
	{
		if (
			Parent is Menu &&
			DropDownItems.Count == 0 &&
			!noclose /*&& !Option*/
		) (Parent as Menu).ForceClose();
		
		if (BoolOption != null) BoolOption.Value =! BoolOption.Value;
		
		Update();
	}
	
	void Update ()
	{
		if (BoolOption != null) Checked = BoolOption.Value;
	}
}