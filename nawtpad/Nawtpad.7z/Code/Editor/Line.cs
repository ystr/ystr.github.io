using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

class Line : IEnumerable
{
	public Pass PassIn = null;
	public Pass PassOut = null;
	
	public bool Marked = false;
	public string MarkName = null;
	
	string text;
	readonly List<CharMeta> metas;
	
	public string Text { get { return text; } }
	public List<CharMeta> Meta { get { return metas; } }
	
	public Line ()
	{
		text = "";
		metas = new List<CharMeta>();
	}
	
	public Line (List<CharMeta> meta, string text)
	{
		this.text = text;
		metas = meta;
	}
	
	public Line (string s)
	{
		text = "";
		metas = new List<CharMeta>(); Append(s);
	}
	
	public int Length { get { return metas.Count; } }
	
	public void Append (CharMeta s, char c) { metas.Add(s); text += c; }
	
	public void Append (string s)
	{
		foreach (char c in s) metas.Add(new CharMeta(c));
		text += s;
	}
	
	//public void Insert (int i, CharMeta c)
	//{
		//metas.Insert(i, c);
	//}
	
	public void Insert (int i, string s)
	{
		text = text.Insert(i, s);
		foreach (char c in s) metas.Insert(i++, new CharMeta(c));
	}
	
	//public void RemoveAt (int i)
	//{
		//metas.RemoveAt(i);
	//}
	
	public void RemoveRange (int i, int n)
	{
		metas.RemoveRange(i, n);
		text = text.Remove(i, n);
	}
	
	public Line Copy () { return Copy(0); }
	public Line Copy (int i) { return Copy(i, Length - i); }
	
	public Line Copy (int i, int n)
	{
		return new Line(metas.GetRange(i, n), text.Substring(i, n));
	}
	
	public Line Cut (int i) { return Cut(i, Length - i); }
	public Line Cut (int i, int n)
	{
		Line re = Copy(i, n);
		RemoveRange(i, n);
		return re;
	}
	
	public string Export () { return Export(0, metas.Count); }
	public string Export (int start, int end)
	{
		return Text.Substring(start, end - start);
	}
	
	public Limits FindWordBounds (int at)
	{
		if (metas.Count == 0) return new Limits(0, 0);
		if (at >= metas.Count) at = metas.Count - 1;
		
		CharMeta c = metas[at];
		
		bool spaces = c.IsBreaker;
		bool alphns = c.IsWordPart;
		
		int i = at;
		
		while (i >= 0)
		{
			bool w = metas[i].IsBreaker;
			bool a = metas[i].IsWordPart;
			
			if (alphns) { if (!a) break; }
			else if (spaces) { if (!w) break; }
			else if (a || w) break;
			
			--i;
		}
		
		int start = i + 1;
		i = at + 1;
		
		while (i < metas.Count)
		{
			bool w = metas[i].IsBreaker;
			bool a = metas[i].IsWordPart;
			
			if (alphns) { if (!a) break; }
			else if (spaces) { if (!w) break; }
			else if (a || w) break;
			
			++i;
		}
		
		return new Limits(start, i);
	}
	
	public int FindIndented ()
	{
		for (int i = 0; i < metas.Count; ++i)
		{
			if (!char.IsWhiteSpace(Text[i])) return i;
		}
		
		return -1;
	}
	
	public IEnumerator GetEnumerator ()
	{
		foreach (CharMeta c in metas)
		{
			yield return c;
		}
	}
}