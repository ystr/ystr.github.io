enum ChangeType
{
	Removed,
	Added
};

class Change
{
	public readonly ChangeType Type;
	
	public readonly Pos Start;
	public readonly string Content;
	public readonly Pos End;
	
	public Change (ChangeType type, Pos start, string content, Pos end)
	{
		Type = type;
		Start = start;
		Content = content;
		End = end;
	}
}