struct Range
{
	public Pos Start;
	public Pos End;
	
	public delegate void Action (Range r);
	
	public Range (Pos start, Pos end)
	{
		Start = start;
		End = end;
	}
}