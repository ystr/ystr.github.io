using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;


class SchemeMenu : Menu
{
	public readonly Document D;
	
	ToolStripSeparator assocSep = new ToolStripSeparator();
	readonly Row assocRow = new Row("Use for %0");
	
	public SchemeMenu (Document doc)
	{
		D = doc;
		
		foreach (string id in Scheme.ListSchemes())
		{
			Row sr = new Row(Scheme.NameFromID(id));
			sr.Name = id;
			sr.Clicked += () => SetScheme(sr);
			Items.Add(sr);
		}
		
		assocRow.Clicked += () =>
		{
			D.Scheme.AssociateWith(D);
			Reveal();
		};
		
		Items.Add(assocSep);
		Items.Add(assocRow);
		
		Opening += (o, e) =>
		{
			D.SchemeChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			D.SchemeChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		this.Check(r => D.Scheme.ID == r.Name);
		
		if (assocRow.Visible = assocSep.Visible = D.FileExtension != "")
		{
			assocRow.Text = Own.Line("Associate .%0", D.FileExtension);
			assocRow.Checked = D.Scheme.IsAssociatedWith(D);
			assocRow.Enabled = !D.Scheme.IsAssociatedWith(D);
		}
	}
	
	void SetScheme (Row r)
	{
		D.Scheme = Scheme.FromID(r.Name);
	}
}