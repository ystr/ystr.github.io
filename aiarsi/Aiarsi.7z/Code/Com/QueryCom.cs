using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

class QueryCom : ChatCom
{
	public readonly Query Query;
	
	public QueryCom (Query q) : base (q, Sig(q))
	{
		Query = q;
		
		Text = Query.Name;
		
		IconName = "Query";
		Skinize();
		
		Query.Terminated += Close;
		Server.WelcomedChanged += SyncAdmitStatus;
		
		AdmitStatus();
	}
	
	protected override void Dispose (bool disposing)
	{
		Query.Terminated -= Close;
		Server.WelcomedChanged -= SyncAdmitStatus;
		base.Dispose(disposing);
	}
	
	
	void SyncAdmitStatus () { this.Sync(AdmitStatus); }
	void AdmitStatus ()
	{
		HSplit.Panel2Collapsed = !Server.Welcomed;
	}
	
	
	static string Sig (Query q)
	{
		return "Servers\\" + q.Server.ID + "\\Queries\\" + Options.Escape(q.ID);
	}
	
	public static QueryCom Opened (Query q)
	{
		return (QueryCom) Opened(Sig(q));
	}
	
	public static void Open (Query q)
	{
		if (!Open(Sig(q)))
		{
			Open(new QueryCom(q));
		}
	}
}