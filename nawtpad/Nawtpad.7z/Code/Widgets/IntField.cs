using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;


class IntField : Field
{
	bool selfchange = false;
	
	public readonly int Min;
	public readonly int Max;
	
	int intvalue;
	public event Action ValueChanged = () => {};
	public int Value {
		get { return intvalue; }
		set { intvalue = value; Reveal(); }
	}
	
	public IntField (int min, int max)
	{
		Min = intvalue = min;
		Max = max;
		
		AutoSize = false;
		Width = 10 * Max.ToString().Length;
		
		TextChanged += (o, e) =>
		{
			ForeColor = SystemColors.WindowText.Rip();
			
			if (selfchange) return;
			
			try {
				
				int newv = int.Parse(Text, CultureInfo.InvariantCulture);
				if (newv > Max || newv < Min) throw new Exception();
				
				if (newv != intvalue)
				{
					intvalue = newv;
					ValueChanged();
				} 
				
			} catch { ForeColor = Color.Red; }
		};
		
		Reveal();
	}
	
	void Reveal ()
	{
		selfchange = true;
		Text = intvalue.ToString();
		selfchange = false;
	}
}