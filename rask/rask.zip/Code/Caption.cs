using System;
using System.Drawing;
using System.Windows.Forms;

class Caption : TextBox
{
	Frame frame;
	
	public Frame Frame
	{
		get { return frame; }
		set { frame = value; Text = frame.Caption; }
	}
	
	public Caption (Frame f)
	{
		Frame = f;
		Multiline = true;
		ScrollBars = ScrollBars.Vertical;
		DoubleBuffered = true;
		TextChanged += (o, e) => { Frame.Caption = Text; };
	}
}