using System.Collections.Generic;
using System.Drawing;

class Sub
{
	public int Start;
	public int End;
	public int VisualStart;
	public int VisualEnd;
	public int VisualIndent;
}