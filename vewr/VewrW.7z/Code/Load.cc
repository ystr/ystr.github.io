bool Load (TCHAR* path)
{
	delete Source; Source = 0;
	delete [] FrameTimes; FrameTimes = 0;
	
	Source = new Image(path);
	
	if (Source->GetLastStatus() != Ok)
	{
		TCHAR* ext = wcsrchr(path, '.');
		if (!ext) return false; ext += 1;
		for (int i = 0; i < 3; ++i) ext[i] = tolower(ext[i]);
		
		if (wcscmp(ext, L"tga") == 0) Source = LoadTarga(path);
		else return false;
		
		if (!Source) return false;
	}
	
	wcscpy(Path, path);
	
	int fdc = Source->GetFrameDimensionsCount();
	GUID* fds = new GUID[fdc];
	Source->GetFrameDimensionsList(fds, fdc);
	FDID = fds[0]; delete [] fds;
	
	FrameCount = Source->GetFrameCount(&FDID);
	
	if (FrameCount > 1)
	{
		int ps = Source->GetPropertyItemSize(PropertyTagFrameDelay);
		PropertyItem* pi = (PropertyItem*)malloc(ps);
		Source->GetPropertyItem(PropertyTagFrameDelay, ps, pi);
		long* times = (long*) pi->value;
		
		FrameTimes = new int[FrameCount];
		
		for (int i = 0; i < FrameCount; i++)
		{
			FrameTimes[i] = times[i] * 10;
		}
		
		delete pi;
	}
	
	SourceWidth = Source->GetWidth();
	SourceHeight = Source->GetHeight();
	
	return true;
}
