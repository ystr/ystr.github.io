using System;
using System.Drawing;
using System.Windows.Forms;

class Knob : Button
{
	readonly string text;
	void Localize () { Text = Own.Line(text); }
	
	public Knob (string text)
	{
		this.text = text;
		Own.LocaleChanged += Localize;
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}