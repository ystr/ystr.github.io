set -e

ShDir=/usr/local/share/Lma
BinDir=/usr/local/bin

mkdir -p $ShDir

cp Lma.py $ShDir
cp Lma.lma $ShDir

echo "${ShDir}/Lma.py ${ShDir}/Lma.lma \$@" > $BinDir/lma
echo 'rlwrap -n lma - $@' > $BinDir/lmar

chmod -R 755 $ShDir
chmod 755 $BinDir/lma
chmod 755 $BinDir/lmar

GSWDir=/usr/local/share/gtksourceview-3.0/language-specs
mkdir -p $GSWDir
cp lma.lang $GSWDir

MimeDir=/usr/local/share/mime
mkdir -p $MimeDir/packages
cp lma.xml $MimeDir/packages/lma.xml
update-mime-database $MimeDir
