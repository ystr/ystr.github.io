using System;
using System.Drawing;
using System.Windows.Forms;

class Tab : TabPage
{
	readonly string text;
	void Localize () { Text = Own.Line(text); }
	
	public Tab (string title)
	{
		text = title;
		Padding = new Padding(10);
		UseVisualStyleBackColor = true;
		Own.LocaleChanged += Localize;
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}
