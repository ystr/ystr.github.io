#include <SDL2/SDL.h>


#if SDL_BYTEORDER == SDL_BIG_ENDIAN
	#define SDL_PIXELFORMAT SDL_PIXELFORMAT_RGBA8888
#else
	#define SDL_PIXELFORMAT SDL_PIXELFORMAT_ABGR8888
#endif


static struct {
	
	SDL_Window* Window;
	SDL_Renderer* Renderer;
	SDL_Texture* Buffer;
	
	Syxel* Pixels;
	int Stride;
	
} Sys = {0};


#define FIRE(F) if (F) F
#define KEYRANGE(V, F0, F1, T0) (V >= F0 && V <= F1) return T0 + (V - F0)


static int SdlScanFromSysKey (const SysKey k)
{
	if KEYRANGE (k, 'A', 'Z', SDL_SCANCODE_A);
	else if KEYRANGE (k, SYS_KEY_F01, SYS_KEY_F12, SDL_SCANCODE_F1);
	else switch (k) {
		case SYS_KEY_LEFT: return SDL_SCANCODE_LEFT;
		case SYS_KEY_RIGHT: return SDL_SCANCODE_RIGHT;
		case SYS_KEY_DOWN: return SDL_SCANCODE_DOWN;
		case SYS_KEY_UP: return SDL_SCANCODE_UP;
		case SYS_KEY_PGUP: return SDL_SCANCODE_PAGEUP;
		case SYS_KEY_PGDN: return SDL_SCANCODE_PAGEDOWN;
		case SYS_KEY_HOME: return SDL_SCANCODE_HOME;
		case SYS_KEY_END: return SDL_SCANCODE_END;
		case SYS_KEY_ESCAPE: return SDL_SCANCODE_ESCAPE;
		case SYS_KEY_CTRL: return SDL_SCANCODE_LCTRL;
		default: return -1;
	}
}

static SysMods SysModsFromSdl ()
{
	SysMods m = 0;
	
	SDL_Keymod sm = SDL_GetModState();
	
	if (sm & KMOD_SHIFT) m |= SYS_SHIFT;
	if (sm & KMOD_CTRL) m |= SYS_CTRL;
	if (sm & KMOD_ALT) m |= SYS_ALT;
	
	return m;
}

static SysKey SysKeyFromSdl (const SDL_Keysym* ks)
{
	if KEYRANGE (ks->scancode, SDL_SCANCODE_A, SDL_SCANCODE_Z, 'A');
	else if KEYRANGE (ks->scancode, SDL_SCANCODE_F1, SDL_SCANCODE_F12, SYS_KEY_F01);
	else if KEYRANGE (ks->scancode, SDL_SCANCODE_1, SDL_SCANCODE_9, '1');
	else switch (ks->scancode) {
		case SDL_SCANCODE_0: return SYS_KEY_0;
		case SDL_SCANCODE_HOME: return SYS_KEY_HOME;
		case SDL_SCANCODE_END: return SYS_KEY_END;
		case SDL_SCANCODE_PAGEUP: return SYS_KEY_PGUP;
		case SDL_SCANCODE_PAGEDOWN: return SYS_KEY_PGDN;
		case SDL_SCANCODE_ESCAPE: return SYS_KEY_ESCAPE;
		case SDL_SCANCODE_UP: return SYS_KEY_UP;
		case SDL_SCANCODE_DOWN: return SYS_KEY_DOWN;
		case SDL_SCANCODE_LEFT: return SYS_KEY_LEFT;
		case SDL_SCANCODE_RIGHT: return SYS_KEY_RIGHT;
		case SDL_SCANCODE_SPACE: return SYS_KEY_SPACE;
		default: return 0;
	}
}


static void SdlOnWindowEvent (const SDL_WindowEvent* e)
{
	switch (e->event)
	{
		case SDL_WINDOWEVENT_CLOSE: exit(0); break;
		case SDL_WINDOWEVENT_SIZE_CHANGED:
			FIRE (SysApp.OnSize) (e->data1, e->data2);
		break;
	}
}

static void SdlOnKeyUpEvent (const SDL_KeyboardEvent* e)
{
	FIRE (SysApp.OnKeyUp) (
		SysKeyFromSdl(&e->keysym), SysModsFromSdl()
	);
}

static void SdlOnKeyDownEvent (const SDL_KeyboardEvent* e)
{
	FIRE (SysApp.OnKeyDown) (
		SysKeyFromSdl(&e->keysym), SysModsFromSdl()
	);
}

static void SdlProcessEvent (SDL_Event* e)
{
	switch (e->type)
	{
		case SDL_WINDOWEVENT: SdlOnWindowEvent(&e->window); break;
		case SDL_KEYDOWN: SdlOnKeyDownEvent(&e->key); break;
		case SDL_KEYUP: SdlOnKeyUpEvent(&e->key); break;
	}
}


void SysSetResolution (int w, int h)
{
	SysApp.W = w;
	SysApp.H = h;
	
	if (!Sys.Window) return;
	if (Sys.Buffer) SDL_DestroyTexture(Sys.Buffer);
	
	Sys.Buffer = SDL_CreateTexture (
		Sys.Renderer, SDL_PIXELFORMAT,
		SDL_TEXTUREACCESS_STREAMING, w, h
	);
}

bool SysIsKeyDown (SysKey k)
{
	int s = SdlScanFromSysKey(k);
	if (s == -1) return false;
	return SDL_GetKeyboardState(0)[s];
}

void SysQuit ()
{
	exit(0);
}


int main (int argc, char** argv)
{
	setbuf(stdout, 0);
	SDL_Init(SDL_INIT_VIDEO);
	atexit(SDL_Quit);
	
	int mres = SysApp.OnStart(argc - 1, argv + 1);
	if (mres) return mres;
	
	if (SysApp.Windowed)
	{
		Sys.Window = SDL_CreateWindow (
			SysApp.Title, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
			SysApp.W, SysApp.H, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
		);
	}
	else
	{
		SDL_DisplayMode dm;
		SDL_GetDesktopDisplayMode(0, &dm);
		
		Sys.Window = SDL_CreateWindow (
			SysApp.Title, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
			SysApp.W = dm.w, SysApp.H = dm.h, SDL_WINDOW_SHOWN
		);
		
		SDL_SetRelativeMouseMode(SDL_TRUE);
		SDL_SetWindowFullscreen(Sys.Window, true);
		SDL_ShowCursor(SDL_DISABLE);
	}
	
	Sys.Renderer = SDL_CreateRenderer(Sys.Window, -1, 0);
	
	FIRE (SysApp.OnSize) (SysApp.W, SysApp.H);
	else SysSetResolution(SysApp.W, SysApp.H);
	
	long ncap = SysApp.Rate ? 1000 / SysApp.Rate : 0;
	long time = 0;
	
	for ( SDL_Event e ;; )
	{
		long curt = SDL_GetTicks();
		long elat = curt - time;
		
		if (elat < ncap)
		{
			SDL_Delay(ncap - elat);
			continue;
		}
		
		time = curt;
		
		while (SDL_PollEvent(&e)) SdlProcessEvent(&e);
		
		SDL_RenderClear(Sys.Renderer);
		SDL_LockTexture(Sys.Buffer, 0, (void**) &Sys.Pixels, &Sys.Stride);
		
		FIRE (SysApp.OnPaint) (Sys.Pixels, Sys.Stride, elat / 1000.0);
		
		SDL_UnlockTexture(Sys.Buffer);
		SDL_RenderCopyEx(Sys.Renderer, Sys.Buffer, 0, 0, 0, 0, SDL_FLIP_VERTICAL);
		SDL_RenderPresent(Sys.Renderer);
	}
	
	
	return 0;
}
