using System;
using System.Windows.Forms;

static class Controls
{
	static public void Sync (this Control target, Action act)
	{
		if (target.InvokeRequired) {
			try { target.Invoke(act); }
			catch (InvalidOperationException) { }
		} else act();
	}
}