using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;


class TabKeyMenu : Menu
{
	public readonly Editor E;
	
	Row indentRow = new Row("Indent") { Name = "Indent" };
	Row bothRow = new Row("Auto Indent/Tab") { Name = "Auto" };
	Row tabRow = new Row("Insert Tab") { Name = "InsertTab" };
	
	public TabKeyMenu (Editor editor)
	{
		this.E = editor;
		
		indentRow.Clicked += () => SetFunction(indentRow);
		bothRow.Clicked += () => SetFunction(bothRow);
		tabRow.Clicked += () => SetFunction(tabRow);
		
		Items.Add(indentRow);
		Items.Add(bothRow);
		Items.Add(tabRow);
		
		Opening += (o, e) =>
		{
			E.TabKeyFunctionChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.TabKeyFunctionChanged -= Reveal;
		};
	}
	
	void SetFunction (Row r)
	{
		Editor.DefaultTabKeyFunction = Editor.GlobalTabKeyFunction = r.Name;
	}
	
	void Reveal ()
	{
		Check(r => r.Name == E.TabKeyFunction);
	}
}