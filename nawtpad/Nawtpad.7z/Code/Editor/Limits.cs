using System;

struct Limits : IComparable
{
	public readonly int Start;
	public readonly int End;
	
	public Limits (int s, int e)
	{
		Start = s;
		End = e;
	}
	
	public override string ToString ()
	{
		return Start.ToString() + " — " + End.ToString();
	}
	
	public int CompareTo (object o)
	{
		Limits to = (Limits) o;
		
		if (Start < to.Start) return -1;
		else if (Start > to.Start) return +1;
		else if (End < to.End) return -1;
		else if (End > to.End) return +1;
		else return 0;
	}
	
	static public bool operator == (Limits l1, Limits l2) { return l1.Start == l2.Start && l1.End == l2.End; }
	static public bool operator != (Limits l1, Limits l2) { return !(l1 == l2); }
	
	public override int GetHashCode () { return Start ^ End; }
	public override bool Equals (object o) { return (Limits) o == this; }
}