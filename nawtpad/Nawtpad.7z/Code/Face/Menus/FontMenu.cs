using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;


class FontMenu : Menu
{
	public readonly Editor E;
	
	public FontMenu (Editor editor)
	{
		E = editor;
		
		SuspendLayout();
		
		var sfs = new InstalledFontCollection().Families;
		Array.Sort(sfs, (a, b) => String.Compare(a.Name, b.Name));
		
		foreach (FontFamily f in sfs)
		{
			Row fr = new Row(f.Name) { Name = f.Name };
			fr.Clicked += () => Editor.DefaultFontName = Editor.GlobalFontName = fr.Name;
			Items.Add(fr);
		}
		
		Opening += (o, e) =>
		{
			E.FontNameChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.FontNameChanged -= Reveal;
		};
		
		ResumeLayout();
	}
	
	void Reveal ()
	{
		this.Check(r => E.FontName == r.Name);
	}
}
