using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

class Stexp
{
	List<Bitmap> raws = new List<Bitmap>();
	double[,] Rs, Gs, Bs;
	
	public void Load (string dir)
	{
		foreach (string file in Directory.GetFiles(dir))
		{
			try { raws.Add(new Bitmap(file)); Console.WriteLine("+ " + file); }
			catch (Exception e) { Console.WriteLine("! " + file + " (" + e.Message + ")"); }
		}
	}
	
	public void Compose ()
	{
		int width = raws[0].Width;
		int height = raws[0].Height;
		
		Rs = new double[height, width];
		Gs = new double[height, width];
		Bs = new double[height, width];
		
		int total = width * height;
		int done = 0;
		
		for (int y = 0; y < height; y++)
		{
			for (int x = 0; x < width; x++)
			{
				Rs[y, x] = 0;
				Gs[y, x] = 0;
				Bs[y, x] = 0;
				
				foreach (Bitmap raw in raws)
				{
					Rs[y, x] += (double) raw.GetPixel(x, y).R / 255.0;
					Gs[y, x] += (double) raw.GetPixel(x, y).G / 255.0;
					Bs[y, x] += (double) raw.GetPixel(x, y).B / 255.0;
				}
				
				Rs[y, x] /= raws.Count;
				Gs[y, x] /= raws.Count;
				Bs[y, x] /= raws.Count;
				
				done++;
			}
			
			Console.SetCursorPosition(0, Console.CursorTop);
			double perc = (double) done / (double) total * 100.0;
			Console.Write("Processing... " + Math.Round(perc, 2) + "%    ");
		}
	}
	
	public Bitmap Export (double expo)
	{
		Bitmap bmp = new Bitmap(Rs.GetLength(1), Rs.GetLength(0));
		
		for (int y = 0; y < bmp.Height; y++)
		{
			for (int x = 0; x < bmp.Width; x++)
			{
				double r = Rs[y, x] * expo; if (r > 1) r = 1;
				double g = Gs[y, x] * expo; if (g > 1) g = 1;
				double b = Bs[y, x] * expo; if (b > 1) b = 1;
				
				bmp.SetPixel(x, y, Color.FromArgb(
					(byte) (r * 255), (byte) (g * 255), (byte) (b * 255)
				));
			}
		}
		
		return bmp;
	}
	
	static void Main (string[] args)
	{
		Stexp ms = new Stexp();
		
		if (args.Length == 0) Console.WriteLine("Syntax: Stexp.exe [input folder] [output PNG file] [exposure (default = 1)]");
		
		string input = args.Length > 0 ? args[0] : null;
		string output = args.Length > 1 ? args[1] : null;
		string expo = args.Length > 2 ? args[2] : null;
		
		inputArg: if (input == null) { Console.Write("Input folder: "); input = Console.ReadLine(); }
		
		try { ms.Load(input); }
		catch (Exception e) { Console.WriteLine(e.Message); input = null; goto inputArg; }
		
		ms.Compose();
		
		outputArg: if (output == null) { Console.Write("\nOutput file (png): "); output = Console.ReadLine(); }
		expoArg: if (expo == null) { Console.Write("Exposure (default = 1): "); expo = Console.ReadLine(); }
		
		if (expo.Length >= 1 && expo[0] == 'q' || expo[0] == 'Q') return;
		
		try { ms.Export(double.Parse(expo)).Save(output); }
		catch (Exception e) { Console.WriteLine(e.Message); output = expo = null; goto outputArg; }
		
		if (args.Length < 3)
		{
			Console.Write("Done. [Q]uit? ");
			expo = null; goto expoArg;
		}
	}
}
