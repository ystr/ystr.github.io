using System.Windows.Forms;

class ContextMenu : ContextMenuStrip
{
	public ContextMenu ()
	{
		Renderer = new SimpleRenderer();
	}
	
	public void AddSeparator ()
	{
		Items.Add(new ToolStripSeparator());
	}
	
	class SimpleRenderer : ToolStripProfessionalRenderer
	{
		protected override void OnRenderImageMargin (ToolStripRenderEventArgs e) { }
	}
}