#define SKY_SEGS 64
#define SKY_NEAR -1000


typedef struct {
	
	real Radius;
	real Height;
	
	Rgb Glow;
	Rgb AirFilter;
	
	Rgb ZenFog;
	Rgb TanFog;
	
	fake TanScatter, TanOpacity;
	fake ZenScatter, ZenOpacity;
	
} Sky;

typedef struct {
	
	const Eye* Eye;
	const Pov* Pov;
	const Sky* Sky;
	
	real PovNorm;
	
	const Liting* Liting;
	
} SkyPass;

typedef struct {
	
	Xyz Point;
	
	Xyz VPoint;
	bool Behind;
	bool Shaded;
	Apex Apex;
	
} SkyVert;

typedef struct {
	
	fake Norm;
	fake Dist;
	
	fake Opacity;
	fake Scatter;
	
	SkyVert Verts[SKY_SEGS];
	
} SkyLoop;


void ShadeSky (Syxel* o, Pixel* p, const Apex* a, const SkyPass* s)
{
	fu16 r = o->R * (1 - (1 - s->Sky->AirFilter.R) * a->W) + a->R;
	fu16 g = o->G * (1 - (1 - s->Sky->AirFilter.G) * a->W) + a->G;
	fu16 b = o->B * (1 - (1 - s->Sky->AirFilter.B) * a->W) + a->B;
	
	o->R = r < 0xFF ? r : 0xFF;
	o->G = g < 0xFF ? g : 0xFF;
	o->B = b < 0xFF ? b : 0xFF;
}


void SkyPreVert (SkyVert* a, Xyz v, real rad, fake opa, fake sca, const SkyPass* g)
{
	a->Shaded = false;
	
	a->Point = v;
	a->VPoint = LocProPov(Norm(v, rad), g->Pov);
	
	a->Apex.W = opa;
	a->Apex.R = a->Apex.G = a->Apex.B = sca;
	
	a->Behind = a->VPoint.Z > SKY_NEAR;
}

void SkyShadeVert (SkyVert* v, const SkyPass* g)
{
	v->Shaded = true;
	
	if (!v->Behind)
	{
		v->Apex.X = EyeV2SX(g->Eye, v->VPoint.X, v->VPoint.Z);
		v->Apex.Y = EyeV2SY(g->Eye, v->VPoint.Y, v->VPoint.Z);
	}
	
	v->Apex.Z = v->VPoint.Z;
	
	Xyz up = Norm(v->Point, 1);
	Rgb c = g->Sky->Glow;
	
	for EACHC (const Lamp*, l, g->Liting->Lamps)
	{
		fake zen = Dot(up, l->Point);
		fake twl = powf(1 - fabs(zen), 4) * zen * 20;
		
		if (zen < 0) zen = 0;
		if (twl < 0) twl = 0;
		
		Rgb zamb = RgbMul(RgbRgb(l->Light, g->Sky->ZenFog), zen);
		Rgb tamb = RgbMul(RgbRgb(l->Light, g->Sky->TanFog), twl);
		
		c.R += tamb.R + zamb.R;
		c.G += tamb.G + zamb.G;
		c.B += tamb.B + zamb.B;
	}
	
	v->Apex.R *= c.R * 0xFF;
	v->Apex.G *= c.G * 0xFF;
	v->Apex.B *= c.B * 0xFF;
}

void SkyClip (Apex* c, const SkyVert* f, const Eye* eye, const SkyVert* b)
{
	real zz = Weigh(f->VPoint.Z, c->Z = SKY_NEAR, b->VPoint.Z);
	
	c->X = EyeV2SX(eye, LERP(f->VPoint.X, zz, b->VPoint.X), c->Z);
	c->Y = EyeV2SY(eye, LERP(f->VPoint.Y, zz, b->VPoint.Y), c->Z);
	c->R = LERP(f->Apex.R, zz, b->Apex.R);
	c->G = LERP(f->Apex.G, zz, b->Apex.G);
	c->B = LERP(f->Apex.B, zz, b->Apex.B);
	c->W = LERP(f->Apex.W, zz, b->Apex.W);
}

void SkyRenderTri (SkyVert* v0, SkyVert* v1, SkyVert* v2, const SkyPass* g)
{
	if (v0->Behind && v1->Behind && v2->Behind) return;
	
	if (!v0->Shaded) SkyShadeVert(v0, g);
	if (!v1->Shaded) SkyShadeVert(v1, g);
	if (!v2->Shaded) SkyShadeVert(v2, g);
	
	switch (v0->Behind + v1->Behind + v2->Behind)
	{
		case 0: {
			
			DrawTri (
				g->Eye, (PixelShader*) ShadeSky, g,
				&v0->Apex, &v1->Apex, &v2->Apex
			);
			
		} break;
		
		case 1: {
			
			const SkyVert *f0, *f1, *bk;
			
			if (v0->Behind) bk = v0, f0 = v1, f1 = v2;
			else if (v1->Behind) bk = v1, f0 = v0, f1 = v2;
			else bk = v2, f0 = v0, f1 = v1;
			
			Apex m0; SkyClip(&m0, f0, g->Eye, bk);
			Apex m1; SkyClip(&m1, f1, g->Eye, bk);
			
			DrawTri(g->Eye, (PixelShader*) ShadeSky, g, &f0->Apex, &f1->Apex, &m0);
			DrawTri(g->Eye, (PixelShader*) ShadeSky, g, &f1->Apex, &m1, &m0);
			
		} break;
		
		case 2: {
			
			const SkyVert *fr, *b0, *b1;
			
			if (v0->Behind && v1->Behind) fr = v2, b0 = v0, b1 = v1;
			else if (v1->Behind && v2->Behind) fr = v0, b0 = v1, b1 = v2;
			else fr = v1, b0 = v0, b1 = v2;
			
			Apex m0; SkyClip(&m0, fr, g->Eye, b0);
			Apex m1; SkyClip(&m1, fr, g->Eye, b1);
			
			DrawTri(g->Eye, (PixelShader*) ShadeSky, g, &fr->Apex, &m0, &m1);
			
		} break;
	}
}

void RenderSky (const SkyPass* g)
{
	const Sky* s = g->Sky;
	
	fake sb = s->Radius - Max ( s->Height,
		Min (
			Max(0, g->PovNorm - s->Radius),
			s->Radius * 0.125
		)
	);
	
	fake sg = s->Radius;
	fake st = s->Radius + s->Height;
	
	fake deep = pow(1 - Clamp(0, Weigh(sg, g->PovNorm, st), 1), 16);
	
	SkyLoop loops [] = {
		{ .Norm = sb, .Dist = 1, .Opacity = s->TanOpacity, .Scatter = s->TanScatter },
		{ .Norm = sg, .Dist = 1, .Opacity = s->TanOpacity, .Scatter = s->TanScatter },
		{ .Norm = st, .Dist = 1, .Opacity = deep * Lerf(s->TanOpacity, 0, s->ZenOpacity), .Scatter = deep * Lerf(s->TanScatter, 0, s->ZenScatter) },
		{ .Norm = st, .Dist = 0.2, .Opacity = deep * Lerf(s->TanOpacity, 0.5, s->ZenOpacity), .Scatter = deep * Lerf(s->TanScatter, 0.5, s->ZenScatter) },
		{ .Norm = st, .Dist = 0.05, .Opacity = deep * Lerf(s->TanOpacity, 0.75, s->ZenOpacity), .Scatter = deep * Lerf(s->TanScatter, 0.75, s->ZenScatter) },
	};
	
	int loopsCount = deep ? ALEN(loops) : 3;
	Rot at = Look(Norm(g->Pov->Loc, 1));
	
	for EACHC (SkyLoop*, l, loops)
	{
		real pn = Max(g->PovNorm, l->Norm + s->Height);
		
		real tr = AltCH(l->Norm, pn) * l->Dist;
		real tz = CatCH(tr, l->Norm);
		
		for (int ci = 0; ci < SKY_SEGS; ci++)
		{
			real ca = ci * (TAU / SKY_SEGS);
			Xy c = { cos(ca), sin(ca) };
			Xyz v = (Xyz){ c.X * tr, c.Y * tr, tz };
			
			SkyPreVert(l->Verts + ci, XyzRot(v, at), l->Norm, l->Opacity, l->Scatter, g);
		}
	}
	
	for (int si0 = 0, si1 = 1; si1 < loopsCount; si0++, si1++)
	for (int ci0 = 0, ci1 = 1; ci0 < SKY_SEGS; ci0++, ci1++)
	{
		if (ci1 >= SKY_SEGS) ci1 = 0;
		
		SkyVert* s0c0 = &loops[si0].Verts[ci0], *s0c1 = &loops[si0].Verts[ci1];
		SkyVert* s1c0 = &loops[si1].Verts[ci0], *s1c1 = &loops[si1].Verts[ci1];
		
		SkyRenderTri(s0c0, s1c1, s1c0, g);
		SkyRenderTri(s0c0, s0c1, s1c1, g);
	}
	
	if (!deep) return;
	
	SkyVert top;
	SkyPreVert(&top, g->Pov->Loc, st, deep * s->ZenOpacity, deep * s->ZenScatter, g);
	
	for (int ci0 = 0, ci1 = 1; ci0 < SKY_SEGS; ci0++, ci1++)
	{
		if (ci1 >= SKY_SEGS) ci1 = 0;
		const int si0 = loopsCount - 1;
		
		SkyVert* a0 = &loops[si0].Verts[ci1];
		SkyVert* a1 = &loops[si0].Verts[ci0];
		
		SkyRenderTri(a0, &top, a1, g);
	}
}
