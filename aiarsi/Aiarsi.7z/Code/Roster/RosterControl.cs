using System;
using System.Drawing;
using System.Windows.Forms;

abstract class RosterControl : Panel
{
	public int LinearIndex;
	
	bool selected = false;
	public event Action SelectedChanged = () => {};
	public bool Selected {
		get { return selected; }
		set { selected = value; Colorize(); SelectedChanged(); }
	}
	
	protected Color NormalFore = SystemColors.WindowText;
	protected Color NormalBack = Color.Transparent;
	protected Color SelectedFore = SystemColors.HighlightText;
	protected Color SelectedBack = SystemColors.Highlight;
	
	protected void Colorize ()
	{
		if (selected) {
			TitleLable.ForeColor = SelectedFore;
			if (Extra.IsAppThemed()) BackColor = SelectedBack;
			else TitleLable.BackColor = SelectedBack;
		} else {
			TitleLable.ForeColor = NormalFore;
			if (Extra.IsAppThemed()) BackColor = NormalBack;
			else TitleLable.BackColor = NormalBack;
		}
	}
	
	protected Table Frame = new Table();
	protected Lable TitleLable;
	
	public RosterControl (string title)
	{
		AutoSize = true;
		
		TitleLable = new Lable(title);
		TitleLable.TextAlign = ContentAlignment.MiddleCenter;
		TitleLable.Margin = new Padding(0);
		TitleLable.AutoSize = false;
		TitleLable.AutoEllipsis = true;
		
		TitleLable.MouseDown += (o, e) => DirectlySelected();
		TitleLable.DoubleClick += (o, e) => DoubleClicked();
		
		Frame[1] = TitleLable;
		
		Frame.AutoSize = true;
		Frame.Dock = DockStyle.Bottom;
		
		Frame.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 24));
		Frame.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
		Frame.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 24));
		Frame.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 24));
		
		Controls.Add(Frame);
	}
	
	public void SelectDirectly () { DirectlySelected(); }
	public event Action DirectlySelected = () => {};
	public event Action DoubleClicked = () => {};
	
	public abstract void Key (KeyEventArgs e);
	
	protected void StartRedraw () { RedrawStarted(); }
	protected void FinishRedraw () { RedrawFinished(); }
	
	public event Action RedrawStarted = () => {};
	public event Action RedrawFinished = () => {};
}