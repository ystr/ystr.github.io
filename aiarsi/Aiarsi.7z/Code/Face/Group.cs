using System;
using System.Drawing;
using System.Windows.Forms;

class Group : GroupBox
{
	readonly string title;
	void Localize () { Text = Own.Line(title); }
	
	public Group (string title)
	{
		this.title = title;
		AutoSize = true;
		Padding = new Padding(10);
		Own.LocaleChanged += Localize;
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}