void SetPeriod (int t)
{
	if (!Timer) Timer = SetTimer(0, 1, t, 0);
	SetTimer(WinHandle, Timer, t, 0);
}

void ShowFrame (int n)
{
	Frame = n;
	
	Source->SelectActiveFrame(&FDID, Frame);
	
	SourceToScreen();
	ScreenToWindow();
}

void NextFrame (int de)
{
	Frame += de;
	
	if (Frame >= FrameCount) Frame = 0;
	else if (Frame < 0) Frame = FrameCount - 1;
	
	if (Animate && FrameCount > 1) SetPeriod(FrameTimes[Frame]);
	
	ShowFrame(Frame);
}

void StopAnimation ()
{
	if (Timer)
	{
		KillTimer(WinHandle, Timer);
		Timer = 0;
	}
}

void ApplyAnimation ()
{
	if (Animate && FrameCount > 1) SetPeriod(FrameTimes[Frame]);
	else StopAnimation();
}

void ToggleAnimation ()
{
	Animate = !Animate;
	ApplyAnimation();
	if (!Animate) ShowIcon();
}
