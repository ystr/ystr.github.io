class Uninstaller
{
	static void Main (string[] args)
	{
		Deployment.Uninstaller.Auto("Types", args);
	}
}