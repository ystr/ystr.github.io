using System.Windows.Forms;


class ViewMenu : Menu
{
	public readonly Face F;
	public readonly Editor E;
	
	Row toolbarRow = new Row("&Toolbar", "F11");
	Row statusbarRow = new Row("&Statusbar", "F12");
	Row guidesRow = new Row("&Indentation Guides");
	Row numbersRow = new Row("&Line Numbers", "F9");
	Row braceMatchingRow = new Row("&Brace Matching");
	Row wrapRow = new Row("&Wrap", "Ctrl W");
	Row spaceRow = new Row("Whitespace", "Ctrl I");
	Row zoomInRow = new Row("Zoom &In", "Ctrl +");
	Row zoomOutRow = new Row("Zoom &Out", "Ctrl -");
	Row resetZoomRow = new Row("&Reset Zoom", "Ctrl 0");
	
	public ViewMenu (Face f)
	{
		F = f;
		E = F.E;
		
		numbersRow.Clicked += () => E.Numbers = !E.Numbers;
		guidesRow.Clicked += () => E.Guides = !E.Guides;
		wrapRow.Clicked += () => E.Wrap =! E.Wrap;
		spaceRow.Clicked += () => E.ShowSpace =! E.ShowSpace;
		statusbarRow.Clicked += () => F.ShowStatusbar.Value =! F.ShowStatusbar.Value;
		zoomInRow.Clicked += F.ZoomIn;
		zoomOutRow.Clicked += F.ZoomOut;
		resetZoomRow.Clicked += F.ResetZoom;
		toolbarRow.Clicked += () => F.ShowToolbar.Value =! F.ShowToolbar.Value;
		braceMatchingRow.Clicked += () => E.BraceMatching = !E.BraceMatching;
		
		Items.Add(toolbarRow);
		Items.Add(statusbarRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(numbersRow);
		Items.Add(guidesRow);
		Items.Add(braceMatchingRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(wrapRow);
		Items.Add(spaceRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(zoomInRow);
		Items.Add(zoomOutRow);
		Items.Add(resetZoomRow);
		
		Opening += (o, e) =>
		{
			E.GuidesChanged += Reveal;
			E.NumbersChanged += Reveal;
			E.WrapChanged += Reveal;
			E.ShowSpaceChanged += Reveal;
			F.ShowToolbar.Changed_ += Reveal;
			F.ShowStatusbar.Changed_ += Reveal;
			E.BraceMatchingChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.GuidesChanged -= Reveal;
			E.NumbersChanged -= Reveal;
			E.WrapChanged -= Reveal;
			E.ShowSpaceChanged -= Reveal;
			F.ShowToolbar.Changed_ -= Reveal;
			F.ShowStatusbar.Changed_ -= Reveal;
			E.BraceMatchingChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		guidesRow.Checked = E.Guides;
		guidesRow.Enabled =! E.ShowSpace;
		numbersRow.Checked = E.Numbers;
		wrapRow.Checked = E.Wrap;
		spaceRow.Checked = E.ShowSpace;
		toolbarRow.Checked = F.ShowToolbar.Value;
		statusbarRow.Checked = F.ShowStatusbar.Value;
		braceMatchingRow.Checked = E.BraceMatching;
	}
}