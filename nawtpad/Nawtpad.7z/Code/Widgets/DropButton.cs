using System;
using System.Drawing;
using System.Windows.Forms;


class DropButton : ToolStripDropDownButton
{
	public event Action Clicked = () => {};
	
	string text;
	public new string Text {
		get { return text; }
		set { text = value; Localize(); }
	}
	
	void Localize ()
	{
		base.Text = Own.Line(text.Replace("&", ""));
	}
	
	public DropButton (string text)
	{
		this.text = text;
		
		AutoToolTip = false;
		ShowDropDownArrow = false;
		
		Own.LocaleChanged += Localize;
		Own.SkinChanged += Localize;
		
		Localize();
		
		Click += (o, e) => Clicked();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.SkinChanged -= Localize;
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}