using System;
using System.Drawing;
using System.Windows.Forms;

class Splitter : SplitContainer
{
	int FullLength { get { switch (Orientation) {
		case Orientation.Vertical: return Width;
		default: case Orientation.Horizontal: return Height;
	} } }
	
	public int RightPosition
	{
		get { return FullLength - SplitterDistance; }
		set { SplitterDistance = FullLength - value; }
	}
}