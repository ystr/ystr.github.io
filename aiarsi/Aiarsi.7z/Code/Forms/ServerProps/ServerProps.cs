using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

abstract class ServerTab : Tab
{
	public readonly Server Server;
	public ServerTab (Server s, string title) : base (title) { Server = s; }
	public abstract void Save (Server s);
}

class ServerProps : UtilityWindow
{
	public readonly Server Server;
	
	readonly TabControl tabs = new TabControl();
	
	MainTab mainTab;
	PerformTab performTab;
	
	Table footerTable = new Table(0, 100, 0);
	Knob saveButton = new Knob("Save");
	Lable nameLable = new Lable("Title:");
	Field nameField = new Field();
	
	void Skinize () { Icon = Own.Icon(Server == null ? "AddServer" : "ServerProps"); }
	void Localize () { Text = Server == null ? Own.Line("New Server") : Server.Title; }
	
	public ServerProps (Server s) : base (s == null ? "Windows\\AddServer" : "Servers\\" + s.ID + "\\Settings")
	{
		Server = s;
		
		mainTab = new MainTab(Server, "Main");
		performTab = new PerformTab(Server, "Perform");
		
		Skinize(); Own.SkinChanged += Skinize;
		Localize(); Own.LocaleChanged += Localize;
		
		Size = new Size(300, 400);
		
		tabs.Dock = DockStyle.Top;
		Controls.Add(tabs);
		
		tabs.Controls.Add(mainTab);
		tabs.Controls.Add(performTab);
		
		footerTable.Dock = DockStyle.Bottom;
		Controls.Add(footerTable);
		
		nameField.AllowEmpty = false;
		saveButton.Height = nameField.Height;
		saveButton.Click += (o, e) => { Save(); };
		
		footerTable.Put(nameLable, nameField, saveButton);
		
		tabs.Height = footerTable.Top - tabs.Top - 10;
		
		if (Server != null)
		{
			nameField.Text = Server.Title;
			Server.Terminated += Close;
		}
		
		nameField.Check();
		mainTab.Check();
		
		nameField.Checked += Check;
		mainTab.Checked += Check;
		
		mainTab.Submitted += Submit;
		performTab.Submitted += Submit;
		nameField.Submitted += Submit;
		
		Check();
	}
	
	protected override void Dispose (bool disposing)
	{
		if (Server != null) Server.Terminated -= Close;
		Own.SkinChanged -= Skinize;
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
	
	bool Okay
	{
		get {
			return (
				nameField.Okay &&
				mainTab.Okay
			);
		}
	}
	
	void Check ()
	{
		saveButton.Enabled = Okay;
	}
	
	void Submit ()
	{
		if (Okay) Save();
	}
	
	void Save ()
	{
		bool add = (Server == null);
		Server s = add ? new Server(null) : Server;
		
		s.Title = nameField.Text;
		
		if (add) Server.Add(s);
		
		mainTab.Save(s);
		performTab.Save(s);
		
		Close();
	}
	
	public static void Open (Server s)
	{
		if (s == null) new ServerProps(s).Show();
		if (!Open("Servers\\" + s.ID + "\\Settings")) Open(new ServerProps(s));
	}
	
	public static void New ()
	{
		new ServerProps(null).Show();
	}
}
