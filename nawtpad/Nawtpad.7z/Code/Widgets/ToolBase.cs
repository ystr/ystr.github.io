using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;


class ToolBase : ToolStrip
{
	public ToolBase ()
	{
		Padding = new Padding(2, 1, 2, 1);
		GripStyle = ToolStripGripStyle.Hidden;
		BackColor = Color.Transparent;
		CanOverflow = false;
		
		#if WIN32
			OS.ThemeChanged += SetStyle;
			SetStyle();
		#endif
	}
	
	protected override void Dispose (bool disposing)
	{
		OS.ThemeChanged -= SetStyle;
		base.Dispose(disposing);
	}
	
	void SetStyle ()
	{
		if (Application.RenderWithVisualStyles) Renderer = new ModernRenderer();
		else Renderer = new ClassicRenderer();
	}
	
	class ModernRenderer : ToolStripSystemRenderer
	{
		protected override void OnRenderToolStripBackground (ToolStripRenderEventArgs e)
		{
			
		}
		
		protected override void OnRenderToolStripBorder (ToolStripRenderEventArgs e)
		{
			//using (Pen p = new Pen(SystemColors.ControlLight.Rip()))
			//{
				//e.Graphics.DrawLine (
					//p, e.AffectedBounds.X, e.AffectedBounds.Height - 1,
					//e.AffectedBounds.Width, e.AffectedBounds.Height - 1
				//);
			//}
		}
	}
	
	class ClassicRenderer : ToolStripSystemRenderer
	{
		protected override void OnRenderToolStripBorder (ToolStripRenderEventArgs e) { }
	}
	
	protected override void WndProc (ref Message m)
	{
		if (m.Msg == 0x21 && CanFocus && !(Parent as Window).Active) Focus();
		base.WndProc(ref m);
	}
}
