using System.Reflection;

[assembly: AssemblyProduct("ContextReplace")]
[assembly: AssemblyVersion("0.3.1.*")]
[assembly: AssemblyInformationalVersion("0.3.1")]
[assembly: AssemblyCompany("ES")]