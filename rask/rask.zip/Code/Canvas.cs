using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

class Canvas : Panel
{
	Frame frame;
	
	public Frame Frame
	{
		get { return frame; }
		set { frame = value; Invalidate(); }
	}
	
	public Canvas (Frame frame)
	{
		this.frame = frame;
		
		DoubleBuffered = true;
		ResizeRedraw = true;
		BackColor = Color.White;
	}
	
	enum Mode { Nothing, Drawing, Erasing };
	Mode mode = Mode.Nothing;
	
	Point? delStart = null;
	Rectangle? delArea = null;
	Pen delPen = new Pen(Color.Red);
	
	float FX (int x) { return (float) x / ClientSize.Width; }
	float FY (int y) { return (float) y / ClientSize.Height; }
	
	RectangleF F (Rectangle r) {
		return new RectangleF(FX(r.Left), FY(r.Top), FX(r.Width), FY(r.Height));
	}
	
	protected override void OnMouseDown (MouseEventArgs e)
	{
		switch (e.Button)
		{
			case MouseButtons.Left: {
				mode = Mode.Drawing;
				frame.StartStroke(FX(e.X), FY(e.Y));
			} break;
			
			case MouseButtons.Right: {
				mode = Mode.Erasing;
				delStart = new Point(e.X, e.Y);
			} break;
		}
	}
	
	protected override void OnMouseMove (MouseEventArgs e)
	{
		switch (mode)
		{
			case Mode.Drawing: {
				frame.DrawTo(FX(e.X), FY(e.Y));
			} break;
			
			case Mode.Erasing: {
				delArea = new Rectangle(
					Math.Min(e.X, delStart.Value.X), Math.Min(e.Y, delStart.Value.Y),
					Math.Abs(delStart.Value.X  - e.X), Math.Abs(delStart.Value.Y - e.Y)
				);
			} break;
			
			default: return;
		}
		
		Invalidate();
	}
	
	protected override void OnMouseUp (MouseEventArgs e)
	{
		switch (mode)
		{
			case Mode.Drawing: {
				frame.EndStroke();
			} break;
			
			case Mode.Erasing: {
				
				frame.EraseArea(F(delArea.Value));
				
				delStart = null;
				delArea = null;
				
				Invalidate();
				
			} break;
			
			default: return;
		}
		
		frame.Commit();
		mode = Mode.Nothing;
	}
	
	protected override void OnPaint (PaintEventArgs e)
	{
		frame.Draw(e.Graphics, new Rectangle(0, 0, ClientSize.Width, ClientSize.Height), ForeColor);
		if (delArea != null) e.Graphics.DrawRectangle(delPen, delArea.Value);
	}
}
