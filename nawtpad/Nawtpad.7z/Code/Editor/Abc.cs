using System.Collections.Generic;
using System.Reflection;

static class Abc
{
	static readonly Dictionary<char, string> abbrs = new Dictionary<char, string>();
	
	static Abc ()
	{
		foreach (FieldInfo fi in typeof(Abc).GetFields())
		{
			if (
				fi.IsLiteral && !fi.IsInitOnly // is const
				&& fi.FieldType == typeof(char) && fi.IsPublic
			) {
				abbrs[fi.GetRawConstantValue().ToString()[0]] = fi.Name;
			}
		}
	}
	
	public static string GetCode (this char c)
	{
		return ((int)c).ToString("X4");
	}
	
	public static string GetAbbr (this char c)
	{
		if (abbrs.ContainsKey(c)) return abbrs[c];
		else return null;
	}
	
	public static string GetCodeOrAbbr (this char c)
	{
		string abbr = Abc.GetAbbr(c);
		if (abbr != null) return abbr;
		return Abc.GetCode(c);
	}
	
	// Newline:
	
	public const char CR = '\r'; // Carriage Return
	public const char LF = '\n'; // Line Feed
	public const char FF = '\u000C'; // Form Feed
	public const char NEL = '\u0085'; // Next Line
	public const char VT = '\u000B'; // Vertical Tab
	public const char LS = '\u2028'; // Line Separator
	public const char PS = '\u2029'; // Paragraph Separator
	
	// Breaking visible spaces:
	
	public const char SP = ' '; // Guess what
	public const char HT = '\t'; // Horizontal Tab
	
	// Non-breaking visible spaces:
	
	public const char NBSP = '\u00A0'; // Non-Breaking Space
	public const char NNBSP = '\u202F'; // Narrow Non-Breaking Space
	public const char FSP = '\u2007'; // Figure Space
	
	// Zero-width breakers:
	
	public const char WJ = '\u202F'; // Word Joiner
	public const char ZWSP = '\u200B'; // Zero-Width Space
	public const char ZWNJ = '\u200C'; // Zero-Width Non-Joiner
	public const char SHY = '\u00AD'; // Soft Hyphen
	
	// Control:
	
	public const char BS = '\u0008'; // Backspace
	
	// Delimiters:
	
	public const char FD = '\u001C'; // File Separator
	public const char GS = '\u001D'; // Group Separator
	public const char RS = '\u001E'; // Record Separator
	public const char US = '\u001F'; // Unit Separator
}