using System;

abstract partial class Chat : Terminal
{
	public readonly string ID;
	public readonly string Name;
	
	public readonly Server Server;
	public readonly Options Options;
	
	
	public Chat (Server s, string opDir, string name)
	{
		Server = s;
		
		ID = name.ToID();
		Options = Server.Options.Open(opDir + "\\" + Options.Escape(ID));
		Name = Options.Get("Name", name);
		
		Server.TitleChanged += SetWriter;
		Log.UnreadChanged += Server.ScanUnreadItems;
		
		SetWriter();
	}
	
	
	
	void SetWriter ()
	{
		Log.LogFile = Server.Title.EscapeFileName() + "\\" + Name.EscapeFileName() + ".log";
	}
	
	
	public void Say (string text)
	{
		try { Server.Send("PRIVMSG " + Name + " :" + text); }
		catch (Irc.TooLongException) { text.Chop(Say); }
	}
	
	public void SayAction (string text)
	{
		try { Server.Send(Line.Make("PRIVMSG", Name, Line.Ctcp("ACTION " + text))); }
		catch (Irc.TooLongException) { text.Chop(SayAction); }
	}
	
	
	protected bool Highlight (string title, string line)
	{
		if (
			(Settings.HighlightNick && line.Contains(Server.CurrentNick, true)) ||
			line.Contains(Settings.HighlightWords, true)
		) {
			this.Announce(NotifyType.Info, title, line);
			Log.Unread |= Unread.Important;
			return true;
		} else return false;
	}
	
	
	protected bool watch;
	public event Action WatchChanged = () => {};
	public bool Watch {
		get { return watch; }
		set { Options.Set("Watch", watch = value); WatchChanged(); }
	}
	
	
	public override void Send (Slash s)
	{
		switch (s.Command)
		{
			case "ME": SayAction(s.All); break;
			default: Server.Send(s); break;
		}
	}
	
	public override void Send (string line)
	{
		if (Slash.IsIt(line)) Send(new Slash(line));
		else Say(line);
	}
	
	
	public override void ProcessOutgoing (Line l)
	{
		switch (l.Command)
		{
			case Irc.PRIVMSG: {
				
				Entry e;
				
				if (l.CtcpCommand == "ACTION") {
					e = new Entry(LogTag.OutgoingAction);
					e.Add(Server.CurrentNick + " " + l.CtcpMessage);
				} else if (l.CtcpPlain != null) break;
				else {
					e = new Entry(LogTag.OutgoingSpeech);
					e.Add(Style.Get("OutgoingSpeechFrom"), Server.CurrentNick);
					e.Add(Style.Get("OutgoingSpeechSeparator"), ": ");
					e.Add(Style.Get("OutgoingSpeechBody"), l.Postfix);
				}
				
				Log.Push(e);
				
			} break;
		}
	}
	
	public override void ProcessIncoming (Line l)
	{
		switch (l.Command)
		{
			case Irc.PRIVMSG: {
				
				Entry e;
				string msg;
				
				if (l.CtcpCommand == "ACTION") {
					e = new Entry(LogTag.IncomingAction);
					msg = l.CtcpMessage;
					e.Add(l.From + " " + msg);
				} else if (l.CtcpPlain != null) break;
				else {
					e = new Entry(LogTag.IncomingSpeech);
					msg = l.Postfix;
					e.Add(Style.Get("IncomingSpeechFrom"), l.From);
					e.Add(Style.Get("IncomingSpeechSeparator"), ": ");
					e.Add(Style.Get("IncomingSpeechBody"), msg);
				}
				
				if (!Highlight(l.From, msg) && watch
				) {
					this.Announce(NotifyType.Info, l.From, msg);
					Log.Unread |= Unread.Important;
				}
				
				Log.Unread |= Unread.Message;
				Log.Push(e);
				
			} break;
		}
	}
}