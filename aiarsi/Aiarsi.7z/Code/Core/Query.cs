using System;
using System.Collections.Generic;

class Query : Chat
{
	bool keep = false;
	public event Action KeepChanged = () => {};
	public bool Keep {
		get { return keep; }
		set { Options.Set("Keep", keep = value); KeepChanged(); }
	}
	
	public Query (Server s, string name) : base (s, "Queries", name)
	{
		keep = Options.Get("Keep", false);
		watch = Options.Get("Watch", Settings.WatchNewQueries);
	}
	
	public void Terminate () { Terminated(); }
	public event Action Terminated = () => {};
	
	public override void ProcessIncoming (Line il)
	{
		switch (il.Command)
		{
			case Irc.ERR_NOSUCHNICK:
				Log.Push(LogTag.Error, il.Postfix);
			break;
			
			case Irc.QUIT:
				Log.Push(LogTag.Quit, "%0 quit (%1)", il.From, il.Postfix);
			break;
			
			case Irc.NICK:
				Log.Push(LogTag.Name, "%0 is now known as %1", il.From, il.Postfix);
			break;
			
			case Irc.RPL_AWAY:
				Log.Push(LogTag.Info, "%0 is away (%1)", il.Args[1], il.Postfix);
			break;
		}
		
		base.ProcessIncoming(il);
	}
}