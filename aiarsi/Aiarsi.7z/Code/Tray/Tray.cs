using System;
using System.Drawing;
using System.Windows.Forms;

static class Tray
{
	public static void Initialize ()
	{
		icon = new NotifyIcon();
		icon.Visible = true;
		
		Skinize();
		Own.SkinChanged += Skinize;
		
		menu = new TrayMenu();
		icon.ContextMenuStrip = menu;
		
		icon.MouseClick += (o, e) =>
		{
			if (e.Button != MouseButtons.Left) Notify.ClearAsterisks();
			else if (Notify.Asterisks == 0) {
				if (Roster.The == null) Roster.ShowRoster();
				else if (
					Roster.The.Minimized || (
						!Settings.CloseToTray && (
							!Settings.ShowMinimizeButton || Settings.InTaskbar
						)
					)
				) Roster.CloseToTray();
				else Roster.The.Summon();
			} else if (Notify.Asterisks == 1) Notify.InvokeAsterisk();
			else if (Notify.Asterisks >= 2) {
				if (Roster.The == null) Roster.ShowRoster();
				else Roster.The.Summon();
			}
		};
		
		icon.BalloonTipClicked += (o, e) => Notify.InvokeAsterisk();
		
		Notify.AsterisksChanged += RevealIcon;
		
		Settings.Changed += ApplySettings;
		ApplySettings();
	}
	
	static NotifyIcon icon;
	static TrayMenu menu;
	
	static Icon normalIcon;
	static Icon asteriskIcon;
	static Icon asterisksIcon;
	
	static void Skinize ()
	{
		normalIcon = Own.Icon("Main");
		asteriskIcon = Own.Icon("Asterisk");
		asterisksIcon = Own.Icon("Asterisks");
		
		RevealIcon();
	}
	
	static void RevealIcon ()
	{
		if (Notify.Asterisks == 0) icon.Icon = normalIcon;
		else if (Notify.Asterisks == 1) icon.Icon = asteriskIcon;
		else if (Notify.Asterisks >= 2) icon.Icon = asterisksIcon;
	}
	
	static void ApplySettings ()
	{
		icon.Text = Settings.RosterTitle;
	}
	
	public static void ShowBalloon (NotifyType type, string title, string text)
	{
		icon.BalloonTipTitle = title;
		icon.BalloonTipText = text;
		
		switch (type)
		{
			case NotifyType.Error: icon.BalloonTipIcon = ToolTipIcon.Error; break;
			case NotifyType.Problem: icon.BalloonTipIcon = ToolTipIcon.Warning; break;
			default: icon.BalloonTipIcon = ToolTipIcon.Info; break;
		}
		
		icon.ShowBalloonTip(8000);
	}
	
	public static void Exit ()
	{
		icon.Visible = false;
		menu.Dispose();
	}
}