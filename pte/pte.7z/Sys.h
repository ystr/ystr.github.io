#ifndef SYS_H
#define SYS_H


#include <stdbool.h>
#include <stdint.h>


typedef int8_t s8; typedef uint8_t u8;
typedef int16_t s16; typedef uint16_t u16;
typedef int32_t s32; typedef uint32_t u32;
typedef int_fast8_t fs8; typedef uint_fast8_t fu8;
typedef int_fast16_t fs16; typedef uint_fast16_t fu16;
typedef int_fast32_t fs32; typedef uint_fast32_t fu32;
typedef int_least8_t ls8; typedef uint_least8_t lu8;
typedef int_least16_t ls16; typedef uint_least16_t lu16;
typedef int_least32_t ls32; typedef uint_least32_t lu32;
typedef unsigned char uchar; typedef signed char schar;
typedef unsigned short ushort; typedef signed short sshort;
typedef unsigned int uint; typedef signed int sint;
typedef unsigned long ulong; typedef signed long slong;


typedef enum {
	SYS_KEY_A = 'A', SYS_KEY_B = 'B', SYS_KEY_C = 'C', SYS_KEY_D = 'D',
	SYS_KEY_E = 'E', SYS_KEY_F = 'F', SYS_KEY_G = 'G', SYS_KEY_H = 'H',
	SYS_KEY_I = 'I', SYS_KEY_J = 'J', SYS_KEY_K = 'K', SYS_KEY_L = 'L',
	SYS_KEY_M = 'M', SYS_KEY_N = 'N', SYS_KEY_O = 'O', SYS_KEY_P = 'P',
	SYS_KEY_Q = 'Q', SYS_KEY_R = 'R', SYS_KEY_S = 'S', SYS_KEY_T = 'T',
	SYS_KEY_U = 'U', SYS_KEY_V = 'V', SYS_KEY_W = 'W', SYS_KEY_X = 'X',
	SYS_KEY_Y = 'Y', SYS_KEY_Z = 'Z', SYS_KEY_0 = '0', SYS_KEY_1 = '1',
	SYS_KEY_2 = '2', SYS_KEY_3 = '3', SYS_KEY_4 = '4', SYS_KEY_5 = '5',
	SYS_KEY_6 = '6', SYS_KEY_7 = '7', SYS_KEY_8 = '8', SYS_KEY_9 = '9',
	SYS_KEY_SPACE = ' ', SYS_KEY_ENTER = '\n', SYS_KEY_TAB = '\t',
	SYS_KEY_ESCAPE = 0x1B, SYS_KEY_BACKSPACE = '\b', SYS_KEY_DELETE = 0x7F,
	SYS_KEY_HOME = 'h', SYS_KEY_PGUP = 'p', SYS_KEY_PGDN = 'n', SYS_KEY_END = 'x',
	SYS_KEY_UP = 'u', SYS_KEY_DOWN = 'd', SYS_KEY_LEFT = 'l', SYS_KEY_RIGHT = 'r',
	SYS_KEY_CTRL = '^', SYS_KEY_ALT = '*', SYS_KEY_SHIFT = '$',
	SYS_KEY_F01 = 0xF1, SYS_KEY_F02 = 0xF2, SYS_KEY_F03 = 0xF3,
	SYS_KEY_F04 = 0xF4, SYS_KEY_F05 = 0xF5, SYS_KEY_F06 = 0xF6,
	SYS_KEY_F07 = 0xF7, SYS_KEY_F08 = 0xF8, SYS_KEY_F09 = 0xF9,
	SYS_KEY_F10 = 0xFA, SYS_KEY_F11 = 0xFB, SYS_KEY_F12 = 0xFC,
} SysKey;

typedef enum {
	SYS_CTRL = 0x0100,
	SYS_SHIFT = 0x0200,
	SYS_ALT = 0x0400
} SysMods;


typedef struct { u8 R, G, B, A; } Syxel;
typedef void SysPaintFun (Syxel*, int stride, double dt);
typedef int SysMainFun (int argc, char** argv);
typedef void SysKeyFun (SysKey, SysMods);
typedef void SysSizeFun (int w, int h);
typedef void SysFun ();


void SysSetResolution (int w, int h);
bool SysIsKeyDown (SysKey);
void SysQuit ();


extern struct SysApp {
	
	bool Windowed;
	const char* const Title;
	
	int Rate;
	int W, H;
	
	SysMainFun* OnStart;
	SysKeyFun* OnKeyDown;
	SysKeyFun* OnKeyUp;
	SysPaintFun* OnPaint;
	SysSizeFun* OnSize;
	SysFun* OnClose;
	
} SysApp;


#endif
