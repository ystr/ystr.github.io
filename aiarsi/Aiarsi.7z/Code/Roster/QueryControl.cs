using System;
using System.Drawing;
using System.Windows.Forms;

class QueryControl : ChatControl
{
	public readonly Query Query;
	
	ContextMenu menu = new ContextMenu();
	MenuRow showRow = new MenuRow("Query", "Open", "Enter", true);
	MenuRow deleteRow = new MenuRow("Delete", "Delete", "Del");
	
	RosterKnob keepKnob = new RosterKnob("K", "Keep in list");
	RosterKnob deleteKnob = new RosterKnob("×", "Delete", "Del");
	
	public QueryControl (ServerControl parent, Query q) : base (parent, q, q.Name)
	{
		Query = q;
		
		Frame[2] = keepKnob;
		Frame[3] = deleteKnob;
		
		ContextMenuStrip = menu;
		menu.Items.Add(showRow);
		menu.Items.Add(deleteRow);
		
		DoubleClicked += ShowCom;
		keepKnob.Clicked += ToggleKeep;
		deleteKnob.Clicked += Delete;
		showRow.Clicked += ShowCom;
		deleteRow.Clicked += Delete;
		
		Query.KeepChanged += SyncReveal;
		
		Reveal();
	}
	
	protected override void Dispose (bool d)
	{
		Query.KeepChanged -= SyncReveal;
		base.Dispose(d);
	}
	
	void SyncReveal () { this.Sync(Reveal); }
	void Reveal ()
	{
		keepKnob.Checked = Query.Keep;
	}
	
	void ShowCom ()
	{
		QueryCom.Open(Query);
	}
	
	void ToggleKeep ()
	{
		Query.Keep = !Query.Keep;
	}
	
	void Delete ()
	{
		Query.Server.ZapQuery(Query);
	}
	
	public override void Key (KeyEventArgs e)
	{
		switch (e.KeyCode)
		{
			case Keys.K: ToggleKeep(); break;
			case Keys.Enter: ShowCom(); break;
			case Keys.Apps: ContextMenuStrip.Show(this, new Point(0, 0)); break;
			case Keys.Delete: Delete(); break;
			default: Parent.Key(e); break;
		}
	}
}