typedef enum {
	CUV_xyZ, CUV_xYZ, CUV_XYZ, CUV_XyZ,
	CUV_xyz, CUV_Xyz, CUV_xYz, CUV_XYz,
} CubeVerts;

typedef enum {
	CUE_xZ, CUE_YZ, CUE_XZ, CUE_yZ,
	CUE_xz, CUE_Yz, CUE_Xz, CUE_yz,
	CUE_xy, CUE_xY, CUE_XY, CUE_Xy,
} CubeEdges;

typedef enum {
	CUQ_Z, CUQ_z,
	CUQ_x, CUQ_X,
	CUQ_y, CUQ_Y,
} CubeQuads;


const struct {
	
	s8 Verts[8][3];
	u8 Edges[12][2];
	u8 Quads[6][4];
	
} Cube = {
	
	.Verts = {
		[CUV_xyZ] = { -1, -1, +1 },
		[CUV_xYZ] = { -1, +1, +1 },
		[CUV_XYZ] = { +1, +1, +1 },
		[CUV_XyZ] = { +1, -1, +1 },
		[CUV_Xyz] = { +1, -1, -1 },
		[CUV_XYz] = { +1, +1, -1 },
		[CUV_xYz] = { -1, +1, -1 },
		[CUV_xyz] = { -1, -1, -1 },
	},
	
	.Edges = {
		[CUE_xZ] = { CUV_xyZ, CUV_xYZ },
		[CUE_YZ] = { CUV_xYZ, CUV_XYZ },
		[CUE_XZ] = { CUV_XyZ, CUV_XYZ },
		[CUE_yZ] = { CUV_xyZ, CUV_XyZ },
		[CUE_Xz] = { CUV_Xyz, CUV_XYz },
		[CUE_Yz] = { CUV_xYz, CUV_XYz },
		[CUE_xz] = { CUV_xyz, CUV_xYz },
		[CUE_yz] = { CUV_xyz, CUV_Xyz },
		[CUE_xy] = { CUV_xyz, CUV_xyZ },
		[CUE_xY] = { CUV_xYz, CUV_xYZ },
		[CUE_XY] = { CUV_XYz, CUV_XYZ },
		[CUE_Xy] = { CUV_Xyz, CUV_XyZ },
	},
	
	.Quads = {
		[CUQ_Z] = { CUE_xZ, CUE_YZ, CUE_XZ, CUE_yZ },
		[CUQ_z] = { CUE_Xz, CUE_Yz, CUE_xz, CUE_yz },
		[CUQ_x] = { CUE_xz, CUE_xY, CUE_xZ, CUE_xy },
		[CUQ_X] = { CUE_XZ, CUE_XY, CUE_Xz, CUE_Xy },
		[CUQ_Y] = { CUE_xY, CUE_Yz, CUE_XY, CUE_YZ },
		[CUQ_y] = { CUE_xy, CUE_yZ, CUE_Xy, CUE_yz },
	},
};
