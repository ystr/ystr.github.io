using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Text;

class OptBox : Panel
{
	int flow = 0;
	
	public OptBox ()
	{
		BackColor = SystemColors.Window;
		BorderStyle = BorderStyle.Fixed3D;
		VScroll = HScroll = true;
		AutoScroll = true;
	}
	
	Control Add (Control c)
	{
		c.Top = flow;
		c.Dock = DockStyle.None;
		Controls.Add(c);
		flow += c.Height;
		return c;
	}
	
	public Check AddCheck (string text, bool ckd)
	{
		Check ck = new Check(text);
		ck.Checked = ckd;
		return Add(ck) as Check;
	}
	
	public Lable AddHeader (string text)
	{
		Lable l = new Lable(text);
		l.Font = new Font(l.Font, FontStyle.Bold);
		return Add(l) as Lable;
	}
}

class MiscTab : Tab
{
	OptBox opx = new OptBox();
	
	public bool Portable { get { return portableCk.Checked; } }
	public bool SuppressWelcomes { get { return suppressWelcomesCk.Checked; } }
	
	public bool HideRawPing { get { return hideRawPingCk.Checked; } }
	public bool HideRawList { get { return hideRawListCk.Checked; } }
	public bool HideRawPrivmsg { get { return hideRawPrivmsgCk.Checked; } }
	public bool HideRawKnown { get { return hideRawKnownCk.Checked; } }
	
	Check suppressWelcomesCk;
	Check portableCk;
	
	Check hideRawPingCk;
	Check hideRawListCk;
	Check hideRawPrivmsgCk;
	Check hideRawKnownCk;
	
	public MiscTab () : base ("Misc")
	{
		opx.Dock = DockStyle.Fill;
		Controls.Add(opx);
		
		portableCk = opx.AddCheck("Portable mode", Settings.Portable);
		suppressWelcomesCk = opx.AddCheck("Ignore welcome notices", Settings.SuppressWelcomes);
		
		opx.AddHeader("Debug log");
		hideRawPingCk = opx.AddCheck("Hide PING/PONG", Settings.HideRawPing);
		hideRawListCk = opx.AddCheck("Hide LIST reply (322)", Settings.HideRawList);
		hideRawPrivmsgCk = opx.AddCheck("Hide PRIVMSGs", Settings.HideRawPrivmsg);
		hideRawKnownCk = opx.AddCheck("Hide all known commands", Settings.HideRawKnown);
	}
}