using System;
using System.Drawing;
using System.Windows.Forms;

class Lable : Label
{
	readonly string text;
	void Localize () { Text = Own.Line(text); }
	
	public Lable (string text)
	{
		this.text = text;
		AutoSize = true;
		Margin = new Padding(0);
		Dock = DockStyle.Fill;
		TextAlign = ContentAlignment.MiddleLeft;
		Own.LocaleChanged += Localize;
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
	
	#region DoubleClickCopyPrevention
		
		string savedClipboard;
		
		protected override void OnDoubleClick (EventArgs e)
		{
			if (savedClipboard != null)
			{
				Clipboard.SetData(DataFormats.Text, savedClipboard);
			}
			
			savedClipboard = null;
			base.OnDoubleClick(e);
		}
		
		protected override void WndProc (ref Message m)
		{
			if (m.Msg == 0x203) // WM_LBUTTONDCLICK
			{
				IDataObject d = Clipboard.GetDataObject();
				
				if (d.GetDataPresent(DataFormats.Text))
				{
					savedClipboard = d.GetData(DataFormats.Text) as string;
				}
			}
			
			base.WndProc(ref m);
		}
		
	#endregion
}