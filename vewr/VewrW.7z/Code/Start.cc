void Show ()
{
	int iw = SourceWidth;
	int ih = SourceHeight;
	
	int maxw = GetSystemMetrics(SM_CXSCREEN) - 128;
	int maxh = GetSystemMetrics(SM_CYSCREEN) - 128;
	
	while (iw > maxw || ih > maxh) { iw /= 2; ih /= 2; }
	if (iw < 128 && ih < 128) { Fit = false; }
	if (iw < 128) { iw = 128; } if (ih < 128) { ih = 128; }
	
	iw += 2 * GetSystemMetrics(SM_CXSIZEFRAME);
	ih += GetSystemMetrics(SM_CYCAPTION) + 2 * GetSystemMetrics(SM_CYSIZEFRAME);
	
	HINSTANCE appHandle = GetModuleHandle(0);
	
	WNDCLASSEX winClass = {0};
	
	winClass.cbSize = sizeof(winClass);
	winClass.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	winClass.lpfnWndProc = WndProc;
	winClass.hInstance = appHandle;
	winClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	winClass.lpszClassName = L"Vewr";
	
	RegisterClassEx(&winClass);
	
	WinHandle = CreateWindow (
		L"Vewr", File, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, iw, ih,
		HWND_DESKTOP, 0, appHandle, 0
	);
	
	ApplyBackground();
	
	ApplyAnimation();
	
	ShowIcon();
	
	ShowWindow(WinHandle, SW_SHOWNORMAL);
	
	WinContext = GetDC(WinHandle);
	
	MSG m; while (GetMessage(&m, 0, 0, 0))
	{
		TranslateMessage(&m);
		DispatchMessage(&m);
	}
}

void Start (TCHAR* path)
{
	ULONG_PTR gdipToken;
	GdiplusStartupInput gdipInput;
	GdiplusStartup(&gdipToken, &gdipInput, 0);
	if (Load(path)) { PreparePath(path); Show(); }
	GdiplusShutdown(gdipToken);
}

void Main ()
{
	LoadApis();
	
	int argn;
	
	TCHAR** args = CommandLineToArgvW(GetCommandLine(), &argn);
	
	if (argn < 2)
	{
		TCHAR path[MAX_PATH];
		
		OPENFILENAME o = {0};
		
		o.lStructSize = sizeof(o);
		o.lpstrFile = path;
		o.lpstrFile[0] = '\0';
		o.nMaxFile = sizeof(path);
		o.lpstrFilter = L"All\0*.*\0";
		o.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
		
		if (GetOpenFileName(&o)) Start(path);
	}
	
	else
	{
		for (int i = 2; i < argn; i++)
		{
			TCHAR quoted[MAX_PATH];
			
			wcscpy(quoted, L"\"");
			wcscat(quoted, args[i]);
			wcscat(quoted, L"\"");
			
			ShellExecute(0, 0, args[0], quoted, 0, SW_SHOW);
		}
		
		Start(args[1]);
	}
}
