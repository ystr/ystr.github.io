using System.Windows.Forms;

class InterfaceMenu : Menu
{
	OptRow overviewRow;
	OptRow tipsRow;
	OptRow exitRow;
	
	public InterfaceMenu ()
	{
		overviewRow = new OptRow(Face.Overview);
		tipsRow = new OptRow(Face.ShowTips);
		exitRow = new OptRow(Face.ConfirmExit);
		
		Items.Add(overviewRow);
		Items.Add(tipsRow);
		Items.Add(exitRow);
	}
}