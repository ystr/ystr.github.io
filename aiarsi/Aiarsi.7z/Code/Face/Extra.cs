using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

static class Extra
{
	static public void Sync (this Control target, Action act)
	{
		if (target.InvokeRequired)
		{
			try { target.Invoke(act); }
			
			#if DEBUG
				catch (InvalidOperationException e) { Console.WriteLine(e.ToString()); }
			#else
				catch (InvalidOperationException) { }
			#endif
			
		} else act();
	}
	
	
	static public void WipeControls (this Control ta)
	{
		for (int i = ta.Controls.Count - 1; i >= 0; i--)
		{
			Control c = ta.Controls[i];
			c.WipeControls();
			c.Controls.Clear();
			c.Dispose();
		}
	}
	
	static public void Put (this Control ta, params Control[] list)
	{
		foreach (Control c in list)
		{
			ta.Controls.Add(c);
		}
	}
	
	
	[DllImport("user32.dll")] static extern int SendMessage (IntPtr hWnd, uint wMsg, UIntPtr wParam, IntPtr lParam);
	public static int SendMessage (this Control ta, int wMsg, int wParam, int lParam) { return ta.SendMessage((uint)wMsg, (uint)wParam, lParam); }
	public static int SendMessage (this Control ta, uint wMsg, uint wParam, int lParam) { return SendMessage(ta.Handle, wMsg, (UIntPtr)wParam, (IntPtr)lParam); }
	
	
	[DllImport("user32.dll")] static extern int ShowWindow (IntPtr hWnd, uint Msg);
	public static void Unminimize (this Form ta) { ShowWindow(ta.Handle, 0x09); }
	
	
	[DllImport("user32.dll")] static extern int GetScrollPos (IntPtr hWnd, int nBar);
	public static int GetScrollPos (this Control ta) { return GetScrollPos(ta.Handle, 0x1); }
	
	public static void Scroll (this Control ta, int delta)
	{
		int pos = ta.GetScrollPos() + delta; if (pos < 0) pos = 0;
		ta.SendMessage(277, 4 + 0x10000 * pos, 0);
	}
	
	public static void ScrollToBottom (this Control ta)
	{
		ta.SendMessage(277, 7, 0);
	}
	
	
	[DllImport("UxTheme.dll")] public static extern bool IsAppThemed ();
	
	
	public static void AllowRedraw (this Control c, bool l) { SendMessage(c, 0x000B, l ? 1 : 0, 0); }
	public static void SuspendRedraw (this Control c) { AllowRedraw(c, false); }
	public static void ResumeRedraw (this Control c) { AllowRedraw(c, true); c.Refresh(); }
	
	
	[DllImport("user32.dll")] static extern bool FlashWindowEx (ref FLASHWINFO pwfi);
	
	struct FLASHWINFO
	{
		public uint cbSize;
		public IntPtr hwnd;
		public uint dwFlags;
		public uint uCount;
		public uint dwTimeout;
	}
	
	static public void Flash (this Window w)
	{
		FLASHWINFO i = new FLASHWINFO();
		
		i.cbSize = (uint) Marshal.SizeOf(i);
		i.hwnd = w.Handle;
		i.dwFlags = 3; // FLASHW_ALL
		i.uCount = 3;
		i.dwTimeout = 100;
		
		FlashWindowEx(ref i);
	}
}