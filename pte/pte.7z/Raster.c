typedef struct {
	
	fu8 ByPP;
	fu16 Stride;
	Rect Clip;
	
	void* Zero;
	void* Raw;
	
} Raster;


static inline void* RefXY (const Raster* r, int x, int y)
{
	return (char*) r->Zero + y * r->Stride + x * r->ByPP;
}

static inline void SetXY (const Raster* r, int x, int y, const void* p)
{
	memcpy(RefXY(r, x, y), p, r->ByPP);
}

static inline void GetXY (void* o, const Raster* r, int x, int y)
{
	memcpy(o, RefXY(r, x, y), r->ByPP);
}


void Fill (const Raster* r, const Rect* clip, const void* p)
{
	for (int y = clip->B; y < clip->T; ++y)
	for (int x = clip->L; x < clip->R; ++x)
	{
		SetXY(r, x, y, p);
	}
}


void DrawSprite (
	const Raster* back, const Raster* fore,
	int x, int y, Shader* sha, const void* arg
) {
	int w = fore->Clip.W;
	int h = fore->Clip.H;
	
	Rect srcr = fore->Clip;
	Rect dstr = Lbwh(x - w / 2, y - h / 2, w, h);
	if (!DstClipSrc(&dstr, &back->Clip, &srcr)) return;
	
	for (int sy = srcr.B, dy = dstr.B; sy < srcr.T; sy++, dy++)
	for (int sx = srcr.L, dx = dstr.L; sx < srcr.R; sx++, dx++)
	{
		sha(RefXY(back, dx, dy), RefXY(fore, sx, sy), arg);
	}
}


void InitRasterFor (Raster* r, fu8 bpp, fu16 bpr, const Rect* clip, void* p)
{
	r->ByPP = bpp;
	r->Stride = bpr;
	r->Zero = (char*) p - (clip->B * bpr + clip->L * bpp);
	r->Clip = *clip;
	r->Raw = 0;
}

void InitRaster (Raster* r, fu8 bpp, const Rect* clip)
{
	r->ByPP = bpp;
	r->Stride = bpp * clip->W;
	r->Raw = NEW(char, clip->H * r->Stride);
	r->Zero = (char*) r->Raw - clip->B * r->Stride - clip->L * bpp;
	r->Clip = *clip;
}

void KillRaster (const Raster* r)
{
	ZAP(r->Raw);
}
