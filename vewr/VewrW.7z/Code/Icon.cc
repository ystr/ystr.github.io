HICON ComposeIcon (int size)
{
	HICON hic;
	
	Bitmap b(size, size);
	
	Graphics g(&b);
	g.SetInterpolationMode(InterpolationModeLowQuality);
	g.DrawImage(Source, 0, 0, size, size);
	
	b.GetHICON(&hic);
	
	return hic;
}

void ShowIcon ()
{
	if (Icon16) DestroyIcon(Icon16);
	if (Icon32) DestroyIcon(Icon32);
	
	Icon16 = ComposeIcon(16);
	Icon32 = ComposeIcon(32);
	
	SendMessage(WinHandle, WM_SETICON, ICON_SMALL, (LPARAM)Icon16);
	SendMessage(WinHandle, WM_SETICON, ICON_BIG, (LPARAM)Icon32);
}
