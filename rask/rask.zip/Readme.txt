RASKADROVKA
	
	A simple storyboard app.

CONTROLS
	
	Mouse Left = Draw
	Mouse Right = Erase area
	
	Ctrl N = New frame after current
	Ctrl Del = Delete frame
	Ctrl S = Save
	Ctrl Shift S = Save as...
	Ctrl ← = Previous frame
	Ctrl → = Next frame
	Ctrl Shift ← = Move frame back
	Ctrl Shift → = Move frame forward
	
	Double-click frame list empty area = New frame at the end
	Right-click frame = Frame menu
	
	F1 = Help (this file)

FILE FORMAT
	
	char Header [4] = "RASK"
	uint32 VersionOrFlags = 0
	uint32 FrameCount
	struct Frame {
		uint32 StrokeCount
		struct Stroke {
			uint32 PointCount
			struct Point { IEEE754_single X, Y } Points [PointCount]
		} Strokes [StrokeCount]
		Utf8NullTerminatedChar Caption []
	} Frames [FrameCount]

ABOUT
	
	ES <izt@ya.ru> GPL3
	http://ystr.github.io/rask/