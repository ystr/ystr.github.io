void NaturalSort (TCHAR** list, int count)
{
	for (int n = 0; n < count; ++n)
	{
		for (int i = 0; i < count - 1; ++i)
		{
			if (StrCmpLogicalW(list[i], list[i + 1]) > 0)
			{
				TCHAR* swap = list[i + 1];
				list[i + 1] = list[i];
				list[i] = swap;
			}
		}
	}
}

void PreparePath (TCHAR* path)
{
	TCHAR* s = wcsrchr(path, '\\');
	TCHAR* e = wcsrchr(path, '\0');
	
	wcscpy(Dir, L"\0");
	wcscpy(File, L"\0");
	
	wcsncat(Dir, path, s - path);
	wcsncat(File, s + 1, e - s);
	
	FileCount = 0;
	
	TCHAR wd[MAX_PATH];
	wcscpy(wd, Dir);
	wcscat(wd, L"\\*");
	
	HANDLE ff;
	WIN32_FIND_DATA fd;
	
	ff = FindFirstFile(wd, &fd);
	do { if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) FileCount++; }
	while (FindNextFile(ff, &fd));
	FindClose(ff);
	
	Files = new TCHAR*[FileCount];
	
	ff = FindFirstFile(wd, &fd);
	
	int i = 0; do
	{
		if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
		{
			Files[i] = new TCHAR[wcslen(fd.cFileName) + 1];
			wcscpy(Files[i], fd.cFileName); i++;
		}
		
		FindNextFile(ff, &fd);
		
	} while (i < FileCount);
	
	NaturalSort(Files, FileCount);
	for (int i = 0; i < FileCount; ++i) if (!wcscmp(Files[i], File)) Caret = i;
	
	FindClose(ff);
}
