using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

class ServerList : Panel
{
	#region Selection
		
		int selectedIndex = -1;
		List<RosterControl> index = new List<RosterControl>();
		
		ServerControl selectedServer = null;
		public ServerControl SelectedServer { get { return selectedServer; } }
		
		ChatControl selectedChat = null;
		public ChatControl SelectedChat { get { return selectedChat; } }
		
		public void SelectNext (int delta)
		{
			ClearSelection();
			
			selectedIndex += delta;
			
			if (selectedIndex < 0) selectedIndex = index.Count - 1;
			else if (selectedIndex >= index.Count) selectedIndex = 0;
			
			MarkSelection();
		}
		
		void ClearSelection ()
		{
			if (
				selectedIndex >= 0 && selectedIndex < index.Count
			) index[selectedIndex].Selected = false;
		}
		
		void MarkSelection ()
		{
			if (selectedIndex < 0) return;
			
			RosterControl selected = index[selectedIndex];
			selected.Selected = true;
			
			if (selected.GetType().Name == "ServerControl") {
				selectedServer = (ServerControl) selected;
				selectedChat = null;
			} else {
				selectedChat = (ChatControl) selected;
				selectedServer = selectedChat.Parent;
			}
		}
		
		void Select (int i)
		{
			ClearSelection();
			selectedIndex = i;
			MarkSelection();
		}
		
		void Reindex ()
		{
			index.Clear();
			
			int i = 0;
			
			foreach (Control s in container.Controls)
			{
				ServerControl sc = (ServerControl) s;
				sc.DirectlySelected += () => Select(sc.LinearIndex);
				sc.Selected = false;
				sc.LinearIndex = i++;
				index.Add(sc);
				
				if (sc.Expanded)
				{
					foreach (Control c in sc.Sub.Controls)
					{
						RosterControl cc = (RosterControl) c;
						cc.DirectlySelected += () => Select(cc.LinearIndex);
						cc.LinearIndex = i++;
						cc.Selected = false;
						index.Add(cc);
					}
				}
			}
			
			if (selectedServer != null)
			{
				if (
					selectedServer.Expanded && selectedChat != null
				) selectedIndex = selectedChat.LinearIndex;
				else selectedIndex = selectedServer.LinearIndex;
			}
			
			if (selectedIndex >= index.Count) selectedIndex = -1;
			MarkSelection();
		}
		
	#endregion
	
	Panel container = new Panel();
	bool ignoreIndividualRedraws = false;
	
	public ServerList ()
	{
		AutoScroll = true;
		
		container.Dock = DockStyle.Top;
		container.AutoSize = true;
		Controls.Add(container);
		
		Server.ListChanged += SyncReload;
		Click += (o, e) => Select(-1);
		
		Reload();
	}
	
	protected override void Dispose (bool d)
	{
		Server.ListChanged -= SyncReload;
		base.Dispose(d);
	}
	
	void SyncReload () { this.Sync(Reload); }
	public void Reload ()
	{
		ignoreIndividualRedraws = true;
		AutoScroll = false;
		this.SuspendRedraw();
		
		container.WipeControls();
		
		foreach (Server s in Server.List)
		{
			ServerControl c = new ServerControl(s);
			c.Dock = DockStyle.Bottom;
			c.Reorganized += Reindex;
			c.RedrawStarted += () => { if (!ignoreIndividualRedraws) { AutoScroll = false; this.SuspendRedraw(); } };
			c.RedrawFinished += () => { if (!ignoreIndividualRedraws) { this.ResumeRedraw(); AutoScroll = true; } };
			container.Controls.Add(c);
		}
		
		Reindex();
		
		AutoScroll = true;
		this.ResumeRedraw();
		ignoreIndividualRedraws = false;
	}
	
	public void SetExpandedAll (bool exp)
	{
		ignoreIndividualRedraws = true;
		this.SuspendRedraw();
		foreach (ServerControl c in container.Controls) c.Expanded = exp;
		this.ResumeRedraw();
		ignoreIndividualRedraws = false;
	}
}