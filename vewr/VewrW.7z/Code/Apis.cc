typedef int (WINAPI StrCmpLogicalWHandler) (PCWSTR s1, PCWSTR s2);
StrCmpLogicalWHandler* StrCmpLogicalW;

void LoadApis ()
{
	HINSTANCE shlwapi = LoadLibrary(L"shlwapi.dll");
	StrCmpLogicalW = (StrCmpLogicalWHandler*) GetProcAddress(shlwapi, "StrCmpLogicalW");
}
