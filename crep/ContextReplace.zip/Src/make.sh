mcs Face.cs Own.cs Version.cs Replacer.cs -resource:Replace.ico -out:ContextReplace.exe -r:System.Windows.Forms -r:System.Drawing -o+
