using System;
using System.Timers;
using System.Collections.Generic;

enum ChannelStatus
{
	Joining, Joined,
	Parting, Parted
}

enum ChannelProblem
{
	Kicked,
	Unjoinable
}

partial class Channel : Chat
{
	public Channel (Server s, string name) : this (s, name, false) { }
	public Channel (Server s, string name, bool initiallyJoined) : base (s, "Channels", name)
	{
		if (initiallyJoined) status = ChannelStatus.Joined;
		
		autoJoin = Options.Get("AutoJoin", false);
		watch = Options.Get("Watch", false);
		key = Options.Get("Key", "");
		
		Server.Link.StatusChanged += HandleServerStatus;
		Server.WelcomedChanged += () => { if (autoJoin && Server.Welcomed) Join(); };
	}
	
	
	char? ownStatus = null;
	ChannelStatus status = ChannelStatus.Parted;
	ChannelProblem? problem = null;
	
	object ownStatusLock = new object();
	object statusLock = new object();
	object problemLock = new object();
	
	void SetOwnStatus (char? s) { lock (ownStatusLock) ownStatus = s; OwnStatusChanged(); }
	void SetStatus (ChannelStatus s) { lock (statusLock) status = s; StatusChanged(); }
	void SetProblem (ChannelProblem? p) { lock (problemLock) problem = p; ProblemChanged(); }
	
	public char? OwnStatus { get { lock (ownStatusLock) return ownStatus; } }
	public ChannelStatus Status { get { lock (statusLock) return status; } }
	public ChannelProblem? Problem { get { lock (problemLock) return problem; } }
	
	
	public event Action OwnStatusChanged = () => {};
	public event Action StatusChanged = () => {};
	public event Action ProblemChanged = () => {};
	
	
	public void Join ()
	{
		SetStatus(ChannelStatus.Joining);
		Server.Send("JOIN " + Name + " " + Key);
	}
	
	public void Part ()
	{
		SetStatus(ChannelStatus.Parting);
		Server.Send("PART " + Name);
	}
	
	
	bool autoJoin;
	public event Action AutoChanged = () => {};
	public bool AutoJoin {
		get { return autoJoin; }
		set { Options.Set("AutoJoin", autoJoin = value); AutoChanged(); }
	}
	
	string key;
	public string Key {
		get { return key; }
		set { Options.Set("Key", key = value); }
	}
	
	
	void HandleServerStatus ()
	{
		if (Server.Link.Status == LinkStatus.Disconnected)
		{
			SetStatus(ChannelStatus.Parted);
			
			lock (statusLock) if (status != ChannelStatus.Joined) return;
			
			lock (users) users.Clear();
			UsersChanged();
			
			Entry e = new Entry(LogTag.Client);
			e.Add(Style.Get("Client"), "Disconnected.\n");
			Log.Push(e);
		}
	}
	
	
	#region Users
		
		readonly SortedDictionary<string, User> users = new SortedDictionary<string, User>();
		public event Action UsersChanged = () => {};
		bool userListInProgress = false;
		
		public SortedDictionary<string, User> ListUsers ()
		{
			lock (users)
			{
				return new SortedDictionary<string, User>(users);
			}
		}
		
		public bool HasUser (string id)
		{
			lock (users)
			{
				return users.ContainsKey(id);
			}
		}
		
	#endregion
	
	
	public void Terminate ()
	{
		ChannelStatus cs;
		lock (statusLock) cs = status;
		
		if (
			cs == ChannelStatus.Joined ||
			cs == ChannelStatus.Joining
		) Part();
		
		Terminated();
	}
	
	public event Action Terminated = () => {};
	
	
	public override void Send (Slash s)
	{
		switch (s.Command)
		{
			case "PART": Server.Send("PART " + Name); break;
			case "TOPIC": Server.Send("TOPIC " + Name + " :" + s.All); break;
			case "INVITE": Server.Send("INVITE " + s.All + " " + Name); break;
			case "MODE": Server.Send("MODE " + Name + " " + s.All); break;
			
			case "KICK":
				if (s.All == null) break;
				if (s.Post == null) Server.Send("KICK " + Name + " " + s.First);
				else Server.Send("KICK " + Name + " " + s.First + " :" + s.Post);
			break;
			
			default: base.Send(s); break;
		}
	}
	
	
	public override void ProcessIncoming (Line il)
	{
		switch (il.Command)
		{
			case Irc.JOIN: {
				
				string uid = il.From.ToID();
				
				if (uid == Server.CurrentID)
				{
					SetStatus(ChannelStatus.Joined);
					SetProblem(null);
					Log.Push(LogTag.Join, "Now talking in %0", Name);
				}
				else
				{
					User ju = new User(il.From);
					
					lock (users) users[uid] = ju;
					UsersChanged();
					
					Log.Push(LogTag.Join, "%0 joins %1", il.From, Name);
				}
				
			} break;
			
			case Irc.KICK: {
				
				string kuid = il.Args[1].ToID();
				
				if (kuid == Server.CurrentID)
				{
					SetStatus(ChannelStatus.Parted);
					SetProblem(ChannelProblem.Kicked);
					
					lock (users) users.Clear();
					UsersChanged();
					
					Entry e = Log.Push(LogTag.Kick, "You were kicked by %0 (%1)\n", il.From, il.Postfix);
					if (Settings.ErrorsNotify) this.Announce(NotifyType.Error, Name, e.Plain);
					
					if (AutoJoin) Join();
				}
				else
				{
					Log.Push(LogTag.Kick, "%1 was kicked by %0 (%2)", il.From, il.Args[1], il.Postfix);
					
					lock (users) users.Remove(kuid);
					UsersChanged();
				}
				
			} break;
			
			case Irc.MODE: {
				
				string mode = il.Args[1];
				
				if (il.Args.Length > 2)
				{
					char? sign = null;
					List<string> modes = new List<string>();
					string[] names = il.Args.Cut(2);
					
					foreach (char c in mode)
					{
						if (c == '-' || c == '+') sign = c;
						else if (sign != null) modes.Add(sign.ToString() + c);
					}
					
					lock (users)
					{
						for (int i = 0; i < names.Length; ++i)
						{
							string id = names[i].ToID();
							if (!users.ContainsKey(id)) continue;
							users[id].ApplyMode(modes[i]);
							if (id == Server.CurrentID) SetOwnStatus(users[id].Status);
						}
					}
					
					Log.Push(LogTag.Mode, "%0 sets %1 %2", il.From, mode, names.Join(" "));
					UsersChanged();
				}
				else
				{
					Log.Push(LogTag.Mode, "%0 sets %1", il.From, mode);
				}
				
			} break;
			
			case Irc.NICK: {
				
				string uid = il.From.ToID();
				
				lock (users)
				{
					if (!users.ContainsKey(uid)) break;
					User u = users[uid];
					users.Remove(uid);
					u.Nick = il.Postfix;
					users[u.ID] = u;
				}
				
				UsersChanged();
				Log.Push(LogTag.Name, "%0 is now known as %1", il.From, il.Postfix);
				
			} break;
			
			case Irc.NOTICE: {
				
				if (il.From == null) Log.Push(LogTag.IncomingNotice, il.Postfix);
				else Log.Push(LogTag.IncomingNotice, "%0: %1", il.From, il.Postfix);
				
				string title = il.From ?? Name;
				
				if (
					!Highlight(title, il.Postfix) && watch
				) this.Announce(NotifyType.Info, title, il.Postfix);
				
				Log.Unread |= Unread.Message;
				
			} break;
			
			case Irc.PART: {
				
				string uid = il.From.ToID();
				
				if (uid == Server.CurrentID)
				{
					SetStatus(ChannelStatus.Parted);
					
					lock (users) users.Clear();
					UsersChanged();
					
					Log.Push(LogTag.Part, "Leaving %0\n", Name);
				}
				else
				{
					lock (users) users.Remove(uid);
					UsersChanged();
					
					Log.Push(LogTag.Part, "%0 leaves %1", il.From, Name);
				}
				
			} break;
			
			case Irc.TOPIC: {
				Log.Push(LogTag.Topic, "%0 sets topic: %1", il.From, il.Postfix);
			} break;
			
			case Irc.QUIT: {
				
				string uid = il.From.ToID();
				
				lock (users)
				{
					if (!users.ContainsKey(uid)) break;
					users.Remove(uid);
				}
				
				UsersChanged();
				Log.Push(LogTag.Quit, "%0 quit (%1)", il.From, il.Postfix);
				
			} break;
			
			case Irc.RPL_ENDOFNAMES:
				userListInProgress = false;
			break;
			
			case Irc.RPL_INVITING:
				if (Status == ChannelStatus.Joined) Log.Push(LogTag.Info, "Inviting %0", il.Args[1]);
			break;
			
			case Irc.RPL_NAMREPLY: {
				
				lock (users)
				{
					if (!userListInProgress) users.Clear();
					userListInProgress = true;
					
					string[] pres = il.Postfix.Trim().Split(' ');
					
					foreach (string pre in pres)
					{
						User nu = new User(pre);
						if (nu.ID == Server.CurrentID) SetOwnStatus(nu.Status);
						users[nu.ID] = nu;
					}
				}
				
				UsersChanged();
				
			} break;
			
			case Irc.RPL_NOTOPIC:
				Log.Push(LogTag.Topic, il.Postfix);
			break;
			
			case Irc.RPL_TOPIC:
				Log.Push(LogTag.Topic, Own.Line("Topic: %0", il.Postfix));
			break;
			
			case Irc.RPL_TOPICWHOTIME:
				DateTime at = il.Args[3].ParseUnixTime();
				Log.Push(LogTag.Topic, "(set by %0 on %1)", il.Args[2], at.ToString());
			break;
			
			case Irc.ERR_USERONCHANNEL:
				Log.Push(LogTag.Error, "%0 %1", il.Args[1], il.Postfix);
			break;
			
			case Irc.ERR_CHANNELISFULL:
			case Irc.ERR_INVITEONLYCHAN:
			case Irc.ERR_BANNEDFROMCHAN:
			case Irc.ERR_BADCHANNELKEY:
				SetStatus(ChannelStatus.Parted);
				SetProblem(ChannelProblem.Unjoinable);
				Log.Push(LogTag.Error, il.Postfix);
			break;
			
			case Irc.ERR_CANNOTSENDTOCHAN:
			case Irc.ERR_CHANOPRIVSNEEDED:
			case Irc.ERR_KEYSET:
				Log.Push(LogTag.Error, il.Postfix);
			break;
		}
		
		base.ProcessIncoming(il);
	}
}