using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;


class NewlineMenu : Menu
{
	Dictionary<string, Row> rows = new Dictionary<string, Row>
	{
		{ "\n", new Row("LF") },
		{ "\r", new Row("CR") },
		{ "\r\n", new Row("CRLF") }
	};
	
	Row defaultRow = new Row("Set as Default");
	
	public readonly Document D;
	
	public NewlineMenu (Document doc)
	{
		D = doc;
		
		foreach (var kv in rows)
		{
			string key = kv.Key;
			kv.Value.Clicked += () => { D.Newline = key; };
			Items.Add(kv.Value);
		}
		
		Items.Add(new ToolStripSeparator());
		Items.Add(defaultRow);
		
		defaultRow.Clicked += () => Document.DefaultNewline = D.Newline;
		
		Opening += (o, e) =>
		{
			D.NewlineChanged += Reveal;
			Document.DefaultNewlineChanged += Reveal;
			
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			D.NewlineChanged -= Reveal;
			Document.DefaultNewlineChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		foreach (var kv in rows)
		{
			kv.Value.Checked = (kv.Key == D.Newline);
		}
		
		defaultRow.Checked = (Document.DefaultNewline == D.Newline);
	}
}