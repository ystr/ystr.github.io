#define _DEFAULT_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <libgen.h>
#include <Imlib2.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <unistd.h>




#define ALEN(A) (sizeof(A) / sizeof(A[0]))




struct {
	
	Display* Display;
	Screen* Screen;
	int ScreenId;
	Colormap Colormap;
	Visual* Visual;
	Atom WM_DELETE_MESSAGE;
	
} X = {0};


struct {
	
	Window Window;
	GC Context;
	
	char* FilePath;
	char* FileName;
	
	char* FilesDir;
	char** Files;
	int FilesCount;
	int FilePos;
	
	bool Fit;
	enum { INNER, OUTER, STRETCH } FitMode;
	int W, H, X, Y;
	bool FlipX, FlipY;
	struct { int L, T, W, H; } Dst;
	float Zoom;
	bool Smooth;
	bool Tile;
	
	Imlib_Image Image;
	struct { int W, H; } Src;
	Imlib_Image Buffer;
	
	int BgColor;
	const struct Rgb8 {
		unsigned char R, G, B;
	} BgColors[3];
	
	struct { int X, Y; } PreCur;
	Time LastClickTime;
	unsigned LastClickButton;
	unsigned ClickNumber;
	
	bool Cursor;
	
	bool Updated;
	struct { int L, T, R, B; } Invalid;
	bool Exposed;
	
	bool FullScreen;
	
} V = {
	
	.Zoom = 1,
	.Tile = false,
	.Smooth = true,
	.Fit = true,
	.FitMode = INNER,
	.Cursor = true,
	
	.BgColor = 0,
	.BgColors = {
		{ 0x00, 0x00, 0x00 },
		{ 0x80, 0x80, 0x80 },
		{ 0xFF, 0xFF, 0xFF },
	},
	
};




void XSetTitle (const char* title)
{
	XTextProperty property;
	
	XmbTextListToTextProperty (
		X.Display, (char**) &title, 1,
		XCompoundTextStyle, &property
	);
	
	XSetWMName(X.Display, V.Window, &property);
	XFree(property.value);
}

void XSetThumbIcon ()
{
	imlib_context_set_image(V.Image);
	static const int tw = 32, th = 32;
	Imlib_Image thi = imlib_create_cropped_scaled_image(0, 0, V.Src.W, V.Src.H, tw, th);
	imlib_context_set_image(thi);
	
	unsigned long xbuf[2 + tw * th];
	xbuf[0] = tw, xbuf[1] = th;
	
	for (int xi = 2, y = 0; y < th; y++)
	for (int x = 0; x < tw; x++, xi++) {
		Imlib_Color ic; imlib_image_query_pixel(x, y, &ic);
		xbuf[xi] = (ic.alpha << 24) | (ic.red << 16) | (ic.green << 8) | ic.blue;
	}
	
	imlib_free_image();
	
	XChangeProperty (
		X.Display, V.Window,
		XInternAtom(X.Display, "_NET_WM_ICON", 0),
		XInternAtom(X.Display, "CARDINAL", 0), 32,
		PropModeReplace, (const unsigned char*) xbuf,
		2 + tw * th
	);
}

void XGetScreenWH (int* w, int* h)
{
	*w = XDisplayWidth(X.Display, DefaultScreen(X.Display));
	*h = XDisplayHeight(X.Display, DefaultScreen(X.Display));
}

void XEnableCursor (bool on)
{
	if (on) XUndefineCursor(X.Display, V.Window);
	else {
		static char d[8] = {0};
		static XColor cc = {0};
		Pixmap p = XCreateBitmapFromData(X.Display, V.Window, d, 8, 8);
		Cursor c = XCreatePixmapCursor(X.Display, p, p, &cc, &cc, 0, 0);
		XDefineCursor(X.Display, V.Window, c);
		XFreeCursor(X.Display, c);
		XFreePixmap(X.Display, p);
	}
}




void VConfigure ()
{
	bool zw = true;
	bool zh = true;
	
	if (V.Fit)
	{
		V.X = 0;
		V.Y = 0;
		
		float sr = (float) V.Src.W / V.Src.H;
		float wr = (float) V.W / V.H;
		
		if (
			V.FitMode == INNER ? wr < sr : wr > sr
		) V.Zoom = (float) V.W / V.Src.W;
		else V.Zoom = (float) V.H / V.Src.H;
		
		if (V.FitMode == STRETCH) zw = zh = false;
	}
	
	V.Dst.W = zw ? V.Src.W * V.Zoom : V.W;
	V.Dst.H = zh ? V.Src.H * V.Zoom : V.H;
	
	int ww = (V.W + V.Dst.W) / 2;
	int hh = (V.H + V.Dst.H) / 2;
	
	if (V.X < -ww) V.X = -ww; else if (V.X > ww) V.X = ww;
	if (V.Y < -hh) V.Y = -hh; else if (V.Y > hh) V.Y = hh;
	
	V.Dst.L = (V.W - V.Dst.W) / 2 + V.X;
	V.Dst.T = (V.H - V.Dst.H) / 2 + V.Y;
	
	V.Updated = true;
}

void VUpdateInfo ()
{
	char title[PATH_MAX + 512];
	
	const char* fm = "";
	if (V.Fit) switch (V.FitMode) {
		case INNER: fm = " F"; break;
		case OUTER: fm = " Z"; break;
		case STRETCH: fm = " S"; break;
	}
	
	snprintf (
		title, sizeof(title), "%s | %i*%i | %i%%%s%s%s%s | %s",
		V.FileName, V.Src.W, V.Src.H,
		(int) round(V.Zoom * 100),
		V.Tile ? " T" : "", fm,
		V.FlipX ? " -X " : "", V.FlipY ? " -Y" : "",
		V.FilesDir
	);
	
	XSetTitle(title);
}

void VRefresh ()
{
	VConfigure();
	VUpdateInfo();
}




bool VLoad (const char* path)
{
	if (V.Image)
	{
		imlib_context_set_image(V.Image);
		imlib_free_image();
	}
	
	V.Image = imlib_load_image_without_cache(path);
	if (!V.Image) return false;
	imlib_context_set_image(V.Image);
	
	free(V.FilePath);
	free(V.FileName);
	
	V.FilePath = strdup(path);
	char ntmp[PATH_MAX]; strcpy(ntmp, V.FilePath);
	V.FileName = strdup(basename(ntmp));
	
	V.Src.W = imlib_image_get_width();
	V.Src.H = imlib_image_get_height();
	
	return true;
}

bool VLoadNew (const char* path)
{
	if (!VLoad(path)) return false;
	
	VConfigure();
	XSetThumbIcon();
	VUpdateInfo();
	
	return true;
}

void VRender ()
{
	if (!V.Updated && !V.Exposed) return;
	
	imlib_context_set_image(V.Buffer);
	
	if (V.Updated)
	{
		imlib_context_set_anti_alias(V.Smooth);
		imlib_context_set_cliprect(0, 0, V.W, V.H);
		const struct Rgb8* bc = V.BgColors + V.BgColor;
		imlib_context_set_color(bc->R, bc->G, bc->B, 0xFF);
		imlib_image_fill_rectangle(0, 0, V.W, V.H);
		
		int w = V.Dst.W * (V.FlipX ? -1 : +1);
		int h = V.Dst.H * (V.FlipY ? -1 : +1);
		
		if (V.Tile)
		for (int t = 0 - (V.Dst.H - V.Dst.T % V.Dst.H); t < V.H; t += V.Dst.H)
		for (int l = 0 - (V.Dst.W - V.Dst.L % V.Dst.W); l < V.W; l += V.Dst.W)
		imlib_blend_image_onto_image (
				V.Image, 0, 0, 0, V.Src.W, V.Src.H,
				l, t, w, h
		); else imlib_blend_image_onto_image (
			V.Image, 0, 0, 0, V.Src.W, V.Src.H,
			V.Dst.L, V.Dst.T, w, h
		);
		
		V.Exposed = true;
		V.Updated = false;
		
		V.Invalid.L = 0, V.Invalid.T = 0;
		V.Invalid.R = V.W, V.Invalid.B = V.H;
	}
	
	if (V.Exposed)
	{
		imlib_context_set_cliprect (
			V.Invalid.L, V.Invalid.T,
			V.Invalid.R - V.Invalid.L, V.Invalid.B - V.Invalid.T
		);
		
		imlib_render_image_on_drawable(0, 0);
		
		V.Exposed = false;
	}
}

void VZoom (float zoom, int x, int y)
{
	V.Fit = false;
	
	float mul = zoom / V.Zoom;
	V.Zoom = zoom;
	
	int cx = 0;
	int cy = 0;
	
	if (
		x >= 0 && x < V.W &&
		y >= 0 && y < V.H
	) {
		cx = V.W / 2 - x;
		cy = V.H / 2 - y;
	}
	
	V.X = (V.X + cx) * mul - cx;
	V.Y = (V.Y + cy) * mul - cy;
	
	VRefresh();
}

void VRelZoom (float dir, int x, int y)
{
	VZoom(V.Zoom * powf(sqrtf(2), +dir), x, y);
}

void VSetFit (bool fit, int x, int y)
{
	if (!(V.Fit = fit)) VZoom(1, x, y);
	VRefresh();
}

void VSetFitMode (int m)
{
	V.FitMode = m;
	V.Fit = true;
	VRefresh();
}

void VToggleFit (int x, int y)
{
	VSetFit(!V.Fit, x, y);
}

void VSetFlipX (bool f)
{
	V.FlipX = f;
	VRefresh();
}

void VSetFlipY (bool f)
{
	V.FlipY = f;
	VRefresh();
}

void VPan (int dx, int dy)
{
	V.Fit = false;
	
	V.X += dx;
	V.Y += dy;
	
	VConfigure();
}

void VToggleSmooth ()
{
	V.Smooth = !V.Smooth;
	VRefresh();
}

void VToggleTile ()
{
	V.Tile = !V.Tile;
	VRefresh();
}

void VNextBack ()
{
	V.BgColor++;
	if (V.BgColor >= (int) ALEN(V.BgColors)) V.BgColor = 0;
	VRefresh();
}

void VEnableCursor (bool on)
{
	XEnableCursor(V.Cursor = on);
}

void VToggleFullScreen ()
{
	V.Fit = true;
	VEnableCursor(!(V.FullScreen = !V.FullScreen));
	
	XSendEvent (
		X.Display, DefaultRootWindow(X.Display), 0,
		SubstructureNotifyMask | SubstructureRedirectMask,
		(XEvent*) &(XClientMessageEvent) {
			.type = ClientMessage, .window = V.Window, .format = 32,
			.message_type = XInternAtom(X.Display, "_NET_WM_STATE", 0),
			.data.l[1] = XInternAtom(X.Display, "_NET_WM_STATE_FULLSCREEN", 0),
			.data.l[0] = V.FullScreen,
		}
	);
}

int FnmCmp (const void* s0, const void* s1)
{
	return strcmp(*(const char**)s0, *(const char**)s1);
}

void VListFiles ()
{
	if (V.Files)
		for (char** f = V.Files; f < V.Files + V.FilesCount; f++)
			free(f);
	free(V.Files);
	
	struct dirent* de;
	DIR* dir = opendir(V.FilesDir);
	V.FilesCount = 0;
	
	while ((de = readdir(dir)))
	{
		if (!strcmp(de->d_name, V.FileName)) V.FilePos = V.FilesCount;
		V.FilesCount++;
	}
	
	rewinddir(dir);
	V.Files = malloc(sizeof(char*) * V.FilesCount);
	
	for (char** f = V.Files; (de = readdir(dir)); f++)
	{
		*f = strdup(de->d_name);
	}
	
	closedir(dir);
	
	qsort(V.Files, V.FilesCount, sizeof(char*), FnmCmp);
	
	for (int i = 0; i < V.FilesCount; i++) {
		if (!strcmp(V.FileName, V.Files[i])) {
			V.FilePos = i;
			break;
		}
	}
}

void VNext (int seek)
{
	if (!V.Files) VListFiles();
	int start = V.FilePos;
	
	char path[PATH_MAX];
	
	for (;;)
	{
		V.FilePos += seek;
		
		if (V.FilePos < 0) V.FilePos = V.FilesCount - 1;
		else if (V.FilePos >= V.FilesCount) V.FilePos = 0;
		
		snprintf(path, sizeof(path), "%s/%s", V.FilesDir, V.Files[V.FilePos]);
		
		if (VLoadNew(path)) break;
		else if (start == V.FilePos) exit(0);
	}
}

void Esq (char* e, const char* s)
{
	for (; *s; ++s, ++e)
	{
		switch (*s)
		{
			case '"': case '\\': *(e++) = '\\'; *e = *s; break;
			default: *e = *s; break;
		}
	}
	
	*e = 0;
}

void VLaunch (const char* com, const char* path, bool wait)
{
	char exe[PATH_MAX];
	char esq[PATH_MAX];
	
	Esq(esq, path);
	
	strcpy(exe, com);
	strcat(exe, " \"");
	strcat(exe, esq);
	strcat(exe, wait ? "\"" : "\" &");
	
	system(exe);
}

void VLaunchF (int fn, bool wait)
{
	char com[16];
	sprintf(com, "vewr-F%i", fn);
	VLaunch(com, V.FilePath, wait);
}

void VDelete ()
{
	VLaunch("gio trash", V.FilePath, true);
	VNext(+1);
}

void VToggleCursor ()
{
	VEnableCursor(!V.Cursor);
}




void XOnExpose (const XExposeEvent* e)
{
	if (V.Exposed)
	{
		if (e->x < V.Invalid.L) V.Invalid.L = e->x;
		if (e->y < V.Invalid.T) V.Invalid.T = e->y;
		if (e->x + e->width > V.Invalid.R) V.Invalid.R = e->x + e->width;
		if (e->y + e->height > V.Invalid.B) V.Invalid.B = e->y + e->height;
	}
	else
	{
		V.Invalid.L = e->x;
		V.Invalid.T = e->y;
		V.Invalid.R = e->x + e->width;
		V.Invalid.B = e->y + e->height;
	}
	
	V.Exposed = true;
}

void XOnConfigure (const XConfigureEvent* e)
{
	if (
		e->width == V.W &&
		e->height == V.H
	) return;
	
	V.W = e->width;
	V.H = e->height;
	
	if (V.Buffer)
	{
		imlib_context_set_image(V.Buffer);
		imlib_free_image();
	}
	
	V.Buffer = imlib_create_image(V.W, V.H);
	
	VRefresh();
}

void XOnMotion (const XMotionEvent* e)
{
	int dx = e->x - V.PreCur.X;
	int dy = e->y - V.PreCur.Y;
	
	if (e->state & Button1Mask)
	{
		V.Fit = false;
		
		V.X += dx;
		V.Y += dy;
		
		VConfigure();
	}
	
	V.PreCur.X = e->x;
	V.PreCur.Y = e->y;
}

void XOnButtonPress (const XButtonEvent* e)
{
	if (V.FullScreen && !V.Cursor)
	{
		V.PreCur.X = V.W / 2, V.PreCur.Y = V.H / 2;
		XWarpPointer(X.Display, 0, V.Window, 0, 0, 0, 0, V.PreCur.X, V.PreCur.Y);
		XEnableCursor(true);
	}
	
	if (
		e->time - V.LastClickTime < 400 &&
		e->button == V.LastClickButton
	) V.ClickNumber++;
	else V.ClickNumber = 1;
	
	V.LastClickButton = e->button;
	V.LastClickTime = e->time;
	
	switch (e->button)
	{
		case Button4: VRelZoom(+.5, e->x, e->y); break;
		case Button5: VRelZoom(-.5, e->x, e->y); break;
	}
}

void XOnButtonRelease (const XButtonEvent* e)
{
	if (V.FullScreen && !V.Cursor)
	{
		XEnableCursor(false);
	}
	
	switch (e->button)
	{
		case Button1: if (V.ClickNumber == 2) VToggleFullScreen(); break;
		case Button2: VToggleFit(e->x, e->y); break;
		case Button3: VNext(e->x < V.W / 2 ? -1 : +1); break;
	}
}

void XOnKeyPress (const XKeyPressedEvent* e)
{
	KeySym ks = XLookupKeysym((XKeyEvent*)e, 0);
	
	if (ks >= XK_1 && ks <= XK_9) VZoom(pow(2, ks - XK_1), -1, -1);
	else if (ks >= XK_F1 && ks <= XK_F12) VLaunchF(ks - XK_F1 + 1, false);
	else if (e->state & ShiftMask) switch (ks)
	{
		case XK_Left: VPan(+64, 0); break;
		case XK_Right: VPan(-64, 0); break;
		case XK_Up: VPan(0, +64); break;
		case XK_Down: VPan(0, -64); break;
		case XK_z: VSetFitMode(STRETCH); break;
	}
	else if (e->state & ControlMask) switch (ks)
	{
		case XK_Left: VSetFlipX(true); break;
		case XK_Right: VSetFlipX(false); break;
		case XK_Up: VSetFlipY(true); break;
		case XK_Down: VSetFlipY(false); break;
	}
	else switch (ks)
	{
		case XK_s: VToggleSmooth(); break;
		case XK_space: VToggleFit(-1, -1); break;
		case XK_b: VNextBack(); break;
		case XK_Return: VToggleFullScreen(); break;
		case XK_Escape: exit(0); break;
		case XK_Left: VNext(-1); break;
		case XK_Right: VNext(+1); break;
		case XK_Up: VRelZoom(+1, -1, -1); break;
		case XK_Down: VRelZoom(-1, -1, -1); break;
		case XK_t: VToggleTile(); break;
		case XK_Delete: VDelete(); break;
		case XK_c: VToggleCursor(); break;
		case XK_f: VSetFitMode(INNER); break;
		case XK_z: VSetFitMode(OUTER); break;
	}
}

void XOnClientMessage (const XClientMessageEvent* e)
{
	if ((Atom)e->data.l[0] == X.WM_DELETE_MESSAGE)
	{
		exit(0);
	}
}




int main (int argc, char** argv)
{
	if (argc < 2) return 1;
	
	for (int i = 2; i < argc; ++i)
		VLaunch(argv[0], argv[i], false);
	
	setbuf(stdout, 0);
	setlocale(LC_ALL, "");
	imlib_set_cache_size(0);
	
	X.Display = XOpenDisplay(0);
	X.ScreenId = DefaultScreen(X.Display);
	X.Screen = DefaultScreenOfDisplay(X.Display);
	X.Colormap = DefaultColormap(X.Display, X.ScreenId);
	X.Visual = DefaultVisual(X.Display, X.ScreenId);
	
	char atmp[PATH_MAX]; strcpy(atmp, argv[1]);
	V.FilesDir = strdup(dirname(atmp));
	if (!VLoad(argv[1])) return 1;
	
	static const int safeguess = 32;
	int sw, sh; XGetScreenWH(&sw, &sh);
	sw -= safeguess * 2, sh -= safeguess * 2;
	int ww = V.Src.W, wh = V.Src.H;
	while (ww > sw || wh > sh) ww /= 2, wh /= 2;
	
	static const int minsize = 128;
	bool toosmall = false;
	
	if (V.Src.W < minsize) toosmall |= !!(ww = minsize);
	if (V.Src.H < minsize) toosmall &= !!(wh = minsize);
	
	if (toosmall)
	{
		V.Fit = false;
		V.Smooth = false;
	}
	
	V.Window = XCreateSimpleWindow (
		X.Display, DefaultRootWindow(X.Display), 
		0, 0, ww, wh, 0, 0, 0
	);
	
	XSetThumbIcon();
	VUpdateInfo();
	
	XSelectInput ( X.Display, V.Window,
		ExposureMask | StructureNotifyMask | KeyPressMask |
		PointerMotionMask | ButtonPressMask | ButtonReleaseMask
	);
	
	X.WM_DELETE_MESSAGE = XInternAtom(X.Display, "WM_DELETE_WINDOW", 0);
	XSetWMProtocols(X.Display, V.Window, &X.WM_DELETE_MESSAGE, 1);
	
	V.Context = XCreateGC(X.Display, V.Window, 0, 0);
	XSetWindowBackground(X.Display, V.Window, None);
	XSetWindowBackgroundPixmap(X.Display, V.Window, None);
	XMapWindow(X.Display, V.Window);
	
	imlib_context_set_display(X.Display);
	imlib_context_set_visual(X.Visual);
	imlib_context_set_colormap(X.Colormap);
	imlib_context_set_drawable(V.Window);
	
	for ( XEvent e ;; )
	{
		XNextEvent(X.Display, &e);
		
		switch (e.type)
		{
			case Expose: XOnExpose((XExposeEvent*)&e); break;
			case ConfigureNotify: XOnConfigure((XConfigureEvent*)&e); break;
			case MotionNotify: XOnMotion((XMotionEvent*)&e); break;
			case ButtonPress: XOnButtonPress((XButtonEvent*)&e); break;
			case ButtonRelease: XOnButtonRelease((XButtonEvent*)&e); break;
			case KeyPress: XOnKeyPress((XKeyPressedEvent*)&e); break;
			case ClientMessage: XOnClientMessage((XClientMessageEvent*)&e); break;
		}
		
		if (!XPending(X.Display))
		{
			VRender();
		}
	}
	
	return 0;
}
