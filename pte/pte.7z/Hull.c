#define HULL_TEXTURE_RES 16
#define HULL_TEXTURE_INC 16
#define HULL_TEXTURE_BLUR_DIV 2
#define HULL_NEAR -0.1


typedef Syxel HTexel;

typedef struct Hull Hull;
typedef struct HPass HPass;

typedef real HullSampler (HTexel* ot, Xyz up, fu32 res, const void*, const Hull*);
typedef void HullPainter (HTexel* ot, Xyz up, Xyz p, Xyz n, const void*, const Hull*);


typedef struct HVert {
	
	Xyz Up;
	Xyz Point;
	
	bool Shaded;
	bool Behind;
	Xyz ProPoint;
	Apex Apex;
	
} HVert;

typedef struct HEdge {
	
	u8 Depth;
	HVert* V[2], C;
	
	struct HEdge* Sub;
	
} HEdge;

typedef struct HQuad {
	
	HVert* V[4], C;
	HEdge* E[4];
	
	fu32 Res;
	fake Bounds;
	
	fu16 Progress;
	HTexel Texture[P2(HULL_TEXTURE_RES)];
	bool Ready;
	bool Alpha;
	
	struct HQuadSub* Sub;
	
} HQuad;

typedef struct HQuadSub {
	
	HEdge E[4];
	HQuad Q[4];
	
} HQuadSub;

struct Hull
{
	Seed Seed;
	
	real Radius;
	real MinCutoff;
	
	int MinDepth;
	int MaxDepth;
	
	Rgb ZenFog, ZenAmb, ZenDir;
	Rgb TanFog, TanAmb, TanDir;
	
	fake FogMul;
	fake FogMax;
	
	Rgb Glow;
	
	fu32 GeometryRes;
	
	HullSampler* Sample;
	HullPainter* Paint;
	PixelShader* ShadeFront;
	PixelShader* ShadeBack;
	
	HVert* Verts; fu16 VertsCount;
	HEdge* Edges; fu16 EdgesCount;
	HQuad* Quads; fu16 QuadsCount;
};

typedef struct { Xy T[4], C; } HQuvs;

const HQuvs HRootQuvs = { {
	{ 0, 0 }, { 0, HULL_TEXTURE_RES },
	{ HULL_TEXTURE_RES, HULL_TEXTURE_RES },
	{ HULL_TEXTURE_RES, 0 }
}, { HULL_TEXTURE_RES / 2, HULL_TEXTURE_RES / 2 } };

struct HPass
{
	const Eye* Eye;
	const Pov* Pov;
	
	void* Tag;
	Hull* Hull;
	
	fake Cutoff;
	const Liting* Liting;
};




Xyz HPFromUV (const HQuad* q, fake u, fake v)
{
	fake wx1 = u, wx0 = 1 - wx1;
	fake wy1 = v, wy0 = 1 - wy1;
	
	const Xyz* p0 = &q->V[0]->Point; fake w0 = wx0 * wy0;
	const Xyz* p1 = &q->V[1]->Point; fake w1 = wx0 * wy1;
	const Xyz* p2 = &q->V[2]->Point; fake w2 = wx1 * wy1;
	const Xyz* p3 = &q->V[3]->Point; fake w3 = wx1 * wy0;
	
	return (Xyz) {
		p0->X * w0 + p1->X * w1 + p2->X * w2 + p3->X * w3,
		p0->Y * w0 + p1->Y * w1 + p2->Y * w2 + p3->Y * w3,
		p0->Z * w0 + p1->Z * w1 + p2->Z * w2 + p3->Z * w3,
	};
}

Xyz HPFromIUV (const HQuad* q, fu8 u, fu8 v)
{
	return HPFromUV ( q,
		(0.5 + u) * (1.0 / HULL_TEXTURE_RES),
		(0.5 + v) * (1.0 / HULL_TEXTURE_RES)
	);
}

void HUpdateTexture (HQuad* q, const HPass* p)
{
	for (fu16 i = 0; i < HULL_TEXTURE_INC / 2; ++i)
	{
		fu8 u0 = (q->Progress % (HULL_TEXTURE_RES / 2)) * 2, u1 = u0 + 1;
		fu8 v0 = (q->Progress / (HULL_TEXTURE_RES / 2)) * 2, v1 = v0 + 1;
		
		HTexel* t0 = q->Texture + u0 + v0 * HULL_TEXTURE_RES;
		HTexel* t1 = q->Texture + u0 + v1 * HULL_TEXTURE_RES;
		HTexel* t2 = q->Texture + u1 + v1 * HULL_TEXTURE_RES;
		HTexel* t3 = q->Texture + u1 + v0 * HULL_TEXTURE_RES;
		
		Xyz p0 = HPFromIUV(q, u0, v0), up0 = Norm(p0, 1);
		Xyz p1 = HPFromIUV(q, u0, v1), up1 = Norm(p1, 1);
		Xyz p2 = HPFromIUV(q, u1, v1), up2 = Norm(p2, 1);
		Xyz p3 = HPFromIUV(q, u1, v0), up3 = Norm(p3, 1);
		
		p0 = Mul(up0, p->Hull->Sample(t0, up0, q->Res, p->Tag, p->Hull));
		p1 = Mul(up1, p->Hull->Sample(t1, up1, q->Res, p->Tag, p->Hull));
		p2 = Mul(up2, p->Hull->Sample(t2, up2, q->Res, p->Tag, p->Hull));
		p3 = Mul(up3, p->Hull->Sample(t3, up3, q->Res, p->Tag, p->Hull));
		
		if (t0->A) p->Hull->Paint(t0, up0, p0, TriNormal(p3, p0, p1), p->Tag, p->Hull);
		if (t1->A) p->Hull->Paint(t1, up1, p1, TriNormal(p0, p1, p2), p->Tag, p->Hull);
		if (t2->A) p->Hull->Paint(t2, up2, p2, TriNormal(p1, p2, p3), p->Tag, p->Hull);
		if (t3->A) p->Hull->Paint(t3, up3, p3, TriNormal(p2, p3, p0), p->Tag, p->Hull);
		
		q->Alpha |= t0->A || t1->A || t2->A || t3->A;
		
		if (++q->Progress >= P2(HULL_TEXTURE_RES / 2))
		{
			q->Ready = true;
			return;
		}
	}
}

const HTexel* HRefTexel (const HTexel* t, fake u, fake v)
{
	fu8 iu = CLAMP(0, u, HULL_TEXTURE_RES - 1);
	fu8 iv = CLAMP(0, v, HULL_TEXTURE_RES - 1);
	
	return t + iv * HULL_TEXTURE_RES + iu;
}




HVert* HSharedVert (const HEdge* a, const HEdge* b)
{
	if (a->V[0] == b->V[0] || a->V[0] == b->V[1]) return a->V[0];
	if (a->V[1] == b->V[0] || a->V[1] == b->V[1]) return a->V[1];
	
	return 0;
}

HEdge* HWhich (const HEdge* e, const HVert* v)
{
	if (e->V[0] == v) return e->Sub + 0;
	else return e->Sub + 1;
}




void InitHVert (HVert* v, Xyz p, const void* w, const Hull* h)
{
	v->Up = Norm(p, 1);
	v->Point = Mul(v->Up, h->Sample(0, v->Up, h->GeometryRes, w, h));
}

void InitHEdge (HEdge* e, HVert* v0, HVert* v1, const void* w, const Hull* h, u8 depth)
{
	e->V[0] = v0;
	e->V[1] = v1;
	
	InitHVert(&e->C, Mid(v0->Point, v1->Point), w, h);
	
	e->Sub = 0;
	e->Depth = depth;
}

void InitHQuad ( const HQuad* pq, HQuad* q,
	HEdge* e0, HEdge* e1, HEdge* e2, HEdge* e3,
	const void* w, const Hull* h
) {
	q->E[0] = e0; q->V[0] = HSharedVert(e3, e0);
	q->E[1] = e1; q->V[1] = HSharedVert(e0, e1);
	q->E[2] = e2; q->V[2] = HSharedVert(e1, e2);
	q->E[3] = e3; q->V[3] = HSharedVert(e2, e3);
	
	InitHVert ( &q->C,
		Mid (
			Mid(q->V[0]->Point, q->V[2]->Point),
			Mid(q->V[1]->Point, q->V[3]->Point)
		),
	w, h );
	
	q->Bounds = sqrt ( Max (
		Max (
			Qis(q->C.Point, q->V[0]->Point),
			Qis(q->C.Point, q->V[1]->Point)
		),
		Max (
			Qis(q->C.Point, q->V[2]->Point),
			Qis(q->C.Point, q->V[3]->Point)
		)
	) );
	
	q->Sub = 0;
	q->Progress = 0;
	q->Ready = 0;
	q->Alpha = 0;
	
	if (pq) q->Res = pq->Res * 2;
	else q->Res = HULL_TEXTURE_RES / HULL_TEXTURE_BLUR_DIV;
}




void HSplitEdge (HEdge* e, const void* w, const Hull* h)
{
	e->Sub = NEW(HEdge, 2);
	
	InitHEdge(e->Sub + 0, e->V[0], &e->C, w, h, e->Depth + 1);
	InitHEdge(e->Sub + 1, &e->C, e->V[1], w, h, e->Depth + 1);
}

void HSplitQuad (HQuad* q, const void* w, const Hull* h)
{
	q->Sub = NEW(HQuadSub);
	
	HEdge* es = q->Sub->E;
	HQuad* qs = q->Sub->Q;
	
	InitHEdge(es + 0, &q->E[0]->C, &q->C, w, h, q->E[0]->Depth + 1);
	InitHEdge(es + 1, &q->E[1]->C, &q->C, w, h, q->E[1]->Depth + 1);
	InitHEdge(es + 2, &q->E[2]->C, &q->C, w, h, q->E[2]->Depth + 1);
	InitHEdge(es + 3, &q->E[3]->C, &q->C, w, h, q->E[3]->Depth + 1);
	
	HEdge *w00 = HWhich(q->E[0], q->V[0]), *w01 = HWhich(q->E[0], q->V[1]);
	HEdge *w11 = HWhich(q->E[1], q->V[1]), *w12 = HWhich(q->E[1], q->V[2]);
	HEdge *w22 = HWhich(q->E[2], q->V[2]), *w23 = HWhich(q->E[2], q->V[3]);
	HEdge *w33 = HWhich(q->E[3], q->V[3]), *w30 = HWhich(q->E[3], q->V[0]);
	
	InitHQuad(q, qs + 0, w00, es + 0, es + 3, w30, w, h);
	InitHQuad(q, qs + 1, w11, es + 1, es + 0, w01, w, h);
	InitHQuad(q, qs + 2, w22, es + 2, es + 1, w12, w, h);
	InitHQuad(q, qs + 3, w33, es + 3, es + 2, w23, w, h);
}


void HClearEdge (HEdge* e)
{
	if (!e->Sub) return;
	
	HClearEdge(e->Sub + 0);
	HClearEdge(e->Sub + 1);
	
	ZAP0(e->Sub);
}

void HClearQuad (HQuad* q)
{
	if (!q->Sub) return;
	
	HClearEdge(q->Sub->E + 0);
	HClearEdge(q->Sub->E + 1);
	HClearEdge(q->Sub->E + 2);
	HClearEdge(q->Sub->E + 3);
	
	HClearQuad(q->Sub->Q + 0);
	HClearQuad(q->Sub->Q + 1);
	HClearQuad(q->Sub->Q + 2);
	HClearQuad(q->Sub->Q + 3);
	
	ZAP0(q->Sub);
}




void HProcessEdge (HEdge* e, const HPass* p, fake qlod)
{
	if (
		( e->Depth < p->Hull->MinDepth ||
			Qis(e->C.Point, p->Pov->Loc) < qlod
		) && e->Depth < p->Hull->MaxDepth
	) {
		if (!e->Sub) HSplitEdge(e, p->Tag, p->Hull);
		
		qlod *= 0.25;
		
		HProcessEdge(e->Sub + 0, p, qlod);
		HProcessEdge(e->Sub + 1, p, qlod);
	}
	
	else HClearEdge(e);
}

void HProcessQuad (HQuad* q, const HPass* p, fake qlod)
{
	if (
		q->E[0]->Sub && q->E[1]->Sub &&
		q->E[2]->Sub && q->E[3]->Sub
	) {
		if (!q->Sub) HSplitQuad(q, p->Tag, p->Hull);
		
		qlod *= 0.25;
		
		HProcessEdge(q->Sub->E + 0, p, qlod);
		HProcessEdge(q->Sub->E + 1, p, qlod);
		HProcessEdge(q->Sub->E + 2, p, qlod);
		HProcessEdge(q->Sub->E + 3, p, qlod);
		
		HProcessQuad(q->Sub->Q + 0, p, qlod);
		HProcessQuad(q->Sub->Q + 1, p, qlod);
		HProcessQuad(q->Sub->Q + 2, p, qlod);
		HProcessQuad(q->Sub->Q + 3, p, qlod);
	}
	
	else HClearQuad(q);
}




void HRenderVert (HVert* v, const HPass* p)
{
	v->Shaded = false;
	v->ProPoint = LocProPov(v->Point, p->Pov);
	if ((v->Behind = v->ProPoint.Z > HULL_NEAR)) return;
}

void HShadeVert (HVert* v, const HPass* p)
{
	v->Shaded = true;
	
	v->Apex.X = EyeV2SX(p->Eye, v->ProPoint.X, v->ProPoint.Z);
	v->Apex.Y = EyeV2SX(p->Eye, v->ProPoint.Y, v->ProPoint.Z);
	
	v->Apex.Z = v->ProPoint.Z;
	
	fake upz = fabs(Zenith(v->Point, v->Up, p->Pov->Loc));
	fake cls = 1 / (1 + Qis(v->Point, p->Pov->Loc) * p->Hull->FogMul);
	fake fog = (1 - upz) * (1 - cls) * p->Hull->FogMax;
	
	v->Apex.R = p->Hull->Glow.R;
	v->Apex.G = p->Hull->Glow.G;
	v->Apex.B = p->Hull->Glow.B;
	
	for EACHC (const Lamp*, l, p->Liting->Lamps)
	{
		fake zen = Dot(v->Up, l->Point); if (zen < 0) zen = 0;
		fake tan = (1 - zen) * zen;
		
		v->Apex.R += l->Light.R * (zen * p->Hull->ZenFog.R + tan * p->Hull->TanFog.R);
		v->Apex.G += l->Light.G * (zen * p->Hull->ZenFog.G + tan * p->Hull->TanFog.G);
		v->Apex.B += l->Light.B * (zen * p->Hull->ZenFog.B + tan * p->Hull->TanFog.B);
	}
	
	v->Apex.W = fog * 0xFF;
	
	v->Apex.R *= v->Apex.W;
	v->Apex.G *= v->Apex.W;
	v->Apex.B *= v->Apex.W;
}

void HRenderEdge (HEdge* e, const HPass* p)
{
	HRenderVert(&e->C, p);
	
	if (e->Sub)
	{
		HRenderEdge(e->Sub + 0, p);
		HRenderEdge(e->Sub + 1, p);
	}
}

void HRenderTri (
	HVert* v0, HVert* v1, HVert* v2,
	Xy uv0, Xy uv1, Xy uv2, const HQuad* t, const HPass* p
) {
	if (v0->Behind || v1->Behind || v2->Behind) return;
	
	PixelShader* sha = TriFront (
		v0->Point, v1->Point, v2->Point, p->Pov->Loc
	) ? p->Hull->ShadeFront : p->Hull->ShadeBack;
	if (!sha) return;
	
	if (!v0->Shaded) HShadeVert(v0, p);
	if (!v1->Shaded) HShadeVert(v1, p);
	if (!v2->Shaded) HShadeVert(v2, p);
	
	v0->Apex.U = uv0.X, v0->Apex.V = uv0.Y;
	v1->Apex.U = uv1.X, v1->Apex.V = uv1.Y;
	v2->Apex.U = uv2.X, v2->Apex.V = uv2.Y;
	
	DrawTri(p->Eye, sha, t->Texture, &v0->Apex, &v1->Apex, &v2->Apex);
}

void HRenderSegment (
	HVert* vc, HVert* v0, HEdge* e, HVert* v1,
	Xy uvc, Xy uv0, Xy uv1, const HQuad* t, const HPass* p
) {
	if (e->Sub) {
		
		Xy uvm = Mid2(uv0, uv1);
		
		HRenderSegment(vc, v0, HWhich(e, v0), &e->C, uvc, uv0, uvm, t, p);
		HRenderSegment(vc, &e->C, HWhich(e, v1), v1, uvc, uvm, uv1, t, p);
	
	} else HRenderTri(vc, v0, v1, uvc, uv0, uv1, t, p);
}

void HRenderQuad (
	const HQuad* pq, HQuad* q, fu8 i,
	const HQuad* t, const HQuvs* c, const HPass* p
) {
	HRenderVert(&q->C, p);
	
	if (!EyeSphereSeen(p->Eye, HULL_NEAR, q->C.ProPoint, q->Bounds)) return;
	if (Qen(q->C.ProPoint) > P2(p->Cutoff + q->Bounds)) return;
	
	if (!q->Ready && (!pq || pq->Ready))
		HUpdateTexture(q, p);
	
	if (q->Ready) { t = q; c = &HRootQuvs; }
	else c = &(HQuvs) { {
		c->T[i], Mid2(c->T[i], c->T[(i + 1) % 4]),
		c->C, Mid2(c->T[(i + 3) % 4], c->T[i])
	}, Mid2(c->T[i], c->C) };
	
	if (q->Sub)
	{
		HRenderEdge(q->Sub->E + 0, p);
		HRenderEdge(q->Sub->E + 1, p);
		HRenderEdge(q->Sub->E + 2, p);
		HRenderEdge(q->Sub->E + 3, p);
		
		HRenderQuad(q, q->Sub->Q + 0, 0, t, c, p);
		HRenderQuad(q, q->Sub->Q + 1, 1, t, c, p);
		HRenderQuad(q, q->Sub->Q + 2, 2, t, c, p);
		HRenderQuad(q, q->Sub->Q + 3, 3, t, c, p);
	}
	else if (t->Alpha)
	{
		HRenderSegment(&q->C, q->V[0], q->E[0], q->V[1], c->C, c->T[0], c->T[1], t, p);
		HRenderSegment(&q->C, q->V[1], q->E[1], q->V[2], c->C, c->T[1], c->T[2], t, p);
		HRenderSegment(&q->C, q->V[2], q->E[2], q->V[3], c->C, c->T[2], c->T[3], t, p);
		HRenderSegment(&q->C, q->V[3], q->E[3], q->V[0], c->C, c->T[3], c->T[0], t, p);
	}
}

void RenderHull (const HPass* p, fake qlod)
{
	for EACHC (HEdge*, e, p->Hull->Edges) HProcessEdge(e, p, qlod);
	for EACHC (HQuad*, q, p->Hull->Quads) HProcessQuad(q, p, qlod);
	
	for EACHC (HVert*, v, p->Hull->Verts) HRenderVert(v, p);
	for EACHC (HEdge*, e, p->Hull->Edges) HRenderEdge(e, p);
	for EACHC (HQuad*, q, p->Hull->Quads) HRenderQuad(0, q, 0, q, &HRootQuvs, p);
}
