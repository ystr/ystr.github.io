rm -r /usr/local/share/Lma
rm /usr/local/bin/lma
rm /usr/local/bin/lmar
rm /usr/local/share/gtksourceview-3.0/language-specs/lma.lang
rm /usr/local/share/mime/packages/lma.xml
update-mime-database /usr/local/share/mime
