using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using Microsoft.Win32;

class Config
{
	static bool portable = false;
	public static event Action PortableChanged = () => {};
	public static bool Portable {
		get { return portable; }
		set {
			if (value == portable) return;
			portable = value; PortableChanged();
		}
	}
	
	static readonly Dictionary<string, string> data = new Dictionary<string, string>();
	static readonly string IniPath = Own.ExeDir + "\\" + Own.Name + ".ini";
	
	static readonly string RegPath = "Software\\" + Own.Name;
	
	static Config ()
	{
		Portable = File.Exists(IniPath);
		Load();
	}
	
	static void LoadFromRegistry ()
	{
		using (RegistryKey rk = Registry.CurrentUser.OpenSubKey(RegPath))
		{
			if (rk == null) return;
			string[] vs = rk.GetValueNames();
			foreach (string v in vs) data[v] = rk.GetValue(v) as string;
		}
	}
	
	static void SaveToRegistry ()
	{
		using (RegistryKey rk = Registry.CurrentUser.CreateSubKey(RegPath))
		{
			foreach (var s in data) rk.SetValue(s.Key, s.Value);
		}
	}
	
	static void LoadFromIni ()
	{
		if (!File.Exists(IniPath)) return;
		string[] lines = File.ReadAllLines(IniPath);
		
		foreach (string l in lines)
		{
			if (!l.Contains("=")) continue;
			string[] kv = l.Split(new char[] { '=' }, 2);
			data[kv[0].Trim()] = kv[1].Trim();
		}
	}
	
	static void SaveToIni ()
	{
		StreamWriter w = new StreamWriter(IniPath);
		foreach (var r in data) w.WriteLine(r.Key + " = " + r.Value);
		w.Close();
	}
	
	public static void Load ()
	{
		if (Portable) LoadFromIni();
		else LoadFromRegistry();
	}
	
	public static void Save ()
	{
		if (Portable) SaveToIni();
		else {
			File.Delete(IniPath);
			SaveToRegistry();
		}
	}
	
	delegate T XYHandler <T> (int x, int y);
	static T Decode <T> (string s, XYHandler <T> clo)
	{
		string[] ss = s.Split('*');
		return clo(Convert.ToInt32(ss[0]), Convert.ToInt32(ss[1]));
	}
	
	static string Encode (int x, int y)
	{
		return x.ToString() + "*" + y.ToString();
	}
	
	
	public static T Get <T> (string key, T d)
	{
		if (!data.ContainsKey(key)) { Set(key, d); return d; }
		string v = data[key];
		object r = v;
		
		switch (typeof(T).Name)
		{
			case "Size": r = Decode(v, (x, y) => new Size(x, y)); break;
			case "Point": r = Decode(v, (x, y) => new Point(x, y)); break;
			case "Int32": r = Convert.ToInt32(v); break;
			case "Single": r = Single.Parse(v, CultureInfo.InvariantCulture); break;
			case "String": r = v; break;
			case "String[]": r = v.Split('\x1F'); break;
			case "Boolean": r = Convert.ToBoolean(v); break;
			case "Encoding": r = Encoding.GetEncoding(v); break;
			default: throw new Exception("Unknown Type: " + typeof(T).Name);
		}
		
		return (T) r;
	}
	
	public static T Set <T> (string key, T vv)
	{
		object v = vv;
		string w = null;
		
		switch (typeof(T).Name)
		{
			case "Size": Size s = (Size) v; w = Encode(s.Width, s.Height); break;
			case "Point": Point p = (Point) v; w = Encode(p.X, p.Y); break;
			case "Int32": w = v.ToString(); break;
			case "Single": w = ((Single)v).ToString(CultureInfo.InvariantCulture); break;
			case "String": w = (string) v; break;
			case "Boolean": w = v.ToString(); break;
			case "String[]": w = string.Join("\x1F", (string[]) v); break;
			case "Encoding": w = ((Encoding)v).WebName; break;
			default: throw new Exception("Unknown Type: " + typeof(T).Name);
		}
		
		data[key] = w;
		return vv;
	}
	
	public static void SemaSet (object o)
	{
		foreach (FieldInfo fi in o.GetType().GetFields())
		{
			string fieldName = fi.Name;
			bool isGeneric = fi.FieldType.IsGenericType;
			
			if (!isGeneric) continue;
			
			string genericTypeName = fi.FieldType.GetGenericTypeDefinition().Name.Split('`')[0];
			
			if (genericTypeName != "Option") continue;
			
			object fieldValue = fi.GetValue(o);
			
			Set(fieldName, (fieldValue as Entry).AsString);
		}
	}
}