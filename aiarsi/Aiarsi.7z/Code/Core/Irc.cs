using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;

static class Irc
{
	public const string ERROR = "ERROR";
	public const string INVITE = "INVITE";
	public const string JOIN = "JOIN";
	public const string KICK = "KICK";
	public const string LIST = "LIST";
	public const string MODE = "MODE";
	public const string NICK = "NICK";
	public const string NOTICE = "NOTICE";
	public const string PART = "PART";
	public const string PING = "PING";
	public const string PONG = "PONG";
	public const string PRIVMSG = "PRIVMSG";
	public const string TOPIC = "TOPIC";
	public const string QUIT = "QUIT";
	public const string USER = "USER";
	
	public const string WTF_PLEASEWAIT = "020";
	
	public const string RPL_WELCOME = "001";
	public const string RPL_YOURHOST = "002";
	public const string RPL_CREATED = "003";
	public const string RPL_LUSERCLIENT = "251";
	public const string RPL_LUSEROP = "252";
	public const string RPL_LUSERUNKNOWN = "253";
	public const string RPL_LUSERCHANNELS = "254";
	public const string RPL_LUSERME = "255";
	public const string RPL_ADMINME = "256";
	public const string RPL_LOCALUSERS = "265";
	public const string RPL_GLOBALUSERS = "266";
	public const string RPL_AWAY = "301";
	public const string RPL_UNAWAY = "305";
	public const string RPL_NOWAWAY = "306";
	public const string RPL_WHOISUSER = "311";
	public const string RPL_WHOISSERVER = "312";
	public const string RPL_WHOISOPERATOR = "313";
	public const string RPL_WHOWASUSER = "314";
	public const string RPL_ENDOFWHO = "315";
	public const string RPL_WHOISIDLE = "317";
	public const string RPL_ENDOFWHOIS = "318";
	public const string RPL_WHOISCHANNELS = "319";
	public const string RPL_LISTSTART = "321";
	public const string RPL_LIST = "322";
	public const string RPL_LISTEND = "323";
	public const string RPL_CHANNELMODEIS = "324";
	public const string RPL_CREATIONTIME = "329";
	public const string RPL_NOTOPIC = "331";
	public const string RPL_TOPIC = "332";
	public const string RPL_TOPICWHOTIME = "333";
	public const string RPL_INVITING = "341";
	public const string RPL_NAMREPLY = "353";
	public const string RPL_ENDOFNAMES = "366";
	public const string RPL_MOTD = "372";
	public const string RPL_MOTDSTART = "375";
	public const string RPL_ENDOFMOTD = "376";
	public const string ERR_NOSUCHNICK = "401";
	public const string ERR_NOSUCHCHANNEL = "403";
	public const string ERR_CANNOTSENDTOCHAN = "404";
	public const string ERR_WASNOSUCHNICK  = "406";
	public const string ERR_UNKNOWNCOMMAND = "421";
	public const string ERR_NICKNAMEINUSE = "432";
	public const string ERR_NICKTOOFAST = "438";
	public const string ERR_ERRONEUSNICKNAME = "433";
	public const string ERR_USERONCHANNEL = "443";
	public const string ERR_ALREADYREGISTERED = "462";
	public const string ERR_KEYSET = "467";
	public const string ERR_CHANNELISFULL = "471";
	public const string ERR_INVITEONLYCHAN = "473";
	public const string ERR_BANNEDFROMCHAN = "474";
	public const string ERR_BADCHANNELKEY = "475";
	public const string ERR_NEEDREGGEDNICK = "477";
	public const string ERR_CHANOPRIVSNEEDED  = "482";
	public const string ERR_USERSDONTMATCH = "502";
	
	
	static readonly Dictionary<string, string> Coms = new Dictionary<string, string>();
	static public bool Known (string c) { return Coms.ContainsKey(c); }
	
	static Irc ()
	{
		foreach (FieldInfo f in typeof(Irc).GetFields())
		{
			if (f.FieldType != typeof(string)) continue;
			
			string n = f.Name;
			string v = f.GetRawConstantValue() as string;
			Coms[v] = n;
		}
	}
	
	
	static public string StripFormatting (this string s)
	{
		return Regex.Replace(s, @"[\x02\x1F\x0F\x16]|\x03(\d\d?(,\d\d?)?)?", "");
	}
	
	static public bool HasChanPrefix (this string s)
	{
		char p = s[0];
		return p == '#' || p == '&' || p == '!' || p == '+';
	}
	
	static public string ToID (this string s)
	{
		return s.ToLower();
	}
	
	
	public class TooLongException : Exception
	{
		public TooLongException (string msg) : base (msg) { }
	}
}