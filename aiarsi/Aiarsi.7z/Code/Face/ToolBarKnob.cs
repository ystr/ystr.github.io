using System;
using System.Drawing;
using System.Windows.Forms;

class ToolBarKnob : ToolStripButton
{
	readonly string image;
	void Skinize () { Image = Own.Image(image); }
	
	readonly string tip;
	readonly string keys;
	
	void Localize ()
	{
		ToolTipText = Own.Line(tip);
		if (keys != null) ToolTipText += " (" + keys + ")";
	}
	
	public ToolBarKnob (string image, string tip, string keys)
	{
		this.image = image;
		this.tip = tip;
		this.keys = keys;
		
		AutoToolTip = false;
		
		Own.SkinChanged += Skinize;
		Own.LocaleChanged += Localize;
		
		Skinize();
		Localize();
		
		Click += (o, e) => { Clicked(); };
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.SkinChanged -= Skinize;
		Own.LocaleChanged -= Localize;
		
		base.Dispose(disposing);
	}
	
	public event Action Clicked = () => {};
}