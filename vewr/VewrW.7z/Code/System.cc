void FileInfo (TCHAR* path)
{
	SHELLEXECUTEINFO i = {0};
	
	i.cbSize = sizeof(i);
	i.lpVerb = L"properties";
	i.lpFile = path;
	i.nShow = SW_SHOW;
	i.fMask = 12;
	
	ShellExecuteEx(&i);
}

void Delete (TCHAR* path, bool perm)
{
	TCHAR dblnull[MAX_PATH];
	memset(dblnull, '\0', MAX_PATH * sizeof(TCHAR));
	wcscpy(dblnull, path);
	
	SHFILEOPSTRUCT s = {0};
	
	if (!perm) s.fFlags = FOF_ALLOWUNDO;
	
	s.wFunc = FO_DELETE;
	s.pFrom = dblnull;
	
	SHFileOperation(&s);
}
