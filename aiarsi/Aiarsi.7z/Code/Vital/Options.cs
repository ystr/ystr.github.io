using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

class Options
{
	protected class Key : Dictionary<string, string> { }
	static protected Dictionary<string, Key> Stack = new Dictionary<string, Key>();
	static protected List<string> RemovedKeys = new List<string>();
	
	
	public static Options Root = new Options();
	
	public static Options Servers = Root.Open("Servers");
	public static Options Windows = Root.Open("Windows");
	
	
	public readonly string Path;
	
	public Options ()
	{
		Path = "Aiarsi";
		portable = File.Exists("Aiarsi.ini");
		Load();
	}
	
	public Options (Options parent, string path)
	{
		Path = parent.Path + "\\" + path;
		
		lock (Stack)
		{
			if (!Stack.ContainsKey(Path))
			{
				Stack.Add(Path, new Key());
			}
		}
	}
	
	public Options Open (string path)
	{
		return new Options(this, path);
	}
	
	
	public string[] ListKeys ()
	{
		List<string> keys = new List<string>();
		
		lock (Stack)
		{
			foreach (string k in Stack.Keys)
			{
				if (k.StartsWith(Path) && k != Path)
				{
					string tail = k.Substring(Path.Length + 1);
					if (tail.Contains("\\")) tail = (tail.Substring(0, tail.IndexOf('\\')));
					if (!keys.Contains(tail)) keys.Add(tail);
				}
			}
		}
		
		return keys.ToArray();
	}
	
	public void ZapKey (string zk)
	{
		zk = Path + "\\" + zk;
		
		lock (Stack)
		{
			RemovedKeys.Add(zk);
			List<string> ks = new List<string>(Stack.Keys);
			
			foreach (string k in ks)
			{
				if (k.StartsWith(zk))
				{
					Stack.Remove(k);
				}
			}
		}
	}
	
	string[] ListValues ()
	{
		lock (Stack)
		{
			return new List<string>(Stack[Path].Keys).ToArray();
		}
	}
	
	object GetValue (string name)
	{
		lock (Stack)
		{
			Dictionary<string, string> va = Stack[Path];
			if (va.ContainsKey(name)) return va[name];
			else return null;
		}
	}
	
	void SetValue (string name, string val)
	{
		lock (Stack)
		{
			Stack[Path][name] = val;
		}
	}
	
	public bool HasValue (string v)
	{
		return GetValue(v) != null;
	}
	
	
	public static string Escape (string s)
	{
		return s.Replace("/", "[/]").Replace("\\", "[//]");
	}
	
	public static string Unescape (string s)
	{
		return s.Replace("[//]", "\\").Replace("[/]", "/");
	}
	
	public string[] ListUnescapedKeys ()
	{
		string[] keys = ListKeys();
		for (int i = 0; i < keys.Length; i++) keys[i] = Unescape(keys[i]);
		return keys;
	}
	
	
	
	public T Get <T> (string name, T d)
	{
		string v = (string) GetValue(name);
		if (v == null) { Set(name, d); return d; }
		
		object r = v;
		
		switch (typeof(T).Name)
		{
			case "Size": {
				string[] ss = v.Split('*');
				r = new Size(Convert.ToInt32(ss[0]), Convert.ToInt32(ss[1]));
			} break;
			
			case "Point": {
				string[] ss = v.Split('*');
				r = new Point(Convert.ToInt32(ss[0]), Convert.ToInt32(ss[1]));
			} break;
			
			case "Int32": r = Convert.ToInt32(v); break;
			case "String": r = v; break;
			case "String[]": r = v.Split('\x1F'); break;
			
			case "Boolean": r = Convert.ToBoolean(v); break;
			case "Encoding": r = Encoding.GetEncoding(v); break;
			
			default: throw new Exception();
		}
		
		return (T) r;
	}
	
	public void Set <T> (string name, T vv)
	{
		object v = vv;
		string w = null;
		
		switch (typeof(T).Name)
		{
			case "Size":
				Size s = (Size) v;
				w = s.Width.ToString() + "*" + s.Height.ToString();
			break;
			
			case "Point":
				Point p = (Point) v;
				w = p.X.ToString() + "*" + p.Y.ToString();
			break;
			
			case "Int32": w = v.ToString(); break;
			case "String": w = (string) v; break;
			case "Boolean": w = v.ToString(); break;
			
			case "String[]": {
				string[] ss = (string[]) v;
				w = string.Join("\x1F", ss);
			} break;
			
			case "Encoding":
				Encoding e = (Encoding) v;
				w = e.WebName;
			break;
			
			default: throw new Exception();
		}
		
		SetValue(name, w);
	}
	
	
	static bool portable;
	static public bool Portable
	{
		get { return portable; }
		set
		{
			if (portable == value) return;
			portable = value;
			
			Save();
			
			if (portable) Registry.CurrentUser.DeleteSubKeyTree("Software\\Aiarsi");
			else if (File.Exists("Aiarsi.ini")) File.Delete("Aiarsi.ini");
		}
	}
	
	static void SaveToRegistry ()
	{
		RegistryKey root = Registry.CurrentUser.CreateSubKey("Software");
		
		lock (Stack)
		{
			foreach (string d in RemovedKeys)
			{
				if (root.OpenSubKey(d) != null)
				{
					root.DeleteSubKeyTree(d);
				}
			}
			
			foreach (KeyValuePair<string, Key> k in Stack)
			{
				RegistryKey rk = root.CreateSubKey(k.Key);
				
				foreach (KeyValuePair<string, string> v in k.Value)
				{
					rk.SetValue(v.Key, v.Value);
				}
			}
		}
	}
	
	static void LoadFromRegistry (RegistryKey rk, string path)
	{
		lock (Stack)
		{
			Stack[path] = new Key();
			
			foreach (string n in rk.GetValueNames())
			{
				Stack[path][n] = (string) rk.GetValue(n);
			}
		}
		
		foreach (string k in rk.GetSubKeyNames())
		{
			LoadFromRegistry(rk.OpenSubKey(k), path + "\\" + k);
		}
	}
	
	static void LoadFromIni ()
	{
		StreamReader r = new StreamReader("Aiarsi.ini");
		
		Key ck = null;
		string line = null;
		
		lock (Stack)
		{
			while ((line = r.ReadLine()) != null)
			{
				if (line.StartsWith("["))
				{
					string path = line.Split('[', ']')[1];
					Stack.Add(path, ck = new Key());
				}
				else if (ck != null && line.Contains("="))
				{
					string[] spl = line.Trim().Split(new char[]{'='}, 2);
					ck.Add(spl[0], spl[1]);
				}
			}
		}
		
		r.Close();
	}
	
	static void SaveToIni ()
	{
		StreamWriter w = new StreamWriter("Aiarsi.ini");
		
		lock (Stack)
		{
			foreach (KeyValuePair<string, Key> k in Stack)
			{
				w.WriteLine("[" + k.Key + "]");
				
				foreach (KeyValuePair<string, string> v in k.Value)
				{
					w.WriteLine(v.Key + "=" + v.Value);
				}
			}
		}
		
		w.Close();
	}
	
	static public void Load ()
	{
		if (portable) LoadFromIni();
		else LoadFromRegistry(Registry.CurrentUser.CreateSubKey("Software\\Aiarsi"), "Aiarsi");
	}
	
	static public void Save ()
	{
		lock (Stack)
		{
			if (portable) SaveToIni();
			else SaveToRegistry();
			RemovedKeys.Clear();
		}
	}
}