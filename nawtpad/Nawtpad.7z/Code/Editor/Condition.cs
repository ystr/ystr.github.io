using System;
using System.Collections.Generic;

class Condition
{
	public readonly bool Words = false;
	public readonly bool IgnoreCase = false;
	public readonly List<string> IfStrings = new List<string>();
	public readonly bool IfFirst = false;
	public readonly bool IfFirstNonSpace = false;
	public readonly bool IfLast = false;
	public readonly List<string> IfSetFlags = new List<string>();
	public readonly List<string> IfNotSetFlags = new List<string>();
	public readonly bool? IfNumber = null;
	public readonly bool? IfWordPart = null;
	public readonly bool? IfSpace = null;
	
	public readonly string ThenStylize = null;
	public readonly string ThenTransfer = null;
	public readonly List<string> ThenSetFlags = new List<string>();
	public readonly List<string> ThenRemoveFlags = new List<string>();
	
	public Condition (string code)
	{
		foreach (string entry in code.Split(' '))
		{
			if (entry.Length < 1) continue;
			
			char pre = entry[0];
			string opd = entry.Substring(1);
			
			switch (pre)
			{
				case '`': return;
				case 'W': Words = true; break;
				case 'I': IgnoreCase = true; break;
				case '"': IfStrings.Add(opd); break;
				case '?': IfSetFlags.Add(opd); break;
				case '!': IfNotSetFlags.Add(opd); break;
				case '*': ThenStylize = opd; break;
				case '>': ThenTransfer = opd; break;
				case '+': ThenSetFlags.Add(opd); break;
				case '-': ThenRemoveFlags.Add(opd); break;
				
				case '#': {
					
					switch (opd)
					{
						case "0": IfFirst = true; break;
						case "1": IfFirstNonSpace = true; break;
						case "L": IfLast = true; break;
					}
					
				} break;
				
				case '@': {
					
					bool val = true;
					
					if (opd.StartsWith("!"))
					{
						val = false;
						opd = opd.Trim('!');
					}
					
					switch (opd)
					{
						case "Number": IfNumber = val; break;
						case "WordPart": IfWordPart = val; break;
						case "Space": IfSpace = val; break;
					}
					
				} break;
			}
		}
	}
}