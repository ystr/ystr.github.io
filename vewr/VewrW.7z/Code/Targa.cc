Image* LoadTarga (TCHAR* file)
{
	BYTE* raw = LoadFile(file);
	if (!raw) return 0;
	
	int xs = (raw[0x0C] & 0xFF) | ((raw[0x0D] & 0xFF) << 8);
	int ys = (raw[0x0E] & 0xFF) | ((raw[0x0F] & 0xFF) << 8);
	
	Bitmap* map = new Bitmap(xs, ys);
	BYTE* from = raw + 0x12;
	
	for (int y = ys - 1; y >= 0; --y)
	{
		for (int x = 0; x < xs; ++x)
		{
			map->SetPixel(x, y, Color(from[3], from[2], from[1], from[0]));
			from += 4;
		}
	}
	
	delete[] raw;
	return map;
}
