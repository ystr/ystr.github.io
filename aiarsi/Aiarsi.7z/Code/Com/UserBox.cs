using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

class UserBox : ListBox
{
	public readonly Channel Channel;
	
	bool Selected { get { return (SelectedIndex >= 0); } }
	new User SelectedItem { get { return base.SelectedItem as User; } }
	
	public delegate void UserKeyHandler (User u, KeyEventArgs e);
	public delegate void UserMouseHandler (User u, MouseEventArgs e);
	
	public event UserKeyHandler UserKeyDown = (u, e) => {};
	public event UserMouseHandler UserMouseDown = (u, e) => {};
	public event User.Action UserDoubleClick = (u) => {};
	
	public UserBox (Channel c)
	{
		Channel = c;
		
		DoubleBuffered = true;
		IntegralHeight = false;
		SelectionMode = SelectionMode.One;
		
		MouseDown += (o, e) =>
		{
			SelectedIndex = IndexFromPoint(e.Location);
			if (Selected) UserMouseDown(SelectedItem, e);
		};
		
		DoubleClick += (o, e) => { if (Selected) UserDoubleClick(SelectedItem); };
		KeyDown += (o, e) => { if (Selected) UserKeyDown(SelectedItem, e); };
		LostFocus += (o, e) => { SelectedIndex = -1; };
		
		Style.Changed += SetStyle;
		SetStyle();
		
		Channel.UsersChanged += SyncLoadUsers;
		LoadUsers();
	}
	
	protected override void Dispose (bool disposing)
	{
		Style.Changed -= SetStyle;
		Channel.UsersChanged -= SyncLoadUsers;
		base.Dispose(disposing);
	}
	
	void SyncLoadUsers () { this.Sync(LoadUsers); }
	void LoadUsers ()
	{
		BeginUpdate();
		
		int i = 0, si = -1, ti = TopIndex;
		User su = Selected ? SelectedItem : null;
		
		Items.Clear();
		
		foreach (User u in Channel.ListUsers().Values)
		{
			Items.Add(u);
			if (u == su) si = i;
			i++;
		}
		
		SelectedIndex = si;
		if (ti <= Items.Count) TopIndex = ti;
		
		EndUpdate();
	}
	
	void SetStyle ()
	{
		Font = Style.Default.Font;
		ForeColor = Style.Default.Fore;
		BackColor = Style.Default.Back;
	}
}