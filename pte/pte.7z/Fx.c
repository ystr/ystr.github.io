void GenSpot (Raster* r, int radius, fake blur)
{
	Rect clip = Lbrt(-radius, -radius, +radius, +radius);
	InitRaster(r, sizeof(u8), &clip);
	
	for (int y = -radius; y < +radius; y++)
	for (int x = -radius; x < +radius; x++)
	{
		fake ax = 1.0 / radius * x;
		fake ay = 1.0 / radius * y;
		
		fake a = 1 - (
			sqrtf(ax * ax + ay * ay) - (1 - blur)
		) * (1 / blur);
		
		if (a < 0) a = 0;
		else if (a > 1) a = 1;
		
		u8 a8 = a * a * 0xFF;
		SetXY(r, x, y, &a8);
	}
}


void SetStarAlphas (u8 a[3], fake expo)
{
	a[0] = 0xFF * expo;
	a[1] = 0x40 * expo;
	a[2] = 0x20 * expo;
}

void SSPixel (const Raster* to, int x, int y, const u8* a, Rgb8 color)
{
	if (
		x < to->Clip.L || x >= to->Clip.R ||
		y < to->Clip.B || y >= to->Clip.T
	) return;
	
	OnSyxelAddA8HuedRgb8(RefXY(to, x, y), a, &color);
}

void DrawStar (const Raster* to, int ix, int iy, const u8 a[3], Rgb8 color)
{
	SSPixel(to, ix + 0, iy + 0, a + 0, color);
	SSPixel(to, ix - 1, iy + 0, a + 1, color);
	SSPixel(to, ix + 0, iy - 1, a + 1, color);
	SSPixel(to, ix + 1, iy + 0, a + 1, color);
	SSPixel(to, ix + 0, iy + 1, a + 1, color);
	SSPixel(to, ix - 1, iy - 1, a + 2, color);
	SSPixel(to, ix + 1, iy - 1, a + 2, color);
	SSPixel(to, ix + 1, iy + 1, a + 2, color);
	SSPixel(to, ix - 1, iy + 1, a + 2, color);
}
