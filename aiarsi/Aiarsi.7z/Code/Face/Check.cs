using System;
using System.Drawing;
using System.Windows.Forms;

class Check : CheckBox
{
	readonly string text;
	void Localize () { Text = Own.Line(text); }
	
	public Check (string text)
	{
		this.text = text;
		AutoSize = true;
		Own.LocaleChanged += Localize;
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}