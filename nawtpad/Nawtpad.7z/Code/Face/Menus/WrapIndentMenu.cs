using System.Windows.Forms;


class WrapIndentMenu : Menu
{
	public readonly Editor E;
	
	Row offRow = new Row("No indent");
	Row sameRow = new Row("Same level");
	Row moreRow = new Row("One level more");
	
	public WrapIndentMenu (Editor editor)
	{
		E = editor;
		
		Items.Add(offRow);
		Items.Add(sameRow);
		Items.Add(moreRow);
		
		offRow.Clicked += () => E.WrapIndent = Editor.GlobalWrapIndent = false;
		
		sameRow.Clicked += () =>
		{
			E.WrapIndent = Editor.GlobalWrapIndent = true;
			E.WrapIndentExtra = Editor.GlobalWrapIndentExtra = 0;
		};
		
		moreRow.Clicked += () =>
		{
			E.WrapIndent = Editor.GlobalWrapIndent = true;
			E.WrapIndentExtra = Editor.GlobalWrapIndentExtra = 1;
		};
		
		Opening += (o, e) =>
		{
			E.WrapIndentChanged += Reveal;
			E.WrapIndentExtraChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.WrapIndentChanged -= Reveal;
			E.WrapIndentExtraChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		if (E.WrapIndent) {
			offRow.Checked = false;
			sameRow.Checked = E.WrapIndentExtra == 0;
			moreRow.Checked = E.WrapIndentExtra == 1;
		} else {
			sameRow.Checked = moreRow.Checked = false;
			offRow.Checked = true;
		}
	}
}