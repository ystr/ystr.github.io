#define MM / 1000.0
#define CM / 100.0
#define DM / 10.0
#define KM * 1000.0
#define AU * 150E6 KM
#define LY * 9.46E12 KM
#define PC * 210000.0 AU
#define KH / 3.6
#define ER * 6371 KM
#define MR * 1737 KM
#define SR * 696342 KM
#define JR * 69911 KM
