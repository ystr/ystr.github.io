using System;
using System.Drawing;
using System.Windows.Forms;

class TrayMenu : ContextMenu
{
	MenuRow muteRow = new MenuRow(null, "Mute", null);
	MenuRow settingsRow = new MenuRow("Settings", "Settings", null);
	MenuRow exitRow = new MenuRow(null, "Exit", null);
	
	public TrayMenu ()
	{
		Opened += (o, e) => Reload();
		
		muteRow.Click += (o, e) => { Notify.Mute = !Notify.Mute; };
		exitRow.Click += (o, e) => Application.Exit();
		settingsRow.Clicked += Settings.Open;
		
		Reload();
	}
	
	void Reload ()
	{
		Items.Clear();
		
		foreach (Server s in Server.List) Items.Add(new ServerRow(s));
		if (Server.List.Count > 0) Items.Add(new ToolStripSeparator());
		
		muteRow.Checked = Notify.Mute;
		
		Items.Add(muteRow);
		Items.Add(settingsRow);
		Items.Add(exitRow);
	}
	
	class ChatRow : MenuRow
	{
		public readonly Chat Chat;
		public ChatRow (string icon, Chat c) : base (icon, c.Name, null) { Chat = c; }
	}
	
	class ServerRow : MenuRow
	{
		public readonly Server Server;
		
		public ServerRow (Server s) : base ("Console", s.Title, null)
		{
			Server = s;
			
			Italic = Server.Log.Unread.Has(Unread.Message);
			Bold = Server.UnreadItems.Has(Unread.Important);
			
			ForeColor = Server.Welcomed ? SystemColors.MenuText : SystemColors.GrayText;
			
			Clicked += () => ConsoleCom.Open(s);
			DropDownOpening += (o, e) => Reload();
			
			Reload();
		}
		
		void Reload ()
		{
			DropDownItems.Clear();
			
			foreach (Channel c in Server.ListChannels().Values)
			{
				MenuRow cr = new ChatRow("Channel", c);
				Channel lc = c; cr.Clicked += () => ChannelCom.Open(lc);
				DropDownItems.Add(cr);
			}
			
			foreach (Query q in Server.ListQueries().Values)
			{
				MenuRow pr = new ChatRow("Query", q);
				Query lq = q; pr.Clicked += () => QueryCom.Open(lq);
				DropDownItems.Add(pr);
			}
			
			foreach (ChatRow cr in DropDownItems)
			{
				cr.Italic = cr.Chat.Log.Unread.Has(Unread.Message);
				cr.Bold = cr.Chat.Log.Unread.Has(Unread.Important);
			}
		}
	}
}