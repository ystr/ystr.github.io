#define UNICODE
#include <wchar.h>
#include <windows.h>
#include <shlobj.h>




typedef struct { unsigned char B, G, R, A; } Pixel;
typedef struct { BITMAPINFOHEADER Header; Pixel Data[]; } Raster;

#define BM_THIRD WM_MBUTTONDOWN
#define BM_FIRST WM_LBUTTONDOWN
#define BM_SECOND WM_RBUTTONDOWN

#define BK_ESC VK_ESCAPE
#define BK_DOWN VK_DOWN
#define BK_LEFT VK_LEFT
#define BK_RIGHT VK_RIGHT
#define BK_UP VK_UP




#include "Bckbrd.c"




HWND Window;
HWND EventCatcher;
HPEN EraseRectPen;




wchar_t* NarrowToWide (const char* narrow)
{
	int wlen = MultiByteToWideChar(CP_UTF8, 0, narrow, -1, 0, 0);
	wchar_t* wide = malloc(sizeof(wchar_t) * wlen);
	MultiByteToWideChar(CP_UTF8, 0, narrow, -1, wide, wlen);
	return wide;
}

wchar_t* GetDataPath (const char* name)
{
	wchar_t* wname = NarrowToWide(name);
	wchar_t* path = malloc(sizeof(wchar_t) * MAX_PATH);
	
	BOOL portable = FALSE;
	wchar_t* exepath = malloc(sizeof(wchar_t) * MAX_PATH);
	GetModuleFileName(0, exepath, MAX_PATH);
	
	for (int i = wcslen(exepath) - 1; i >= 0; i--)
	{
		if (exepath[i] == L'\\') break;
		if (exepath[i] == L'P') { portable = TRUE; break; }
	}
	
	if (portable) path[0] = L'\0';
	else {
		SHGetFolderPath(0, CSIDL_APPDATA, 0, 0, path);
		wcscat(path, L"\\Bckbrd\\"); CreateDirectory(path, 0);
	}
	
	wcscat(path, wname); free(wname);
	return path;
}

void* LoadData (const char* name)
{
	wchar_t* path = GetDataPath(name);
	HANDLE file = CreateFile(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (file == INVALID_HANDLE_VALUE) return 0;
	long size = GetFileSize(file, 0); void* data = malloc(size);
	static DWORD br = 0; ReadFile(file, data, size, &br, 0);
	CloseHandle(file);
	return data;
}

void SaveData (const char* name, const void* data, long size)
{
	wchar_t* path = GetDataPath(name);
	HANDLE file = CreateFile(path, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	static DWORD br = 0; WriteFile(file, data, size, &br, 0);
	CloseHandle(file);
	free(path);
}

void DeleteData (const char* name)
{
	wchar_t* path = GetDataPath(name);
	DeleteFile(path);
	free(path);
}

Raster* NewRaster (int w, int h)
{
	int area = w * h;
	Raster* pi = malloc(sizeof(Raster) + sizeof(Pixel) * area);
	for (Pixel* p = pi->Data, *p1 = p + area; p < p1; ++p) p->A = 0xFF;
	
	pi->Header = (BITMAPINFOHEADER) {
		.biSize = sizeof(BITMAPINFOHEADER),
		.biPlanes = 1, .biBitCount = 32, .biCompression = BI_RGB,
		.biWidth = w, .biHeight = -h
	};
	
	return pi;
}

void ZapRaster (Raster* pi)
{
	free(pi);
}

void Invalidate (const Rect* r)
{
	if (!r) { InvalidateRect(Window, 0, 0); return; }
	RECT pr = { .top = r->T, .left = r->L, .right = r->R, .bottom = r->B };
	InvalidateRect(Window, &pr, 0);
}

void Quit ()
{
	exit(0);
}




LRESULT CALLBACK WndProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_MBUTTONDOWN:
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
			
			SetCapture(Window);
			POINT pos; GetCursorPos(&pos);
			BbMouseDown(pos.x, pos.y, uMsg);
			
		break;
		
		case WM_MBUTTONUP:
		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
			
			BbMouseUp();
			ReleaseCapture();
			
		break;
	}
	
	switch (uMsg)
	{
		case WM_MOUSEMOVE: {
			
			POINT pos; GetCursorPos(&pos);
			BbMouseMove(pos.x, pos.y);
			
		} break;
		
		case WM_PAINT: {
			
			UpdateBoard();
			
			PAINTSTRUCT ps;
			HDC dc = BeginPaint(Window, &ps);
			
			for (int gy = 0; gy < Board.GridSize.Y; gy++)
			{
				for (int gx = 0; gx < Board.GridSize.X; gx++)
				{
					int x = gx * TILESIZE - Board.TileLocation.X;
					int y = gy * TILESIZE - Board.TileLocation.Y;
					
					Tile* t = *GetTileLocal(Board.Grid, gx, gy);
					Raster* pi = t->Buffer;
					
					SetDIBitsToDevice (
						dc, x, y, TILESIZE, TILESIZE, 0, 0, 0, TILESIZE,
						pi->Data, (LPBITMAPINFO)&pi->Header, DIB_RGB_COLORS
					);
				}
			}
			
			if (Board.Input.Mode == ERASING)
			{
				SelectObject(dc, GetStockObject(NULL_BRUSH));
				SelectObject(dc, GetStockObject(NULL_BRUSH));
				
				SetBkMode(dc, TRANSPARENT);
				SelectObject(dc, EraseRectPen);
				
				Rectangle ( dc,
					Board.Input.NewSelRect.L, Board.Input.NewSelRect.T,
					Board.Input.NewSelRect.R, Board.Input.NewSelRect.B
				);
			}
			
			EndPaint(Window, &ps);
			DeleteDC(dc);
			
		} break;
		
		case WM_KEYDOWN: BbKeyPress(wParam); break;
		default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	return 0;
}

LRESULT CALLBACK ECWndProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_DISPLAYCHANGE: {
			NewBoard(GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
			SetWindowPos(Window, HWND_NOTOPMOST, 0, 0, Board.ScreenSize.X, Board.ScreenSize.Y, 0);
		} break;
		
		case WM_SETTINGCHANGE: {
			
			if (wParam == SPI_SETDESKWALLPAPER)
			{
				UpdateBackground();
				InvalidateRect(Window, 0, 0);
			}
			
		} break;
			
		case WM_QUERYENDSESSION: Finalize(); return 1; break;
		default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE p, LPSTR c, int s)
{
	#ifdef DEBUG
		AllocConsole();
		freopen("CONOUT$", "wb", stdout);
	#endif
	
	PrepareBoard();
	NewBoard(GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
	atexit(Finalize);
	
	#define WCLX(N,...) { .lpszClassName = N, .cbSize = sizeof(WNDCLASSEX), .hInstance = hInstance, __VA_ARGS__ }
	#define CRWN(N,...) CreateWindowEx(WS_EX_TOOLWINDOW, N, N, WS_POPUP, __VA_ARGS__, 0, 0, hInstance, 0);
	
	WNDCLASSEX winClass = WCLX(L"Bckbrd", .lpfnWndProc = WndProc, .hCursor = LoadCursor(0, IDC_ARROW));
	WNDCLASSEX ecWinClass = WCLX(L"EventCatcher", .lpfnWndProc = ECWndProc);
	
	RegisterClassEx(&winClass);
	RegisterClassEx(&ecWinClass);
	
	Window = CRWN(L"Bckbrd", 0, 0, Board.ScreenSize.X, Board.ScreenSize.Y);
	EventCatcher = CRWN(L"EventCatcher", -32767, -32767, 0, 0);
	
	SetParent(Window, FindWindow(L"Progman", 0));
	ShowWindow(Window, SW_SHOWNOACTIVATE);
	ShowWindow(EventCatcher, SW_SHOWNOACTIVATE);
	
	EraseRectPen = CreatePen(PS_INSIDEFRAME, 1, 0x000000FF);
	
	MSG m; while (GetMessage(&m, 0, 0, 0))
	{
		TranslateMessage(&m);
		DispatchMessage(&m);
	}
	
	return 0;
}
