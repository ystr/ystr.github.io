TCHAR** Files;
int FileCount;
int Caret;

TCHAR Dir[MAX_PATH];
TCHAR File[MAX_PATH];
TCHAR Path[MAX_PATH];

Image* Source = 0;
int SourceWidth, SourceHeight;

GUID FDID;
int FrameCount = 1;
int* FrameTimes = 0;
UINT_PTR Timer = 0;
int Frame = 0;
bool Animate = true;

Image* Screen;
int ScreenWidth, ScreenHeight;

BYTE* Buffer;

bool Fit = true;
bool FullScreen = false;
int X = 0, Y = 0;
float Zoom = 1;
bool OnTop = false;

int Back = 0;
BYTE Backs[3] = { 0, 128, 255 };

bool Smooth = true;

bool Blink = false;
HWND WinHandle;
HDC WinContext;

HICON Icon16 = 0;
HICON Icon32 = 0;
