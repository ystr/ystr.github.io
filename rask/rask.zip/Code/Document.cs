using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

class Document : IEnumerable
{
	List<Frame> frames = new List<Frame>();
	
	public Frame this [int i] { get { return frames[i]; } }
	public IEnumerator GetEnumerator () { foreach (Frame f in frames) yield return f; }
	public int Count { get { return frames.Count; } }
	
	public void SaveTo (string path)
	{
		using (BinaryWriter w = new BinaryWriter(File.OpenWrite(path)))
		{
			w.Write("RASK".ToCharArray());
			w.Write((UInt32)0);
			w.Write(frames.Count);
			foreach (Frame f in frames) f.Write(w);
		}
	}
	
	public Document (string path)
	{
		if (path != null && File.Exists(path))
		{
			using (BinaryReader r = new BinaryReader(File.OpenRead(path)))
			{
				string header = r.ReadUtf8(4);
				if (header != "RASK") throw new IOException("Unknown format (" + header + ")");
				
				UInt32 flags = r.ReadUInt32();
				if (flags != 0) throw new IOException("Unknown version (" + flags + ")");
				
				for (uint i = 0, count = r.ReadUInt32(); i < count; i++) frames.Add(new Frame(r));
			}
		}
		
		if (frames.Count == 0) frames.Add(new Frame());
	}
	
	public void AddFrame (int pos)
	{
		frames.Insert(pos, new Frame());
		if (FrameAdded != null) FrameAdded(pos);
	}
	
	public void RemoveFrame (int pos)
	{
		if (frames.Count == 1) AddFrame(pos + 1);
		
		frames.RemoveAt(pos);
		if (FrameDeleted != null) FrameDeleted(pos);
	}
	
	public void RemoveFrame (Frame f)
	{
		RemoveFrame(frames.IndexOf(f));
	}
	
	public void MoveFrame (int pos, int delta)
	{
		int newpos = pos + delta;
		if (newpos < 0 || newpos >= frames.Count) return;
		
		Frame move = frames[pos];
		
		frames.RemoveAt(pos);
		frames.Insert(newpos, move);
		
		if (FrameMoved != null) FrameMoved(pos, newpos);
	}
	
	public void MoveFrame (Frame f, int delta)
	{
		MoveFrame(frames.IndexOf(f), delta);
	}
	
	public event Action<int> FrameAdded;
	public event Action<int> FrameDeleted;
	public event Action<int, int> FrameMoved;
}
