void SourceToScreen ()
{
	Rect put;
	
	if (Fit)
	{
		float sor = (float) SourceWidth / (float) SourceHeight;
		float scr = (float) ScreenWidth / (float) ScreenHeight;
		
		float zf = scr / sor;
		
		if (scr < sor)
		{
			put.Width = ScreenWidth;
			put.Height = (int) (ScreenHeight * zf);
			
			put.X = 0;
			put.Y = (int) (ScreenHeight / 2 - put.Height / 2);
		}
		else
		{
			put.Height = ScreenHeight;
			put.Width = (int) (ScreenWidth / zf);
			
			put.Y = 0;
			put.X = (int) (ScreenWidth / 2 - put.Width / 2);
		}
	}
	
	else
	{
		put.Width = (int) (SourceWidth * Zoom);
		put.Height = (int) (SourceHeight * Zoom);
		
		put.X = (int) (ScreenWidth / 2 - SourceWidth / 2 * Zoom -X);
		put.Y = (int) (ScreenHeight / 2 - SourceHeight / 2 * Zoom - Y);
	}
	
	delete Screen;
	Screen = new Bitmap(ScreenWidth, ScreenHeight);
	
	Graphics g(Screen);
	
	if (Smooth) g.SetInterpolationMode(InterpolationModeHighQualityBilinear);
	else g.SetInterpolationMode(InterpolationModeNearestNeighbor);
	
	BYTE br, bg, bb;
	
	if (Back < 0) {
		DWORD wc = GetSysColor(COLOR_3DFACE);
		br = GetRValue(wc); bg = GetGValue(wc); bb = GetBValue(wc);
	} else br = bg = bb = Backs[Back];
	
	g.Clear(Color(255, br, bg, bb));
	
	g.DrawImage(Source, put);
}

void ScreenToWindow ()
{
	PAINTSTRUCT ps;
	HDC dc = BeginPaint(WinHandle, &ps);
	
	Graphics g(WinContext);
	g.DrawImage(Screen, 0, 0);
	
	EndPaint(WinHandle, &ps);
	DeleteDC(dc);
}
