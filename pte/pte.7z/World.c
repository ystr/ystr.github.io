#define WORLD_LOD 8
#define WORLD_MIN_CUTOFF 10 KM


typedef struct {
	
	Thing Thing;
	
	real Radius;
	
	Hull* Hulls;
	int HullsCount;
	
	Rgb Emit;
	Rgb Albedo;
	
	const Liting* TestLiting;
	
	Sky* Sky;
	
} World;


bool CollectWorld (Thing* t, const Pov* pov, Eye* eye)
{
	World* w = (World*) t;
	
	if (w->Emit.R || w->Emit.G || w->Emit.B)
	{
		Lamp* l = eye->Lamps + eye->LampsCount++;
		
		l->Light = RgbMul(w->Emit, eye->Expo);
		l->Point = LocProPov(IdenLoc, pov);
		l->Radius = w->Radius;
		l->Glare = true;
	}
	
	return true;
}

bool RenderWorld (Thing* t, const Pov* pov, Eye* eye)
{
	World* w = (World*) t;
	
	Xyz vcen = LocProPov(IdenLoc, pov);
	if (vcen.Z > w->Radius * 2) return false;
	real dis = Len(pov->Loc);
	fake r = EyeV2SR(eye, w->Radius, -dis);
	
	Xy sc; if (EyeV2S(&sc, eye, -1, vcen))
	{
		Rgb e = w->Emit;
		
		for EACHC (const Lamp*, l, w->TestLiting->Lamps)
		{
			fake v = DirProPov(l->Point, pov).Z;
			if (v <= 0) continue;
			
			e.R += w->Albedo.R * l->Light.R * v;
			e.G += w->Albedo.G * l->Light.G * v;
			e.B += w->Albedo.B * l->Light.B * v;
		}
		
		Syxel l8 = Rgb8OfRgb(e);
		u8 a[3]; SetStarAlphas(a, 1);
		DrawStar(eye->To, sc.X, sc.Y, a, l8);
	}
	
	if (r < 1) return false;
	fake qlod = P2(WORLD_LOD * w->Radius);
	
	if (w->Sky) RenderSky ( &(SkyPass) {
		.Pov = pov, .Eye = eye, .Sky = w->Sky,
		.Liting = w->TestLiting, .PovNorm = dis,
	} );
	
	for EACHC (Hull*, h, w->Hulls)
	{
		real disToHorizon = CatCH(h->Radius, Max(dis, h->Radius));
		
		RenderHull ( &(HPass) {
			.Pov = pov, .Eye = eye, .Tag = w, .Hull = h,
			.Cutoff = Max3(disToHorizon, h->MinCutoff, WORLD_MIN_CUTOFF),
			.Liting = w->TestLiting,
		}, qlod );
	}
	
	return true;
}


void WInitVert (HVert* v, const s8 cv[3], const World* w, Hull* h)
{
	InitHVert(v, (Xyz) { cv[0], cv[1], cv[2] }, w, h);
}

void WInitEdge (HEdge* e, const u8 ce[2], const World* w, Hull* h)
{
	InitHEdge(e, h->Verts + ce[0], h->Verts + ce[1], w, h, 0);
}

void WInitQuad (HQuad* q, const u8 cq[4], const World* w, Hull* h)
{
	InitHQuad ( 0, q,
		h->Edges + cq[0], h->Edges + cq[1],
		h->Edges + cq[2], h->Edges + cq[3],
	w, h );
}


void WMakeHull (const World* w, Hull* h)
{
	h->Verts = NEW(HVert, h->VertsCount = ALEN(Cube.Verts));
	h->Edges = NEW(HEdge, h->EdgesCount = ALEN(Cube.Edges));
	h->Quads = NEW(HQuad, h->QuadsCount = ALEN(Cube.Quads));
	
	h->GeometryRes = 1; real side = 2 * w->Radius / sqrt(3);
	while (side > 1) { h->GeometryRes *= 2; side /= 2; }
	
	for COUNT (i, h->VertsCount) WInitVert(h->Verts + i, Cube.Verts[i], w, h);
	for COUNT (i, h->EdgesCount) WInitEdge(h->Edges + i, Cube.Edges[i], w, h);
	for COUNT (i, h->QuadsCount) WInitQuad(h->Quads + i, Cube.Quads[i], w, h);
}


void MakeWorld (World* w)
{
	MakeThing(&w->Thing);
	
	for EACHC (Hull*, s, w->Hulls) WMakeHull(w, s);
	
	w->Thing.Collect = CollectWorld;
	w->Thing.Render = RenderWorld;
}
