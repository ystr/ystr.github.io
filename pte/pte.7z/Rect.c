typedef struct { int L, B, R, T, W, H; } Rect;

#define LBRT(L,B,R,T) { L, B, R, T, R - L, T - B }
#define LBWH(L,B,W,H) { L, B, L + W, B + H, W, H }

Rect Lbrt (int l, int b, int r, int t) { return (Rect) LBRT(l, b, r, t); }
Rect Lbwh (int l, int b, int w, int h) { return (Rect) LBWH(l, b, w, h); }

bool DstClipSrc (Rect* dst, const Rect* clip, Rect* src)
{
	if (dst->L >= clip->R) return false;
	if (dst->B >= clip->T) return false;
	if (dst->R <= clip->L) return false;
	if (dst->T <= clip->B) return false;
	
	if (dst->L < clip->L) src->L += clip->L - dst->L, dst->L = clip->L;
	if (dst->B < clip->B) src->B += clip->B - dst->B, dst->B = clip->B;
	if (dst->R > clip->R) src->R += clip->R - dst->R, dst->R = clip->R;
	if (dst->T > clip->T) src->T += clip->T - dst->T, dst->T = clip->T;
	
	src->W = src->R - src->L;
	src->H = src->T - src->B;
	dst->W = dst->R - dst->L;
	dst->H = dst->T - dst->B;
	
	return true;
}
