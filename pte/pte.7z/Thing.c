typedef struct Thing Thing;


typedef bool ThingRecursor (Thing*, const Pov*, void*);
typedef bool ThingCollector (Thing*, const Pov*, Eye*);
typedef bool ThingRenderer (Thing*, const Pov*, Eye*);


struct Thing
{
	Pos Pos;
	
	ThingCollector* Collect;
	ThingRenderer* Render;
	
	Thing* Parent;
	Thing* Children;
	Thing* Next;
};


void ThingAddChild (Thing* p, Thing* c)
{
	c->Next = p->Children;
	p->Children = c;
	c->Parent = p;
}


bool CollectThing (Thing* t, const Pov* pov, void* uni)
{
	return t->Collect ? t->Collect(t, pov, uni) : true;
}

bool RenderThing (Thing* t, const Pov* pov, void* uni)
{
	return t->Render ? t->Render(t, pov, uni) : true;
}


void InitThing (Thing* t)
{
	*t = (Thing) { .Pos = IDENPOS };
}

void MakeThing (Thing* t)
{
	MakePos(&t->Pos);
}


void RecurseThing (
	ThingRecursor* fun,
	Thing* from, Thing* this,
	const Pov* pov, void* uni
) {
	if (this->Parent && from != this->Parent)
	{
		Pov ppov = PosC2PPos(pov, &this->Pos);
		RecurseThing(fun, this, this->Parent, &ppov, uni);
	}
	
	if (fun(this, pov, uni))
	for (Thing* c = this->Children; c; c = c->Next)
	{
		if (c == from) continue;
		Pov cpov = PosP2CPos(pov, &c->Pos);
		RecurseThing(fun, this, c, &cpov, uni);
	}
}
