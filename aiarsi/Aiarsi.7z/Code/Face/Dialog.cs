using System.Windows.Forms;

static class Dialog
{
	static public bool Delete (string what)
	{
		return MessageBox.Show (
			Own.Line("Delete %0?", what), Own.Line("Delete?"),
			MessageBoxButtons.YesNo, MessageBoxIcon.Question
		) == DialogResult.Yes;
	}
}