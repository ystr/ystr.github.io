using System.Collections.Generic;
using System.Drawing;

class Visual
{
	public readonly Line Source;
	public Visual (Line source) { Source = source; }
	
	public List<Sub> Subs = new List<Sub>();
	public Size Bounds = new Size(0, 1);
	
	public List<Limits> Found = new List<Limits>();
	public List<Limits> FoundAlt = new List<Limits>();
}