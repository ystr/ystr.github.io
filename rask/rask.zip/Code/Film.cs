using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

class Film : FlowLayoutPanel
{
	int selected = 0;
	
	public int Selected {
		get { return selected; }
		set {
			selected = value;
			RevealSelection();
			if (SelectedChanged != null) SelectedChanged(selected);
		}
	}
	
	public event Action<int> SelectedChanged;
	
	public readonly Document Document;
	
	int FindCellSize ()
	{
		for (int size = ClientSize.Height ;; size-- )
		{
			int cols = ClientSize.Width / size;
			int rows = Document.Count / cols + 1;
			
			if (rows * size < ClientSize.Height) return size;
		}
	}
	
	void Rearrange ()
	{
		int size = FindCellSize();
		
		foreach (Preview p in Controls)
		{
			p.Size = new Size(size, size);
			p.Margin = new Padding(0);
		}
	}
	
	void AddPreview (int i)
	{
		Preview p = new Preview(Document[i]);
		
		Controls.Add(p);
		Controls.SetChildIndex(p, i);
		
		selected = i;
		
		p.MouseDown += (o, e) =>
		{
			Selected = Controls.GetChildIndex(o as Control);
			
			if (e.Button == MouseButtons.Right)
				new FrameMenu(Document, Selected).Show(o as Control, new Point(e.X, e.Y));
		};
	}
	
	void DeletePreview (int i)
	{
		Controls.RemoveAt(i);
		selected = (i < Document.Count) ? i : Document.Count - 1;
	}
	
	void RevealSelection ()
	{
		for (int i = 0; i < Document.Count; i++)
		{
			(Controls[i] as Preview).Selected = (i == selected);
		}
	}
	
	public Film (Document subj)
	{
		Document = subj;
		
		DoubleBuffered = true;
		
		SuspendLayout();
		for (int i = 0; i < subj.Count; i++) AddPreview(i);
		RevealSelection();
		ResumeLayout();
		
		SizeChanged += (o, e) =>
		{
			SuspendLayout();
			Rearrange();
			ResumeLayout();
		};
		
		Document.FrameAdded += (i) =>
		{
			SuspendLayout();
			
			AddPreview(i);
			Rearrange();
			RevealSelection();
			
			ResumeLayout();
			
			if (SelectedChanged != null) SelectedChanged(i);
		};
		
		Document.FrameDeleted += (i) =>
		{
			SuspendLayout();
			
			DeletePreview(i);
			Rearrange();
			RevealSelection();
			
			ResumeLayout();
			
			if (SelectedChanged != null) SelectedChanged(selected);
		};
		
		Document.FrameMoved += (ifrom, ito) =>
		{
			SuspendLayout();
			
			Controls.SetChildIndex(Controls[ifrom], ito);
			
			ResumeLayout();
			
			selected = ito;
			
			if (SelectedChanged != null) SelectedChanged(selected);
		};
		
		DoubleClick += (o, e) =>
		{
			Document.AddFrame(Document.Count);
		};
	}
}
