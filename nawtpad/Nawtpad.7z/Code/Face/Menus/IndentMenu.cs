using System.Windows.Forms;


using System.Collections.Generic;

class IndentMenu : Menu
{
	public readonly Document D;
	
	Row tabsRow = new Row("Tabs");
	Row spacesRow = new Row("Spaces");
	Row autoRow = new Row("Autodetect");
	Row defaultRow = new Row("Set as Default");
	
	Dictionary<int, Row> sizeRows = new Dictionary<int, Row>();
	
	void AddTabSizeRow (string title, int size)
	{
		Row tr = new Row(title) { Tag = size };
		tr.Clicked += () => D.IndentSize = size;
		sizeRows[size] = tr;
		Items.Add(tr);
	}
	
	public IndentMenu (Document doc)
	{
		D = doc;
		
		Items.Add(tabsRow);
		Items.Add(spacesRow);
		Items.Add(new ToolStripSeparator());
		AddTabSizeRow(">>", 2);
		AddTabSizeRow(">>>>", 4);
		AddTabSizeRow(">>>>>>>>", 8);
		Items.Add(new ToolStripSeparator());
		Items.Add(autoRow);
		Items.Add(defaultRow);
		
		tabsRow.Clicked += () => D.IndentWithSpaces = false;
		spacesRow.Clicked += () => D.IndentWithSpaces = true;
		autoRow.Clicked += () => Document.DetectIndent = !Document.DetectIndent;
		
		defaultRow.Clicked += () =>
		{
			Document.DefaultIndentWithSpaces = D.IndentWithSpaces;
			Document.DefaultIndentSize = D.IndentSize;
		};
		
		Opening += (o, e) =>
		{
			D.IndentWithSpacesChanged += Reveal;
			D.IndentSizeChanged += Reveal;
			
			Document.DetectIndentChanged += Reveal;
			Document.DefaultIndentWithSpacesChanged += Reveal;
			Document.DefaultIndentSizeChanged += Reveal;
			
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			D.IndentWithSpacesChanged -= Reveal;
			D.IndentSizeChanged -= Reveal;
			
			Document.DetectIndentChanged -= Reveal;
			Document.DefaultIndentWithSpacesChanged -= Reveal;
			Document.DefaultIndentSizeChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		autoRow.Checked = Document.DetectIndent;
		
		tabsRow.Checked = !D.IndentWithSpaces;
		spacesRow.Checked = D.IndentWithSpaces;
		
		defaultRow.Checked =
		(
			Document.DefaultIndentWithSpaces == D.IndentWithSpaces &&
			Document.DefaultIndentSize == D.IndentSize
		);
		
		foreach (Row sr in sizeRows.Values)
		{
			sr.Checked = ((int)sr.Tag == D.IndentSize);
		}
	}
}