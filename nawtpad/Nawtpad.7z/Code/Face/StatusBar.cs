using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;


class StatusBar : ToolBase
{
	public readonly Face F;
	public readonly Editor E;
	public readonly Document D;
	
	StatusLabel caretLabel = new StatusLabel();
	DropButton encodingDrop = new DropButton("Encoding");
	DropButton newlineDrop = new DropButton("Newline");
	DropButton indentDrop = new DropButton("Indentation");
	DropButton schemeDrop = new DropButton("Scheme");
	
	StatusLabel lineLabel = new StatusLabel("Line");
	IntField lineField = new IntField(1, int.MaxValue) { Width = 40 };
	StatusLabel linesTotalLabel = new StatusLabel("Line count");
	StatusLabel charLabel = new StatusLabel("Character");
	IntField charField = new IntField(1, int.MaxValue) { Width = 40 };
	StatusLabel charsTotalLabel = new StatusLabel("Character count");
	
	Button goBtn = new Button("Go");
	
	Button wrapButton = new Button("W", "Wrap", "Ctrl W");
	Button zoomButton = new Button(null, "100%", "Ctrl 0", "Reset Zoom");
	
	Menu contextMenu = new Menu();
	Row hideRow = new Row("Hide Statusbar", "F12");
	
	public StatusBar (Face f)
	{
		F = f;
		E = F.E;
		D = F.D;
		
		hideRow.Clicked += () => F.ShowStatusbar.Value = false;
		contextMenu.Items.Add(hideRow);
		
		encodingDrop.DropDown = new EncodingMenu(D);
		newlineDrop.DropDown = new NewlineMenu(D);
		indentDrop.DropDown = new IndentMenu(D);
		schemeDrop.DropDown = new SchemeMenu(D);
		
		wrapButton.Clicked += () => E.Wrap =! E.Wrap;
		zoomButton.Clicked += () => E.FontSize = Editor.DefaultFontSize;
		
		Items.Add(schemeDrop);
		Items.Add(encodingDrop);
		Items.Add(newlineDrop);
		Items.Add(indentDrop);
		Items.Add(lineLabel);
		Items.Add(lineField);
		Items.Add(linesTotalLabel);
		Items.Add(charLabel);
		Items.Add(charField);
		Items.Add(charsTotalLabel);
		Items.Add(goBtn);
		Items.Add(caretLabel);
		
		Items.Add(zoomButton); zoomButton.Alignment = ToolStripItemAlignment.Right;
		Items.Add(wrapButton); wrapButton.Alignment = ToolStripItemAlignment.Right;
		
		MouseUp += ProcessMouseUp;
		foreach (ToolStripItem i in Items) i.MouseUp += ProcessMouseUp;
		
		E.CaretMoved += RevealPositions;
		D.Updated += RevealPositions;
		E.SelectionChanged += RevealPositions;
		D.EncodingChanged += RevealEncoding;
		D.SaveBomChanged += RevealEncoding;
		D.NewlineChanged += RevealNewline;
		D.IndentWithSpacesChanged += RevealIndent;
		D.IndentSizeChanged += RevealIndent;
		D.SchemeChanged += RevealScheme;
		E.WrapChanged += RevealWrap;
		E.FontSizeChanged += RevealZoom;
		
		Own.LocaleChanged += RevealPositions;
		Own.LocaleChanged += RevealIndent;
		Own.LocaleChanged += RevealScheme;
		Own.LocaleChanged += RevealZoom;
		
		lineField.Submitted += Go;
		charField.Submitted += Go;
		
		goBtn.Click += (o, e) => Go();
		
		RevealPositions();
		RevealEncoding();
		RevealNewline();
		RevealIndent();
		RevealScheme();
		RevealWrap();
		RevealZoom();
	}
	
	public void ShowGo ()
	{
		lineField.SelectAll();
		lineField.Focus();
	}
	
	void Go ()
	{
		E.GoTo(lineField.Value - 1, charField.Value - 1);
		E.Focus();
	}
	
	protected override void Dispose (bool disposing)
	{
		E.CaretMoved -= RevealPositions;
		D.Updated -= RevealPositions;
		E.SelectionChanged -= RevealPositions;
		D.EncodingChanged -= RevealEncoding;
		D.SaveBomChanged -= RevealEncoding;
		D.NewlineChanged -= RevealNewline;
		D.SchemeChanged -= RevealScheme;
		D.IndentWithSpacesChanged -= RevealIndent;
		D.IndentSizeChanged -= RevealIndent;
		E.WrapChanged -= RevealWrap;
		
		Own.LocaleChanged -= RevealPositions;
		Own.LocaleChanged -= RevealIndent;
		Own.LocaleChanged -= RevealScheme;
		Own.LocaleChanged -= RevealZoom;
		
		contextMenu.Dispose();
		
		base.Dispose(disposing);
	}
	
	void RevealScheme ()
	{
		schemeDrop.Text = Own.Line(D.Scheme.Name);
	}
	
	void RevealNewline ()
	{
		newlineDrop.Text = D.Newline.Replace("\n", "LF").Replace("\r", "CR");
	}
	
	void RevealIndent ()
	{
		string i = D.IndentWithSpaces ? "Spaces (%0)" : "Tabs (%0)";
		indentDrop.Text = Own.Line(i, D.IndentSize.ToString());
	}
	
	void RevealEncoding ()
	{
		encodingDrop.Text = D.Encoding.EncodingName;
		if (!D.Encoding.EncodingName.StartsWith("Unicode")) return;
		if (D.SaveBom) encodingDrop.Text += " [BOM]";
	}
	
	void RevealWrap ()
	{
		wrapButton.Checked = E.Wrap;
	}
	
	void RevealZoom ()
	{
		zoomButton.Title = Math.Round(E.FontSize).ToString();
	}
	
	void RevealPositions ()
	{
		lineLabel.Text = Own.Line("Ln:");
		charLabel.Text = Own.Line("Ch:");
		
		linesTotalLabel.Text = "/" + D.Count.ToString();
		charsTotalLabel.Text = "/" + D[E.Caret.Line].Length.ToString();
		
		string txt = "";
		
		if (E.Selected)
		{
			if (E.SelectionStart.Line == E.SelectionEnd.Line)
			{
				txt += Own.Line("Sel Ch %0", (E.SelectionEnd.Char - E.SelectionStart.Char).ToString());
				
				if (E.SelectionEnd.Char - E.SelectionStart.Char == 1)
				{
					char c = D[E.Caret.Line].Text[E.SelectionStart.Char];
					txt += " " + c.ToString() + " [" + c.GetCode() + "]";
					string abbr = c.GetAbbr();
					if (abbr != null) txt += " (" + abbr + ")";
				}
			}
			else txt += Own.Line("Sel Ln %0", (E.SelectionEnd.Line - E.SelectionStart.Line + 1).ToString());
		}
		
		caretLabel.Text = txt;
		caretLabel.ToolTipText = txt;
		
		lineField.Value = E.Caret.Line + 1;
		charField.Value = E.Caret.Char + 1;
	}
	
	void ProcessMouseUp (object o, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			if (o is ToolStripItem) {
				ToolStripItem i = o as ToolStripItem;
				contextMenu.Show(this, i.Bounds.X + e.X, i.Bounds.Y + e.Y);
			} else contextMenu.Show(this, e.X, e.Y);
		}
	}
}