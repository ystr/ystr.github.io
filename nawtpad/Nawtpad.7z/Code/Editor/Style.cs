using System.Collections.Generic;
using System.Drawing;
using System.ComponentModel;
using System.Reflection;


class Style
{
	public class Component
	{
		public byte Index;
		
		public Pen ForePen = null;
		public Brush ForeBrush = null;
		public Brush BackBrush = null;
		public Brush NumForeBrush = null;
		public Brush NumBackBrush = null;
		public Brush StripBrush = null;
		public Pen GuidePen = null;
		public Brush FillBrush = null;
		public FontStyle? Font = null;
		public FontStyle? NumFont = null;
		
		public void Parse (string raw)
		{
			ForePen = null;
			ForeBrush = null;
			BackBrush = null;
			NumForeBrush = null;
			NumBackBrush = null;
			StripBrush = null;
			FillBrush = null;
			GuidePen = null;
			Font = null;
			NumFont = null;
			
			raw = raw.Trim();
			if (raw.Length == 0) return;
			
			string[] args = raw.Split(' ');
			if (args.Length == 0) return;
			
			foreach (string arg in args)
			{
				switch (arg.ToLower())
				{
					default:
						
						string[] spl = arg.Split(':');
						
						string key = spl[0].ToLower();
						string val = spl[1];
						
						switch (key)
						{
							case "fore":
								ForePen = new Pen(ParseColor(val));
								ForeBrush = new SolidBrush(ParseColor(val));
							break;
							case "back": BackBrush = new SolidBrush(ParseColor(val)); break;
							case "numfore": NumForeBrush = new SolidBrush(ParseColor(val)); break;
							case "numback": NumBackBrush = new SolidBrush(ParseColor(val)); break;
							case "strip": StripBrush = new SolidBrush(ParseColor(val)); break;
							case "font": Font = ParseFont(val); break;
							case "numfont": NumFont = ParseFont(val); break;
							case "guide": GuidePen = new Pen(ParseColor(val)); break;
							case "fill": FillBrush = new SolidBrush(ParseColor(val)); break;
						}
						
					break;
				}
			}
		}
		
		static FontStyle ParseFont (string raw)
		{
			FontStyle f = FontStyle.Regular;
			
			foreach (char c in raw)
			{
				switch (c)
				{
					case 'B': f |= FontStyle.Bold; break;
					case 'I': f |= FontStyle.Italic; break;
					case 'U': f |= FontStyle.Underline; break;
					case 'S': f |= FontStyle.Strikeout; break;
				}
			}
			
			return f;
		}
		
		static Color ParseColor (string s)
		{
			int alpha = 255;
			Color color;
			
			if (s.Contains("/"))
			{
				alpha /= int.Parse(s.Substring(s.IndexOf('/') + 1));
				s = s.Substring(0, s.IndexOf('/'));
			}
			
			switch (s)
			{
				case "SystemFore": color = Color.FromArgb(255, SystemColors.WindowText); break;
				case "SystemBack": color = Color.FromArgb(255, SystemColors.Window); break;
				case "SystemSelectedFore": color = Color.FromArgb(255, SystemColors.HighlightText); break;
				case "SystemSelectedBack": color = Color.FromArgb(255, SystemColors.Highlight); break;
				
				default:
					
					if (s[0] == '#' && s.Length == 4)
					{
						char r = s[1], g = s[2], b = s[3];
						s = new string ( new char [] { '#', r, r, g, g, b, b } );
					}
					
					color = (Color) TypeDescriptor.GetConverter(typeof(Color)).ConvertFromString(s);
					
				break;
			}
			
			return Color.FromArgb(alpha, color);
		}
	}
	
	List<Component> index = new List<Component>();
	Dictionary<string, Component> styles = new Dictionary<string, Component>();
	public Component ByIndex (byte i) { return index[i]; }
	
	public Component this [byte index]
	{
		get {
			return ByIndex(index);
		}
	}
	
	public Component this [string id]
	{
		get {
			
			if (!styles.ContainsKey(id))
			{
				Component nc = styles[id] = new Component();
				nc.Index = (byte) index.Count;
				index.Add(nc);
			}
			
			return styles[id];
		}
	}
	
	public readonly Component Default;
	public readonly Component Selected;
	public readonly Component Found;
	public readonly Component FoundAlt;
	public readonly Component Mark;
	public readonly Component Match;
	
	public Style (string file)
	{
		Default = this["Default"];
		Selected = this["Selected"];
		Found = this["Found"];
		FoundAlt = this["FoundAlt"];
		Mark = this["Mark"];
		Match = this["Match"];
		
		if (file != null) foreach (string line in file.SplitToLines())
		{
			if (line.StartsWith(";")) continue;
			if (!line.Contains("=")) continue;
			
			string[] split = line.Split('=');
			
			string key = split[0].Trim();
			if (key.Length == 0) continue;
			
			this[key].Parse(split[1]);
		}
	}
}