#include "Sys.h"

#ifdef SDL
	#include "SDL.c"
#endif
