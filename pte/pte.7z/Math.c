#define PIE 3.141592653589793238462643
#define TAU 6.283185307179586476925287

#define P2(X) ((X)*(X))
#define P3(X) ((X)*(X)*(X))
#define P4(X) ((X)*(X)*(X)*(X))
#define MIN(A,B) ((A)<(B)?(A):(B))
#define MAX(A,B) ((A)>(B)?(A):(B))
#define CLAMP(MIN,V,MAX) ((V) < (MIN) ? (MIN) : (V) > (MAX) ? (MAX) : (V))
#define WEIGH(Y0,Y,Y1) (((Y) - (Y0)) / ((Y1) - (Y0)))
#define LERP(X0,X,X1) ((X0) + ((X1) - (X0)) * (X))
#define ODD(X) ((X) & 1)
#define MARGIN 1E-10


typedef double real;
typedef float fake;


real Clamp (real min, real a, real max) { return CLAMP(min, a, max); }
fake Clamf (fake min, fake a, fake max) { return CLAMP(min, a, max); }
real Smooth (real v) { return P2(v) * (3 - 2 * v); }
real Max (real a, real b) { return MAX(a, b); }
real Min (real a, real b) { return MIN(a, b); }
real Max3 (real a, real b, real c) { return Max(Max(a, b), c); }
real Min3 (real a, real b, real c) { return Min(Min(a, b), c); }
real Weigh (real y0, real y, real y1) { return WEIGH(y0, y, y1); }
real Lerp (real x0, real x, real x1) { return LERP(x0, x, x1); }
fake Weigf (fake y0, fake y, fake y1) { return WEIGH(y0, y, y1); }
fake Lerf (fake x0, fake x, fake x1) { return LERP(x0, x, x1); }


real CatCH (real c, real h) { return sqrt(P2(h) - P2(c)); }
real HypCC (real a, real b) { return sqrt(P2(a) + P2(b)); }
real AltCH (real c, real h) { return CatCH(c, h) * c / h; }
real AltCC (real a, real b) { return a * b / HypCC(a, b); }


typedef struct { real X, Y; } Xy;
typedef struct { real X, Y, Z; } Xyz;
typedef struct { real X, Y, Z, W; } Rot;

#define IDENLOC { 0, 0, 0 }
#define IDENDIR { 0, 0, 1 }
#define IDENROT { 0, 0, 0, 1 }

static const Xyz IdenLoc = IDENLOC;
static const Xyz IdenDir = IDENDIR;
static const Rot IdenRot = IDENROT;

void MakeRot (Rot* r) { if (!r->X && !r->Y && !r->Z && !r->W) r->W = 1; }


Xyz Add (Xyz a, Xyz b) { return (Xyz) { a.X + b.X, a.Y + b.Y, a.Z + b.Z }; }
Xy Add2 (Xy a, Xy b) { return (Xy) { a.X + b.X, a.Y + b.Y }; }
Xyz Sub (Xyz a, Xyz b) { return (Xyz) { a.X - b.X, a.Y - b.Y, a.Z - b.Z }; }
Xyz Mul (Xyz a, real b) { return (Xyz) { a.X * b, a.Y * b, a.Z * b }; }
Xy Mul2 (Xy a, real b) { return (Xy) { a.X * b, a.Y * b }; }
Xyz Div (Xyz a, real b) { return (Xyz) { a.X / b, a.Y / b, a.Z / b }; }
real Dot (Xyz a, Xyz b) { return a.X * b.X + a.Y * b.Y + a.Z * b.Z; }
Xyz Mid (Xyz a, Xyz b) { return Mul(Add(a, b), 0.5); }
Xy Mid2 (Xy a, Xy b) { return Mul2(Add2(a, b), 0.5); }
Xyz NeXyz (Xyz v) { return (Xyz) { -v.X, -v.Y, -v.Z }; }
Rot NeRot (Rot r) { return (Rot) { -r.X, -r.Y, -r.Z, r.W }; }
real Qen (Xyz l) { return P2(l.X) + P2(l.Y) + P2(l.Z); }
real Len (Xyz l) { return sqrt(Qen(l)); }
real Qis (Xyz a, Xyz b) { return Qen(Sub(a, b)); }
real Dis (Xyz a, Xyz b) { return sqrt(Qis(a, b)); }
Xyz Renorm (Xyz v, real from, real to) { return Mul(v, to / from); }
Xyz Norm (Xyz v, real to) { return Renorm(v, Len(v), to); }


Xyz Cross (Xyz a, Xyz b)
{
	return (Xyz) {
		a.Y * b.Z - a.Z * b.Y,
		a.Z * b.X - a.X * b.Z,
		a.X * b.Y - a.Y * b.X,
	};
}


Xyz XyzRot (Xyz l, Rot r)
{
	real x = l.X * r.W + l.Y * -r.Z - l.Z * -r.Y;
	real y = l.Y * r.W + l.Z * -r.X - l.X * -r.Z;
	real z = l.Z * r.W + l.X * -r.Y - l.Y * -r.X;
	real w = l.X * r.X - l.Y * -r.Y - l.Z * -r.Z;
	
	return (Xyz) {
		r.W * x + r.X * w + r.Y * z - r.Z * y,
		r.W * y + r.Y * w + r.Z * x - r.X * z,
		r.W * z + r.Z * w + r.X * y - r.Y * x,
	};
}

Rot RotRot (Rot a, Rot b)
{
	return (Rot) {
		a.W * b.X + a.X * b.W + a.Y * b.Z - a.Z * b.Y,
		a.W * b.Y + a.Y * b.W + a.Z * b.X - a.X * b.Z,
		a.W * b.Z + a.Z * b.W + a.X * b.Y - a.Y * b.X,
		a.W * b.W - a.X * b.X - a.Y * b.Y - a.Z * b.Z,
	};
}


Rot NormRot (Rot r)
{
	real l = 1 / sqrt(P2(r.X) + P2(r.Y) + P2(r.Z) + P2(r.W));
	return (Rot) { r.X * l, r.Y * l, r.Z * l, r.W * l };
}

Rot RotFromAxis (Xyz a)
{
	real len = Len(a);
	if (len == 0) return IdenRot;
	
	Xyz v = Renorm(a, len, 1);
	
	real na = len / 2;
	real sa = sin(na);
	
	return (Rot) {
		v.X * sa,
		v.Y * sa,
		v.Z * sa,
		cos(na)
	};
}

Rot Look (Xyz dir)
{
	if (dir.Z < -1 + MARGIN) return (Rot) { 0, -1, 0, 0 };
	if (dir.Z > +1 - MARGIN) return (Rot) { 0, 0, 0, +1 };
	
	real ha = acos(dir.Z) * 0.5;
	real sa = sin(ha);
	
	real ax = -dir.Y, ay = dir.X;
	real am = 1 / sqrt(P2(ax) + P2(ay)) * sa;
	
	return (Rot) { ax * am, ay * am, 0, cos(ha) };
}


Xyz TriNormalUnn (Xyz v0, Xyz v1, Xyz v2)
{
	return Cross(Sub(v2, v0), Sub(v1, v0));
}

Xyz TriNormal (Xyz v0, Xyz v1, Xyz v2)
{
	return Norm(TriNormalUnn(v0, v1, v2), 1);
}

real ZenithUnn (Xyz vp, Xyz vn, Xyz lp)
{
	return Dot(Sub(lp, vp), vn);
}

real Zenith (Xyz vp, Xyz vn, Xyz lp)
{
	return Dot(Norm(Sub(lp, vp), 1), vn);
}

bool TriFront (Xyz v0, Xyz v1, Xyz v2, Xyz pov)
{
	return ZenithUnn(v0, TriNormalUnn(v0, v1, v2), pov) > 0;
}
