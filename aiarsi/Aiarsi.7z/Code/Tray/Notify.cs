using System;
using System.Media;
using System.Windows.Forms;

enum NotifyType
{
	Info,
	Problem,
	Error
}

static class Notify
{
	static Notify ()
	{
		Own.SkinChanged += Skinize;
		Skinize();
	}
	
	
	static bool mute;
	public static bool Mute {
		get { return mute; }
		set { Options.Root.Set("Mute", mute = value); }
	}
	
	
	static object asteriskLock = new object();
	
	static int asterisks = 0;
	
	public static int Asterisks { get { return asterisks; } }
	public static event Action AsterisksChanged = () => {};
	
	
	static Action asteriskClick = null;
	static object asteriskTarget = null;
	static Com asteriskTargetCom = null;
	
	static void ComActivated (object o, EventArgs e)
	{
		if (asteriskTargetCom == o) ClearAsterisks();
		(o as Com).Activated -= ComActivated;
	}
	
	public static void InvokeAsterisk ()
	{
		lock (asteriskLock)
		{
			if (asteriskClick != null)
			{
				asteriskClick();
				ClearAsterisks();
			}
		}
	}
	
	static public void ClearAsterisks ()
	{
		lock (asteriskLock)
		{
			asteriskClick = null;
			asteriskTarget = null;
			asteriskTargetCom = null;
			asterisks = 0;
		}
		
		AsterisksChanged();
	}
	
	
	static public void Announce (this Terminal src, NotifyType type, string title, string text)
	{
		Com com = null;
		Action click = null;
		
		if (src is Server) com = ConsoleCom.Opened(src as Server);
		else if (src is Channel) com = ChannelCom.Opened(src as Channel);
		else if (src is Query) com = QueryCom.Opened(src as Query);
		
		if (com != null)
		{
			if (com.Active) return;
			com.Activated += ComActivated;
			com.Flash();
		}
		
		if (src is Server) click = () => ConsoleCom.Open(src as Server);
		else if (src is Channel) click = () => ChannelCom.Open(src as Channel);
		else if (src is Query) click = () => QueryCom.Open(src as Query);
		
		bool ro = (Roster.The != null && Roster.The.Active);
		
		if (!ro)
		{
			lock (asteriskLock)
			{
				asteriskClick = click;
				
				if (asteriskTarget == null || asteriskTarget != src)
				{
					asteriskTargetCom = com;
					asteriskTarget = src;
					asterisks++;
				}
			}
			
			AsterisksChanged();
		}
		
		if (Mute) return;
		
		if (Settings.NotifySound) notifySound.PlaySync();
		if (!ro && Settings.NotifyBalloon) Tray.ShowBalloon(type, title, text);
	}
	
	
	static SoundPlayer notifySound;
	static void Skinize () { notifySound = new SoundPlayer(Own.Find("Notify.wav")); }
}
