using System;
using System.Drawing;
using System.Windows.Forms;

class UtilityWindow : Window
{
	public UtilityWindow (string sig) : base (sig)
	{
		Padding = new Padding(10);
		MaximizeBox = MinimizeBox = false;
		FormBorderStyle = FormBorderStyle.FixedSingle;
	}
}
