typedef Syxel Rgb8;
typedef Syxel Rgba8;

#define RGB8(r,g,b) (Rgb8) { .R = r, .G = g, .B = b }
#define RGBA8(r,g,b,a) (Rgba8) { .R = r, .G = g, .B = b, .A = a }

typedef struct { fake R, G, B; } Rgb;
typedef struct { fake R, G, B, A; } Rgba;

typedef void Shader (void* back, const void* fore, const void*);


Rgb8 Rgb8OfRgb (Rgb rgb)
{
	return (Rgb8) {
		.R = rgb.R * 0xFF,
		.G = rgb.G * 0xFF,
		.B = rgb.B * 0xFF,
	};
}

Rgba8 Rgba8OfRgba (Rgba rgba)
{
	return (Rgb8) {
		.R = rgba.R * 0xFF,
		.G = rgba.G * 0xFF,
		.B = rgba.B * 0xFF,
		.A = rgba.A * 0xFF,
	};
}


Rgb RgbMul (Rgb c, fake m) { return (Rgb) { c.R * m, c.G * m, c.B * m }; }
Rgb RgbAdd (Rgb a, Rgb b) { return (Rgb) { a.R + b.R, a.G + b.G, a.B + b.B }; }
Rgb RgbRgb (Rgb a, Rgb b) { return (Rgb) { a.R * b.R, a.G * b.G, a.B * b.B }; }


void OnSyxelAddA8HuedRgb8 (Syxel* back, const u8* fore, const Rgb8* hue)
{
	fu16 r = back->R + (hue->R ** fore >> 8);
	fu16 g = back->G + (hue->G ** fore >> 8);
	fu16 b = back->B + (hue->B ** fore >> 8);
	
	back->R = MIN(r, 0xFF);
	back->G = MIN(g, 0xFF);
	back->B = MIN(b, 0xFF);
}

void OnSyxelPutA8HuedRgb8 (Syxel* back, const u8* opa, const Rgb8* fore)
{
	back->R += (fore->R - back->R) ** opa >> 8;
	back->G += (fore->G - back->G) ** opa >> 8;
	back->B += (fore->B - back->B) ** opa >> 8;
}

void OnSyxelPutA8HuedRgba8 (Syxel* back, const u8* opa, const Rgba8* fore)
{
	back->R += (fore->R - back->R) * fore->A ** opa >> 16;
	back->G += (fore->G - back->G) * fore->A ** opa >> 16;
	back->B += (fore->B - back->B) * fore->A ** opa >> 16;
}
