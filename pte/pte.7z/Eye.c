typedef struct { fake Z; } Pixel;
typedef struct { fake X, Y, Z, R, G, B, U, V, W; } Apex;


typedef struct {
	
	Xyz Point;
	real Radius;
	Rgb Light;
	
	bool Glare;
	
} Lamp;


typedef struct { const Lamp* Lamps; fu8 LampsCount; } Liting;
typedef void PixelShader (Syxel*, Pixel*, const Apex*, const void*);


typedef struct {
	
	Raster Pixels;
	const Raster* To;
	
	fake Expo;
	fake Zoom;
	fake Xoom;
	
	Apex* L0, *L0M;
	Apex* L1, *L1M;
	
	Lamp Lamps[16];
	int LampsCount;
	
	Raster GlareBase;
	
} Eye;




real EyeV2SX (const Eye* e, real x, real z) { return x * e->Xoom / z; }
real EyeV2SY (const Eye* e, real y, real z) { return y * e->Xoom / z; }
real EyeV2SR (const Eye* e, real r, real z) { return r * e->Xoom / z; }

bool EyeV2S (Xy* s, const Eye* e, fake near, Xyz v)
{
	if (v.Z > near) return false;
		
	s->X = EyeV2SX(e, v.X, v.Z);
	if (s->X <= e->To->Clip.L) return false;
	if (s->X >= e->To->Clip.R) return false;
	
	s->Y = EyeV2SY(e, v.Y, v.Z);
	if (s->Y <= e->To->Clip.B) return false;
	if (s->Y >= e->To->Clip.T) return false;
	
	return true;
}

bool EyeSphereSeen (const Eye* e, fake near, Xyz p, fake r)
{
	fake bz = p.Z - r;
	if (bz > near) return false;
	fake sr = EyeV2SR(e, r, bz);
	
	fake sx = EyeV2SX(e, p.X, bz);
	if (sx - sr > e->To->Clip.R) return false;
	if (sx + sr < e->To->Clip.L) return false;
	
	fake sy = EyeV2SY(e, p.Y, bz);
	if (sy - sr > e->To->Clip.T) return false;
	if (sy + sr < e->To->Clip.B) return false;
	
	return true;
}




void InitIncApex (Apex* vs, const Apex* v0, const Apex* v1, fake xx)
{
	vs->Z = (v1->Z - v0->Z) * xx;
	vs->U = (v1->U - v0->U) * xx;
	vs->V = (v1->V - v0->V) * xx;
	vs->W = (v1->W - v0->W) * xx;
	vs->R = (v1->R - v0->R) * xx;
	vs->G = (v1->G - v0->G) * xx;
	vs->B = (v1->B - v0->B) * xx;
}

void InitVarApex (Apex* vs, const Apex* v0, const Apex* inc, fake xc)
{
	vs->Z = v0->Z + xc * inc->Z;
	vs->U = v0->U + xc * inc->U;
	vs->V = v0->V + xc * inc->V;
	vs->W = v0->W + xc * inc->W;
	vs->R = v0->R + xc * inc->R;
	vs->G = v0->G + xc * inc->G;
	vs->B = v0->B + xc * inc->B;
}

void SkipApex (Apex* vs, const Apex* inc, fake skip)
{
	vs->Z += inc->Z * skip;
	vs->U += inc->U * skip;
	vs->V += inc->V * skip;
	vs->W += inc->W * skip;
	vs->R += inc->R * skip;
	vs->G += inc->G * skip;
	vs->B += inc->B * skip;
}

void IncApex (Apex* vs, const Apex* inc)
{
	vs->Z += inc->Z;
	vs->U += inc->U;
	vs->V += inc->V;
	vs->W += inc->W;
	vs->R += inc->R;
	vs->G += inc->G;
	vs->B += inc->B;
}

void DrawRow (
	const Eye* eye, PixelShader* sha, const void* uni,
	int y, const Apex* v0, const Apex* v1
) {
	const Rect* const clip = &eye->To->Clip;
	
	if (v0->X > v1->X) SWAP(const Apex*, v0, v1);
	
	fake x0 = ceil(v0->X); if (x0 >= clip->R) return;
	fake x1 = ceil(v1->X); if (x1 <= clip->L || x0 >= x1) return;
	
	if (x1 > clip->R) x1 = clip->R;
	
	fake xx = 1 / (v1->X - v0->X);
	fake xc = x0 - v0->X;
	
	Apex inc; InitIncApex(&inc, v0, v1, xx);
	Apex var; InitVarApex(&var, v0, &inc, xc);
	
	if (x0 < clip->L)
	{
		fake skip = clip->L - x0;
		SkipApex(&var, &inc, skip);
		x0 = clip->L;
	}
	
	int x = x0;
	
	Pixel* pe = RefXY(&eye->Pixels, x, y);
	Syxel* pf = RefXY(eye->To, x, y);
	
	while (x < x1)
	{
		sha(pf, pe, &var, uni);
		
		IncApex(&var, &inc);
		
		x++;
		
		pe++;
		pf++;
	}
}

void Plot (
	fake y0, fake y1,
	const Apex* a0, const Apex* a1,
	const Rect* clip, Apex tgt[]
) {
	fake yy = 1 / (a1->Y - a0->Y);
	fake yc = y0 - a0->Y;
	
	fake xx = (a1->X - a0->X) * yy;
	fake x = a0->X + yc * xx;
	
	Apex inc; InitIncApex(&inc, a0, a1, yy);
	Apex var; InitVarApex(&var, a0, &inc, yc);
	
	if (y0 < clip->B)
	{
		fake skip = clip->B - y0;
		x += xx * skip;
		SkipApex(&var, &inc, skip);
		y0 = clip->B;
	}
	
	for (int y = y0; y < y1; ++y)
	{
		Apex* p = &tgt[y];
		
		*p = var;
		
		p->X = x;
		x += xx;
		
		IncApex(&var, &inc);
	}
}

void DrawTri (
	const Eye* eye, PixelShader* sha, const void* uni,
	const Apex* a0, const Apex* a1, const Apex* a2
) {
	const Rect* const clip = &eye->To->Clip;
	
	if (a1->X > a2->X) SWAP(const Apex*, a1, a2);
	if (a0->X > a1->X) SWAP(const Apex*, a0, a1);
	if (a1->X > a2->X) SWAP(const Apex*, a1, a2);
	
	if (ceil(a0->X) >= clip->R) return;
	if (ceil(a2->X) <= clip->L) return;
	
	if (a1->Y > a2->Y) SWAP(const Apex*, a1, a2);
	if (a0->Y > a1->Y) SWAP(const Apex*, a0, a1);
	if (a1->Y > a2->Y) SWAP(const Apex*, a1, a2);
	
	fake cy0 = ceil(a0->Y);
	fake cy1 = ceil(a1->Y);
	fake cy2 = ceil(a2->Y);
	
	if (cy2 <= clip->B) return;
	if (cy0 >= clip->T) return;
	if (cy2 <= cy0) return;
	
	int y0 = MAX(cy0, clip->B);
	int y1 = MIN(cy1, clip->T);
	int y2 = MIN(cy2, clip->T);
	
	Plot(cy0, y2, a0, a2, clip, eye->L0);
	
	if (cy1 > clip->B && cy0 < cy1) Plot(cy0, y1, a0, a1, clip, eye->L1);
	if (cy1 < clip->T && cy1 < cy2) Plot(cy1, y2, a1, a2, clip, eye->L1);
	
	for (int y = y0; y < y2; ++y)
		DrawRow(eye, sha, uni, y, &eye->L0[y], &eye->L1[y]);
}




void EyeClear (Eye* eye, Syxel color)
{
	eye->LampsCount = 0;
	
	fu32 meter = 0;
	const Rect clip = eye->Pixels.Clip;
	
	for (int y = clip.B; y < clip.T; ++y)
	{
		Pixel* p = RefXY(&eye->Pixels, clip.L, y);
		Syxel* o = RefXY(eye->To, clip.L, y);
		
		for (int x = 0; x < clip.W; ++x)
		{
			meter += o->R + o->G + o->B;
			
			p->Z = -INFINITY;
			*o = color;
			
			++p;
			++o;
		}
	}
	
	static const float mul = 1.0 / 0xFF;
	eye->Expo = 1 - mul * meter / clip.W / clip.H;
	if (eye->Expo < 0) eye->Expo = 0;
}

void EyePost (Eye* eye)
{
	for EACHC (const Lamp*, l, eye->Lamps)
	{
		if (!l->Glare) continue;
		if (l->Point.Z > 0) continue;
		
		real x = EyeV2SX(eye, l->Point.X, l->Point.Z);
		if (x <= eye->To->Clip.L || x >= eye->To->Clip.R) continue;
		real y = EyeV2SY(eye, l->Point.Y, l->Point.Z);
		if (y <= eye->To->Clip.B || y >= eye->To->Clip.T) continue;
		
		Pixel* ep = RefXY(&eye->Pixels, x, y);
		if (ep->Z > l->Point.Z + l->Radius) continue;
		
		Syxel tp; GetXY(&tp, eye->To, x, y);
		DrawSprite (
			eye->To, &eye->GlareBase, x, y,
			(Shader*) OnSyxelAddA8HuedRgb8, &tp
		);
	}
}

void EyeConfigure (Eye* e)
{
	e->Xoom =- e->Zoom * MIN(e->Pixels.Clip.R, e->Pixels.Clip.T);
}

void EyeBindScreen (Eye* e, const Raster* to)
{
	e->To = to;
}

void SetEye (Eye* e, const Rect* clip)
{
	KillRaster(&e->Pixels);
	InitRaster(&e->Pixels, sizeof(Pixel), clip);
	
	ZAP(e->L0M); e->L0M = NEW(Apex, clip->H), e->L0 = e->L0M - clip->B;
	ZAP(e->L1M); e->L1M = NEW(Apex, clip->H), e->L1 = e->L1M - clip->B;
	
	KillRaster(&e->GlareBase);
	GenSpot(&e->GlareBase, MAX(clip->R, clip->T), 1);
	
	EyeConfigure(e);
}

void EyeSetZoom (Eye* e, fake z)
{
	e->Zoom = z;
	EyeConfigure(e);
}

void InitEye (Eye* e)
{
	*e = (Eye) { .Zoom = 1 };
}
