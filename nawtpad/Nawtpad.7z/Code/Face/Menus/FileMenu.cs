using System.Windows.Forms;


class FileMenu : Menu
{
	public readonly Face F;
	public readonly Document D;
	
	Row saveRow = new Row("&Save", "Ctrl S");
	Row saveAsRow = new Row("Save &As…", "Ctrl Shift S");
	Row saveCopyRow = new Row("Save &Copy…", "Alt Shift S");
	Row openRow = new Row("&Open…", "Ctrl O");
	Row reloadRow = new Row("&Reload", "F5");
	Row schemeRow = new Row("&Scheme");
	Row newlineRow = new Row("&Newline");
	Row indentRow = new Row("&Indentation");
	Row encodingRow = new Row("&Encoding");
	Row instanceRow = new Row("New &Window", "Ctrl N");
	
	public FileMenu (Face f)
	{
		F = f;
		D = F.D;
		
		schemeRow.DropDown = new SchemeMenu(D);
		encodingRow.DropDown = new EncodingMenu(D);
		newlineRow.DropDown = new NewlineMenu(D);
		indentRow.DropDown = new IndentMenu(D);
		
		saveRow.Clicked += () => F.Save();
		saveAsRow.Clicked += () => F.ShowSaveAs();
		saveCopyRow.Clicked += () => F.ShowSaveCopy();
		openRow.Clicked += () => F.ShowOpen();
		reloadRow.Clicked += D.Reload;
		instanceRow.Clicked += F.NewInstance;
		
		Items.Add(saveRow);
		Items.Add(saveAsRow);
		Items.Add(saveCopyRow);
		Items.Add(openRow);
		Items.Add(reloadRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(schemeRow);
		Items.Add(encodingRow);
		Items.Add(newlineRow);
		Items.Add(indentRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(instanceRow);
	}
}