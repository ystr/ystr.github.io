using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

static class Sugar
{
	public static string[] SplitToLines (this string s)
	{
		string[] lfs = new string[] {"\r\n", "\n", "\r"};
		return s.Split(lfs, StringSplitOptions.None);
	}
	
	public static string[] Split (this string s, char div, int max)
	{
		return s.Split(new char[] { div }, max);
	}
	
	public static T[] ToArray <T> (this HashSet<T> hs)
	{
		T[] rarr = new T[hs.Count];
		hs.CopyTo(rarr); return rarr;
	}
	
	public static string Unescape (this string s)
	{
		try { return Regex.Unescape(s); }
		catch (ArgumentException) { return s; }
	}
}