#define ALEN(A) (sizeof(A) / sizeof(A[0]))
#define MSIZE(T,M) (sizeof(((T*)0)->M))
#define EACH(T,V,A,C) (T V = A, *_##V = (T) A + C; V < _##V; V++)
#define EACHA(T,V,A) EACH (T, V, A, ALEN(A))
#define EACHC(T,V,A) EACH(T,V,A,A##Count)
#define COUNT(I,N) (unsigned I = 0; I < N; ++I)
#define EACH0(T,V,A) (T* V##_ = A, *V = *V##_; *V##_; V = *++V##_)
#define SWAP(T,A,B) { T swap = A; A = B; B = swap; }
#define M8(A,B) ( ( (fu16) (A) * (fu16) (B) ) >> 8 )
#define FIRE(F) if (F) F

#define NEW_1(T) ( (T*) malloc(sizeof(T)) )
#define NEW_2(T,N) ( (T*) malloc(sizeof(T) * (N)) )
#define NEW_3(T,AT,AN) ( (T*) malloc(sizeof(T) + sizeof(AT) * (AN)) )
#define NEW_(T,N,A,X,...) X
#define NEW(...) NEW_(__VA_ARGS__,NEW_3,NEW_2,NEW_1,)(__VA_ARGS__)
#define NUW_1(T) ( (T*) calloc(sizeof(T), 1) )
#define NUW_2(T,N) ( (T*) calloc(sizeof(T), (N)) )
#define NUW_(T,N,X,...) X
#define NUW(...) NUW_(__VA_ARGS__,NUW_2,NUW_1,)(__VA_ARGS__)
#define ZAP(P) free(P)
#define ZAP0(P) ZAP(P), P = 0

#ifdef DEBUG
	#define CRASH *((int*)0) = 0
	#define ASSERTC(COND,CATCH) if (!(COND)) { CATCH; CRASH; }
	#define ASSERT(COND) ASSERTC(COND, printf("! %s %s %i\n", #COND, __FILE__, __LINE__))
#else
	#define ASSERTC(COND,CATCH)
	#define ASSERT(COND)
#endif
