#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h>
#include <signal.h>
#include <ctype.h>
#include <pwd.h>




typedef struct { unsigned char B, G, R, A; } Pixel;
typedef struct { XImage* XI; Pixel* Data; } Raster;

#define BM_FIRST Button1
#define BM_SECOND Button3
#define BM_THIRD Button2
#define BK_ESC XK_Escape
#define BK_DOWN XK_Down
#define BK_LEFT XK_Left
#define BK_RIGHT XK_Right
#define BK_UP XK_Up




#include "Bckbrd.c"




struct {
	Display* Display;
	Window Window;
	Window RootWindow;
	int Screen;
	GC Context;
	Rect Invalid;
} X = {0};




Raster* NewRaster (int w, int h)
{
	Raster* pi = malloc(sizeof(Raster));
	pi->Data = malloc(sizeof(Pixel) * w * h);
	
	pi->XI = XCreateImage ( X.Display,
		DefaultVisual(X.Display, X.Screen),
		DefaultDepth(X.Display, X.Screen),
		ZPixmap, 0, (char*) pi->Data, w, h, 32, w * 4
	);
	
	return pi;
}

void ZapRaster (Raster* pi)
{
	XDestroyImage(pi->XI);
	free(pi);
}

char* GetFullPath (const char* name)
{
	const char* condir = "/.bckbrd/";
	
	struct passwd* p = getpwuid(getuid());
	char* path = malloc(strlen(p->pw_dir) + strlen(condir) + 32);
	
	strcpy(path, p->pw_dir);
	strcat(path, condir);
	
	struct stat s = {0};
	if (stat(path, &s) == -1) mkdir(path, 0755);
	
	strcat(path, name);
	return path;
}

void* LoadData (const char* name)
{
	char* path = GetFullPath(name);
	FILE* f = fopen(path, "rb");
	free(path);
	
	if (!f) return 0;
	
	fseek(f, 0, SEEK_END);
	size_t len = ftell(f);
	fseek(f, 0, SEEK_SET);
	
	void* raw = malloc(len);
	size_t r = fread(raw, 1, len, f);
	fclose(f);
	
	if (r != len)
	{
		free(raw);
		return 0;
	}
	
	return raw;
}

void SaveData (const char* name, const void* data, long len)
{
	char* path = GetFullPath(name);
	FILE* f = fopen(path, "wb");
	fwrite(data, 1, len, f);
	fclose(f);
	free(path);
}

void DeleteData (const char* name)
{
	char* path = GetFullPath(name);
	unlink(path);
	free(path);
}

void Invalidate (const Rect* r)
{
	if (!r) r = &(Rect) {
		.R = Board.ScreenSize.X,
		.B = Board.ScreenSize.Y
	};
	
	if (X.Invalid.R) {
		if (r->L < X.Invalid.L) X.Invalid.L = r->R;
		if (r->T < X.Invalid.T) X.Invalid.T = r->T;
		if (r->R > X.Invalid.R) X.Invalid.R = r->R;
		if (r->B > X.Invalid.B) X.Invalid.B = r->B;
	} else X.Invalid = *r;
}

void Quit ()
{
	exit(0);
}




void XRender ()
{
	if (!X.Invalid.R) return;
	
	UpdateBoard();
	Rect gb = GetGridBounds(&X.Invalid);
	
	for (int gy = gb.T; gy <= gb.B; gy++)
	{
		for (int gx = gb.L; gx <= gb.R; gx++)
		{
			int x = gx * TILESIZE - Board.TileLocation.X;
			int y = gy * TILESIZE - Board.TileLocation.Y;
			
			Tile* t = *GetTileLocal(Board.Grid, gx, gy);
			
			XPutImage (
				X.Display, X.Window, X.Context,
				t->Buffer->XI, 0, 0, x, y, TILESIZE, TILESIZE
			);
		}
	}
	
	if (Board.Input.Mode == ERASING)
	{
		XSetForeground(X.Display, X.Context, 0xFF0000);
		
		XDrawRectangle (
			X.Display, X.Window, X.Context,
			Board.Input.NewSelRect.L, Board.Input.NewSelRect.T,
			Board.Input.NewSelRect.R - Board.Input.NewSelRect.L,
			Board.Input.NewSelRect.B - Board.Input.NewSelRect.T
		);
	}
	
	X.Invalid = (Rect) {0};
}




void XOnConfigure (const XConfigureEvent* e)
{
	NewBoard(e->width, e->height);
	Invalidate(&(Rect){ .R = e->width, .B = e->height });
}

void XOnExpose (const XExposeEvent* e)
{
	Invalidate( &(Rect) {
		.L = MAX(e->x, 0), .R = MIN(Board.ScreenSize.X, e->x + e->width),
		.T = MAX(e->y, 0), .B = MIN(Board.ScreenSize.Y, e->y + e->height)
	} );
}

void XOnMotion (const XMotionEvent* e)
{
	BbMouseMove(e->x, e->y);
}

void XOnButtonPress (const XButtonEvent* e)
{
	BbMouseDown(e->x, e->y, e->button);
}

void XOnButtonRelease (const XButtonEvent* e)
{
	BbMouseUp();
}

void XOnKeyPress (XEvent* e)
{
	BbKeyPress(toupper(XLookupKeysym(&e->xkey, 0)));
}




int main (int argc, char** argv)
{
	atexit(Finalize);
	signal(SIGTERM, Quit);
	
	XInitThreads();
	X.Display = XOpenDisplay(0);
	
	PrepareBoard();
	
	X.Screen = DefaultScreen(X.Display);
	Screen* s = DefaultScreenOfDisplay(X.Display);
	X.RootWindow = RootWindow(X.Display, X.Screen);
	
	int w = s->width / 2;
	int h = s->height / 2;
	int l = s->width / 2 - w / 2;
	int t = s->height / 2 - h / 2;
	
	X.Window = XCreateSimpleWindow (
		X.Display, X.RootWindow, l, t, w, h, 0, 0, 0
	);
	
	XSelectInput ( X.Display, X.Window,
		ExposureMask | ButtonPressMask | ButtonReleaseMask |
		PointerMotionMask | KeyPressMask | StructureNotifyMask
	);
	
	XStoreName(X.Display, X.Window, "Bckbrd");
	
	Atom wmDeleteMessage = XInternAtom(X.Display, "WM_DELETE_WINDOW", 0);
	XSetWMProtocols(X.Display, X.Window, &wmDeleteMessage, 1);
	X.Context = XCreateGC(X.Display, X.Window, 0, 0);
	
	XMapWindow(X.Display, X.Window);
	
	for ( XEvent e ;; )
	{
		XNextEvent(X.Display, &e);
		
		switch (e.type)
		{
			case Expose: XOnExpose((XExposeEvent*)&e); break;
			case ButtonPress: XOnButtonPress((XButtonEvent*)&e); break;
			case ButtonRelease: XOnButtonRelease((XButtonEvent*)&e); break;
			case MotionNotify: XOnMotion((XMotionEvent*)&e); break;
			case ConfigureNotify: XOnConfigure((XConfigureEvent*)&e); break;
			case KeyPress: XOnKeyPress(&e); break;
			case ClientMessage:
				if ((Atom) e.xclient.data.l[0] == wmDeleteMessage) Quit();
			break;
		}
		
		if (!XPending(X.Display)) XRender();
	}
}
