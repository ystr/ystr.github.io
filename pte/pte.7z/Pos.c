typedef struct { Xyz Loc; Rot Rot; } Pos, Pov;
void MakePos (Pos* p) { MakeRot(&p->Rot); }
#define IDENPOS { .Rot = IDENROT }
static const Pos IdenPos = IDENPOS;


Rot RotP2C (Rot r, Rot cr) { return RotRot(NeRot(cr), r); }
Xyz LocP2C (Xyz l, Xyz cl, Rot cr) { return XyzRot(Sub(l, cl), NeRot(cr)); }
Xyz DirP2C (Xyz d, Rot cr) { return XyzRot(d, NeRot(cr)); }

Rot RotC2P (Rot r, Rot cr) { return RotRot(cr, r); }
Xyz LocC2P (Xyz l, Xyz cl, Rot cr) { return Add(XyzRot(l, cr), cl); }
Xyz DirC2P (Xyz d, Rot cr) { return XyzRot(d, cr); }


Xyz LocC2PPos (Xyz l, const Pos* cp) { return LocC2P(l, cp->Loc, cp->Rot); }
Xyz DirC2PPos (Xyz d, const Pos* cp) { return DirC2P(d, cp->Rot); }
Rot RotC2PPos (Rot r, const Pos* cp) { return RotC2P(r, cp->Rot); }

Xyz LocP2CPos (Xyz l, const Pos* cp) { return LocP2C(l, cp->Loc, cp->Rot); }
Xyz DirP2CPos (Xyz d, const Pos* cp) { return DirP2C(d, cp->Rot); }
Rot RotP2CPos (Rot r, const Pos* cp) { return RotP2C(r, cp->Rot); }


Pos PosC2PPos (const Pos* p, const Pos* cp)
{
	return (Pos) {
		.Loc = LocC2PPos(p->Loc, cp),
		.Rot = RotC2PPos(p->Rot, cp),
	};
}

Pos PosP2CPos (const Pos* p, const Pos* cp)
{
	return (Pos) {
		.Loc = LocP2CPos(p->Loc, cp),
		.Rot = RotP2CPos(p->Rot, cp),
	};
}


#define LocProPov LocP2CPos
#define DirProPov DirP2CPos
#define RotProPov RotP2CPos
#define LocProPos LocC2PPos
#define DirProPos DirC2PPos
#define RotProPos RotC2PPos
