using System;
using System.Collections.Generic;
using System.Windows.Forms;


class SearchMenu : Menu
{
	public readonly Editor E;
	
	Row incrementalRow = new Row("&Incremental search");
	Row altRow = new Row("Highlight &Selected");
	
	public SearchMenu (Editor editor)
	{
		this.E = editor;
		
		Items.Add(incrementalRow);
		Items.Add(altRow);
		
		incrementalRow.Clicked += () => Editor.DefaultSearchIncremental = Editor.GlobalSearchIncremental = !Editor.DefaultSearchIncremental;
		altRow.Clicked += () => Editor.DefaultAltSearchEnabled = Editor.GlobalAltSearchEnabled = !Editor.DefaultAltSearchEnabled;
		
		Opening += (o, e) =>
		{
			E.SearchIncrementalChanged += Reveal;
			E.AltSearchEnabledChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.SearchIncrementalChanged -= Reveal;
			E.AltSearchEnabledChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		incrementalRow.Checked = E.SearchIncremental;
		altRow.Checked = E.AltSearchEnabled;
	}
}