BYTE* LoadFile (TCHAR* path)
{
	HANDLE file = CreateFile(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (file == INVALID_HANDLE_VALUE) return 0;
	
	int size = GetFileSize(file, 0);
	BYTE* out = new BYTE[size];
	
	DWORD br = 0;
	bool done = ReadFile(file, out, size, &br, 0);
	CloseHandle(file);
	
	if (done) return out;
	else return 0;
}
