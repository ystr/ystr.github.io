#define UNICODE
#define WINVER 0x0501

#include <ctype.h>
#include <windows.h>
#include <gdiplus.h>

#ifdef DEBUG
	#include <cstdio>
	#include <iostream>
#endif


namespace Vewr
{
	using namespace std;
	using namespace Gdiplus;
	
	#include "Apis.cc"
	#include "Files.cc"
	#include "Targa.cc"
	#include "System.cc"
	#include "Globals.cc"
	#include "Path.cc"
	#include "Icon.cc"
	#include "Draw.cc"
	#include "Frames.cc"
	#include "Load.cc"
	#include "Events.cc"
	#include "Start.cc"
};


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	#ifdef DEBUG
		AttachConsole(ATTACH_PARENT_PROCESS);
		freopen("CONOUT$", "wb", stdout);
	#endif
	
	Vewr :: Main();
	
	return 0;
}
