#!/usr/bin/env python3
import sys, math, os, ast, traceback, random
from collections import deque
from PIL import Image




class Cons:
	
	def Eval (self, e, c):
		Record(self); return Eval (e, self.Car,
			lambda o: Apply(e, o, self.Cdr, c) )
	
	def __call__ (self, env, arg, cnt):
		if not arg: return cnt(self)
		return Eval ( env, Car(arg),
			lambda key: Apply ( env, self[key], Cdr(arg),
				lambda a: cnt(a) ))
	
	def GetKV (self, key):
		while self:
			if key == Caar(self): return self
			self = Cdr(self)
	
	def __contains__ (self, key): return self.GetKV(key)
	def __getitem__ (self, key): return Cdar(self.GetKV(key))
	
	def Put (self, e): pass
	def Set (self, k, v): self.GetKV(k).Car.Cdr = v
	def Let (self, k, v):
		if k in self: self.Set(k, v)
		else: self.Cdr = Cons(Cons(k, v), self.Cdr)
	
	def __repr__ (self):
		l = []
		while self:
			if IsCons(self): l.append(Dump(self.Car))
			else: l.append(Parser.Pair); l.append(Dump(self)); break
			self = self.Cdr
		return "[" + " ".join(car for car in l) + "]"
	
	def __bool__ (self):
		return True
	
	def __len__ (self):
		i = 0
		while self:
			i += 1
			self = Cdr(self)
		return i
	
	def __init__ (self, car, cdr):
		self.Car, self.Cdr = car, cdr
	
	def From (l):
		head = tail = None
		for i in l:
			if tail: tail.Cdr = tail = Cons(i, None)
			else: head = tail = Cons(i, None)
		return head


class Int (int):
	
	Size = 2
	BigEndian = False
	
	def __repr__ (self):
		if self.Size == 0: return repr(int(self))
		else: return ( "${0:0" + repr(int(self.Size * 2)) + "X}"
			).format(self & (2 ** (self.Size * 8) - 1))
	
	def __new__ (cls, val, size = 0, big = None): return super(Int, cls).__new__(cls, val)
	
	def __init__ (self, val, size = 0, big = None):
		self.Size = size
		if big is not None: self.BigEndian = big
	
	def __bytes__ (self):
		size = self.Size or Int.Size
		return (self & (2 ** (size * 8) - 1)).to_bytes (
			size, 'big' if self.BigEndian else 'little' )


class String (str):
	
	def __bytes__ (self): return bytes(self, 'utf-8')
	def __getitem__ (self, i): return String(super().__getitem__(i))


class Key (String):
	
	def Eval (self, e, c): return c(e.Get(self))
	def Put (self, env): env.Let(self, Caret())
	def __repr__ (self): return str(self)
	def __call__ (self, env, arg, cnt):
		return Eval ( env, Car(arg),
			lambda val: Let ( env, self, val,
				lambda: Eval(env, Cdr(arg), cnt) ))


class Raw (bytearray):
	
	def __str__ (self): return str(self, 'utf-8')
	def __repr__ (self):
		return Parser.Bytes + "".join(f"{i:02X}" for i in self)
	
	def Set (self, i, v): self[i] = v
	def Let (self, i, v): self.Expand(i + 1); self[i] = v
	
	def __getitem__ (self, k):
		v = super().__getitem__(k)
		return Raw(v) if type(k) is slice else Int(v, 1)
	
	def Expand (self, l):
		if len(self) < l: self.extend([0] * (l - len(self)))
	
	def Write (self, path):
		with open(path, 'wb') as f:
			f.write(self)


class Env:
	
	def Has (self, k):
		if k in self.Map: return self
		elif self.Parent: return self.Parent.Has(k)
		else: return None
	
	def Where (self, k):
		has = self.Has(k)
		if has: return has
		else: raise Exception(Dump(k) + "?")
	
	def RelPath (self, path):
		return os.path.join(os.path.dirname(self.Path), path)
	
	def Let (self, k, v): self.Map[k] = v
	def Set (self, k, v): self.Where(k).Map[k] = v
	def Get (self, k): return self.Where(k).Map[k]
	
	def __getitem__ (self, k): return self.Get(k)
	def __setitem__ (self, k, v): self.Let(k, v)
	def __contains__ (self, k): return self.Has(k)
	def __repr__ (self): return '<env ' + repr(Cons.From(self.Map)) + '>'
	
	def __init__ (self, caller = None, parent = None, thru = None, path = None):
		
		self.Caller, self.Parent = caller, parent
		self.Path = path or (caller.Path if caller else None)
		self.Map = thru.Map if thru else {}


class Lambda:
	
	def __init__ (self, clos, defn):
		self.Clos, self.Defn = clos, defn
	
	def __repr__ (self):
		return Dump(Cons(Key('λ'), self.Defn))
	
	def __call__ (self, cenv, arg, cnt):
		lenv = Env(cenv, self.Clos)
		return LetArgs ( cenv, lenv, Car(self.Defn), arg,
			lambda: Do(lenv, None, Cdr(self.Defn), cnt ))


class Caret:
	
	AddrSize = 2
	
	def __int__ (self): return self.Virt
	def __bytes__ (self): return bytes(Int(self.Virt, self.AddrSize))
	def __repr__ (self): return "[caret " + repr(self.Phys) + " " + repr(self.Virt) + "]"
	def __init__ (self, pa = None, va = None):
		self.Phys = pa if pa is not None else Out.Phys
		self.Virt = va if va is not None else Out.Virt


class Call:
	
	def __call__ (self, *a): return self.Fun(*a)
	def __init__ (self, name, fun): self.Name, self.Fun = name, fun
	def __repr__ (self): return "<call '" + self.Name + "'>"


class Rom (Raw):
	
	Phys = 0
	Virt = 0
	
	def PutBytes (self, b):
		
		self.Expand(self.Phys + len(b))
		
		for c in b:
			
			self[self.Phys] = c
			
			self.Phys += 1
			self.Virt += 1


class Real (float):
	
	pass




class Parser:
	
	Prefs = { ':' : 'quote', '@@' : 'virt-at', '@' : 'at', '-' : '-', '+' : '+' };
	Posfs = { ':' : 'quote' };
	
	def SetPref (k, v): Parser.Prefs[k] = v
	def SetPosf (k, v): Parser.Posfs[k] = v
	
	Comment = '#'
	Openers = '[({'
	Closers = '])}'
	Newlines = '\n'
	Spaces = ' \t' + Newlines
	Enders = Spaces + Closers + Comment
	Breakers = Openers + Enders
	Uncomment = Newlines
	Strings = "\"'"
	Bytes = '$$'
	Pair = ':'
	
	Tag = None
	Input = None
	Pos = 0
	Depth = 0
	
	class Abrupt (Exception):
		def __init__ (self, p):
			self.Depth = p.Depth
	
	def In (self):
		if self.Pos < len(self.Input): return True
		elif self.Depth: raise Parser.Abrupt(self)
	def At (self, at = None): return self.Input[at or self.Pos]
	def OneOf (self, hay, at = None): return self.At(at) in hay
	def Line (self, i): return self.Input[:i or self.Pos].count('\n') + 1
	
	def Next (self):
		while self.In() and self.OneOf(self.Spaces): self.Pos += 1
		if self.In() and self.OneOf(self.Comment):
			self.Pos += 1
			while self.In() and not self.OneOf(self.Uncomment): self.Pos += 1
			self.Pos += 1
			return self.Next()
		return self.In() and not self.OneOf(self.Closers)
	
	def Dive (self, fn, *a):
		self.Pos += 1
		self.Depth += 1
		o = fn(*a)
		self.Depth -= 1
		self.Pos += 1
		return o
	
	def ParseString (self, q):
		start = self.Pos
		while self.In():
			if self.At() == '\\': self.Pos += 1
			elif self.At() == q: break
			self.Pos += 1
		end = self.Pos
		return String(ast.literal_eval(q + self.Input[start:end] + q))
	
	def ParseInt (s):
		
		try: return Int(int(s))
		except: pass
		
		p = s[0]
		n = s[1:]
		
		if not len(n): raise Exception(s)
		if p == '$':
			val = int(n, 16)
			div = 2
		elif p == '%':
			val = 0
			div = 8
			oi = 0; ii = len(n) - 1
			while ii >= 0:
				if n[ii] == '1' or n[ii].isupper(): val |= 1 << oi
				oi += 1; ii -= 1
		else: raise Exception(s)
		
		return Int(val, math.ceil(len(n) / div))
	
	def EatWord (self):
		s0 = self.Pos
		while self.In() and not self.OneOf(self.Breakers): self.Pos += 1
		w = self.Input[s0:self.Pos]
		return w
	
	def Pfx (ps, iff):
		for p in sorted(ps, reverse = True):
			if iff(p): return p
	
	def ParseWord (self, w):
		
		pos = Parser.Pfx(self.Posfs, lambda p: len(w) > len(p) and w.endswith(p))
		if pos: return Cons(Key(self.Posfs[pos]), Cons(self.ParseWord(w[:-len(pos)]), None))
		
		if w.startswith(self.Bytes):
			return Raw(bytearray.fromhex(w[len(self.Bytes):]))
		
		try: return Parser.ParseInt(w)
		except:
			try: return Real(float(w))
			except: return Key(w)
	
	def ParseOne (self):
		
		pos = self.Pos
		pre = Parser.Pfx ( self.Prefs, lambda p:
			self.Input.startswith(p, pos) and
			pos + len(p) < len(self.Input) and
			not self.OneOf(self.Enders, pos + len(p)) )
		
		if pre:
			self.Pos += len(pre);
			o = Cons(Key(self.Prefs[pre]), Cons(self.ParseOne(), None))
		elif self.OneOf(self.Openers): o = self.Dive(self.ParseAll)
		elif self.OneOf(self.Strings): o = self.Dive(self.ParseString, self.At())
		else: o = self.ParseWord(self.EatWord())
		
		if o is not None:
			o.Meta = Cons(self, pos);
		return o
	
	def ParseAll (self):
		head, tail = None, None
		while self.Next():
			this = Cons(self.ParseOne(), None)
			if head != None and isinstance(this.Car, Key) and this.Car == self.Pair:
				if self.Next(): this = self.ParseOne()
			if tail:
				if IsCons(tail): tail.Cdr = tail = this
			else: head = tail = this
		return head
	
	def __init__ (self, inp, tag = None):
		self.Input, self.Tag = inp, tag




def IsCons (v): return type(v) == Cons
def IsAtom (v): return v != None and type(v) != Cons
def IsTrue (v): return v != None

def Car (o): return o.Car if IsCons(o) else o
def Cdr (o): return o.Cdr if IsCons(o) else None
def Cadr (o): return Car(Cdr(o))
def Caar (o): return Car(Car(o))
def Cddr (o): return Cdr(Cdr(o))
def Cdar (o): return Cdr(Car(o))




def Eval (e, o, c):
	return o.Eval(e, c) if hasattr(o, 'Eval') else c(o)

def Apply (e, o, a, c):
	return o(e, a, c) if callable(o) else c(o)

def Put (o, env, cnt):
	if o is None: pass
	elif hasattr(o, 'Put'): o.Put(env)
	else: Out.PutBytes(bytes(o))
	return cnt

def Str (o):
	if o is None: return ''
	else: return str(o)

def Dump (o):
	return repr(o) if IsTrue(o) else '()'




def Let (env, key, val, cnt): env.Let(key, val); return cnt
def LetArgs (cenv, lenv, keys, vals, cnt):
	if IsAtom(keys): return Let(lenv, keys, vals, cnt)
	if not keys and not vals: return cnt
	return Eval ( cenv, Car(vals),
		lambda v: Let ( lenv, Car(keys), v,
			lambda: Apply ( cenv, Cdr(vals), None,
				lambda cdr: LetArgs(cenv, lenv, Cdr(keys), cdr, cnt) )))

def Fold (env, fun, acc, all, cnt):
	if not all: return lambda: cnt(acc)
	return Eval ( env, Car(all),
		lambda e: fun ( acc, e,
			lambda acc, nxt = True:
				lambda: Apply ( env, Cdr(all), None,
					lambda cdr: Fold(env, fun, acc, cdr, cnt) if nxt else cnt(acc) )))

def Reduce (env, fun, all, cnt):
	return Eval ( env, Car(all),
		lambda ini: Apply ( env, Cdr(all), None,
			lambda cdr: Fold(env, fun, ini, cdr, cnt) ))

def Do (env, ret, arg, cnt):
	if arg is None: return lambda: cnt(ret)
	else: return Eval ( env, Car(arg),
		lambda e: (Put if Cdr(arg) else Thru) ( e, env,
			lambda: Apply ( env, Cdr(arg), None,
				lambda cdr: Do(env, e, cdr, cnt) )))

def If (env, arg, cnt):
	if arg is None: return lambda: cnt(None)
	else: return Eval ( env, Car(arg),
		lambda cnd: (
			Eval(env, Cadr(arg), cnt) if IsTrue(cnd)
			else lambda: If(env, Cddr(arg), cnt) ))

def At (e, c, a):
	if isinstance(a, Caret): Out.Phys, Out.Virt = a.Phys, a.Virt
	else: Out.Phys = Out.Virt = int(a)
	return c(None)

def VirtAt (e, c, a):
	Out.Virt = int(a)
	return c(None)

def Load (env, cnt, path):
	with open(path, mode='rb') as f:
		return cnt(Raw(f.read()))

def ImgLoad (path): return Image.open(path).convert('RGBA')
def ImgSave (img, path): img.save(path)
def ImgNew (w, h): return Image.new('RGBA', (w, h))
def ImgSet (i, x, y, v): i.putpixel((x, y), int(v))
def P2I (p): return p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24)
def ImgGet (i, x, y): return P2I(i.getpixel((x, y)))

def Thru (o, env, cnt): return cnt
def Arg (a, b, c): a.append(b); return c(a)
def LArgsA (f): return lambda e, a, c: Fold(e, Arg, [], a, lambda a: f(e, c, a))
def LArgs (f): return LArgsA(lambda e, c, a: f(e, c, *a))
def LFun (f): return LArgsA(lambda e, c, a: c(f(*a)))
def Logic (pre): return lambda a, b, c: c(b, True) if pre(a, b) else c(None, False)
def LogicReduce (env, pre, all, cnt): return Reduce(env, Logic(pre), all, cnt)
def LLogicReduce (f): return lambda e, a, c: LogicReduce(e, f, a, c)
def PrStr (s): print(Str(s), end = '', flush = True)
def Size (n): return n.Size if type(n) == Int else 0
def N (size, r): return Int(r, size) if isinstance(r, int) else r
def NN (a, b, r): return N(max(Size(a), Size(b)), r)

def LReduce (f, ini = None):
	return lambda e, a, c: (
		Reduce(e, lambda a,b,c: c(f(a, b)), a, c) if Cdr(a)
		else Fold(e, lambda a,b,c: c(f(a, b)), ini, a, c) )

def Try (e, a, c):
	Traps.append(lambda: c(None))
	def pop (o): Traps.pop(); return c(o)
	return lambda: Do(e, None, a, pop)


Core = {
	
	'quote'    : lambda e, a, c: c(Car(a)),
	'type'     : LFun(lambda a: type(a).__name__ if IsTrue(a) else None),
	'cons?'    : LFun(lambda a: a if IsCons(a) else None),
	'atom?'    : LFun(lambda a: a if IsAtom(a) else None),
	
	'car'      : LFun(Car),
	'cdr'      : LFun(Cdr),
	
	'has'      : LArgs(lambda e, c, k, ie = None: c(k if k in (ie or e) else None)),
	'get'      : LArgs(lambda e, c, k, ie = None: c((ie or e)[k])),
	'let'      : LArgs(lambda e, c, k, v, ie = None: c((ie or e).Let(k, v))),
	'set'      : LArgs(lambda e, c, k, v, ie = None: c((ie or e).Set(k, v))),
	'sub'      : LFun(lambda o, i0 = None, i1 = None: o[i0:i1]),
	'len'      : LFun(lambda o: len(o) if IsTrue(o) else 0),
	'size'     : LFun(Size),
	
	'eval'     : LArgs(lambda e,c,o,ie=None: Eval(ie or e, o, c)),
	'apply'    : LArgs(lambda e,c,o,a,ie=None: Apply(ie or e, o, a, c)),
	'dump'     : LFun(Dump),
	
	'local'    : LArgs(lambda e,c: c(e)),
	'caller'   : LArgs(lambda e,c,ie=None: c((ie or e).Caller)),
	'parent'   : LArgs(lambda e,c,ie=None: c((ie or e).Parent)),
	
	'if'       : If,
	'do'       : lambda e,a,c: Do(e, None, a, c),
	'try'      : Try,
	
	'+'        : LReduce(lambda a, b: NN(a, b, a + b), 0),
	'*'        : LReduce(lambda a, b: NN(a, b, a * b), 1),
	'-'        : LReduce(lambda a, b: NN(a, b, a - b), 0),
	'/'        : LReduce(lambda a, b: NN(a, b, a / b), 1),
	'%'        : LReduce(lambda a, b: NN(a, b, a % b), 1),
	'|'        : LReduce(lambda a, b: NN(a, b, a | b)),
	'^'        : LReduce(lambda a, b: NN(a, b, a ^ b)),
	'&'        : LReduce(lambda a, b: NN(a, b, a & b)),
	'pow'      : LReduce(lambda a, b: NN(a, b, a ** b)),
	'~'        : LArgs(lambda e,c,a: c(N(Size(a), ~a))),
	'<<'       : LArgs(lambda e,c,i,s: c(N(i, i << s))),
	'>>'       : LArgs(lambda e,c,i,s: c(N(i, i >> s))),
	
	'<'        : LLogicReduce(lambda a, b: a < b),
	'>'        : LLogicReduce(lambda a, b: a > b),
	'<='       : LLogicReduce(lambda a, b: a <= b),
	'>='       : LLogicReduce(lambda a, b: a >= b),
	'=='       : LLogicReduce(lambda a, b: a == b),
	'!='       : LLogicReduce(lambda a, b: a != b),
	
	'floor'    : LFun(math.floor),
	'ceil'     : LFun(math.ceil),
	'log2'     : LFun(math.log2),
	'sqrt'     : LFun(math.sqrt),
	'rand'     : LFun(random.random),
	'sin'      : LFun(math.sin),
	'cos'      : LFun(math.cos),
	'tan'      : LFun(math.tan),
	'asin'     : LFun(math.asin),
	'acos'     : LFun(math.acos),
	'atan'     : LFun(math.atan),
	'atan2'    : LFun(math.atan2),
	
	'key'      : lambda e,a,c: Core['str'](e, a, lambda o: c(Key(o))),
	'str'      : LReduce(lambda a, b: String(Str(a) + Str(b))),
	'int'      : LFun(Int),
	'real'     : LFun(Real),
	'env'      : LFun(Env),
	'raw'      : LFun(lambda s: Raw(bytes(s))),
	'lambda'   : lambda e, a, c: c(Lambda(e, a)),
	'cons'     : LFun(Cons),
	'caret'    : LFun(Caret),
	
	'at'       : LArgs(At),
	'virt-at'  : LArgs(VirtAt),
	'where'    : LFun(Caret),
	'phys'     : LFun(lambda a = None: Int((a or Out).Phys, (a or Caret).AddrSize)),
	'virt'     : LFun(lambda a = None: Int((a or Out).Virt, (a or Caret).AddrSize)),
	'path'     : LArgs(lambda e,c,ie=None: c((ie or e).Path)),
	'rel-path' : LArgs(lambda e,c,p,ie=None: c((ie or e).RelPath(p))),
	'include'  : LArgs(lambda e,c,p: c(ExecFile(e.RelPath(p)))),
	'rom'      : lambda e, a, c: c(Out),
	'pref'     : LFun(Parser.SetPref),
	'posf'     : LFun(Parser.SetPosf),
	'parse'    : LFun(lambda s: Parser(Str(s)).ParseAll()),
	'load'     : LArgs(Load),
	'save'     : LFun(lambda o, path: Raw(bytes(o)).Write(path)),
	'say'      : lambda e, a, c: Core['str'](e, a, lambda o: c(PrStr(o))),
	
	'img-load' : LFun(ImgLoad),
	'img-save' : LFun(ImgSave),
	'img-new'  : LFun(ImgNew),
	'img-get'  : LFun(ImgGet),
	'img-set'  : LFun(ImgSet),
	'img-xs'   : LFun(lambda i: i.size[0]),
	'img-ys'   : LFun(lambda i: i.size[1]),
	
}


Root = Env()
for k, v in Core.items():
	Root.Let(k, Call(k, v))




Repl = False
InPaths = []
OutPath = None
Out = Rom()

Trace = deque()
TraceMax = 32
Traps = []

def Record (o):
	if len(Trace) > TraceMax: Trace.popleft()
	Trace.append(o)

def Style (s, c):
	return '\033[' + c + 'm' + str(s) + '\033[0m'

def Attrib (par, pos):
	return (par.Tag + " " if par.Tag else "") + str(par.Line(pos))

def Chop (s, l = 64):
	return s[:l] + '…' if len(s) > l else s

def Report (o):
	return ( Attrib(o.Meta.Car, o.Meta.Cdr) + ' '
		if hasattr(o, 'Meta') else '' ) + Chop(Dump(o))

def Unroll ():
	for t in Trace:
		print(Style(Report(t), '31'))
	Trace.clear()

def Fail (e):
	#print(Style(traceback.format_exc(), '31;2'))
	Unroll()
	print(Style(e, '31;1'))

def Output (o, echo, put):
	if echo: print(Style(Dump(o), '33'))
	if put: Put(o, Root, None)

def Run (c):
	while c:
		try: c = c()
		except KeyboardInterrupt: raise
		except:
			if Traps: c = Traps.pop()
			else: raise

def Exec (raw, path = '.', abrupt = 0, echo = 0, put = 0):
	par = Parser(raw, path)
	env = Env(None, Root, thru = Root, path = path)
	while par.Next():
		try:
			pos = par.Pos
			Run(Eval(env, par.ParseOne(), lambda o: Output(o, echo, put)))
		except Parser.Abrupt as e:
			if abrupt: raise Exception(Attrib(par, pos) + " (" * e.Depth)
			else: raise
		except KeyboardInterrupt: raise
		except Exception as e:
			raise Exception(Attrib(par, pos) + " " + str(e))

def ExecFile (path):
	return Exec(open(path).read(), path = path, abrupt = 1, echo = 0, put = 1)


ai = 1
while ai < len(sys.argv):
	
	a = sys.argv[ai]
	
	if a == '--': Root.Let('argv', Cons.From(sys.argv[ai+1:])); break
	elif a == '-o': ai += 1; OutPath = sys.argv[ai]
	elif a == '-E': Int.BigEndian = True
	elif a == '-e': Int.BigEndian = False
	elif a == '-i': ai += 1; Int.Size = int(sys.argv[ai])
	elif a == '-a': ai += 1; Caret.AddrSize = int(sys.argv[ai])
	elif a == '-': Repl = True
	else: InPaths.append(a)
	
	ai += 1


try:
	for f in InPaths: ExecFile(f)
	Run(Root['finalize'](Root, None, lambda o: None))
	if OutPath: Out.Write(OutPath)
except KeyboardInterrupt:
	if not Repl: exit(1)
except Exception as e:
	Fail(e)
	exit(1)


Input = []
Depth = 0

while Repl:
	try:
		Trace.clear()
		Input.append(input(Style('>' * (1 + Depth), '92') + ' '))
		Exec("\n".join(Input), echo = 1)
	except KeyboardInterrupt:
		if Depth: print()
		elif not Input: exit(1)
	except Parser.Abrupt as e: Depth = e.Depth; continue
	except Exception as e: Fail(e)
	Input.clear()
	Depth = 0
