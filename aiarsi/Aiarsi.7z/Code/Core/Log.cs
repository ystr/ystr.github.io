using System;
using System.IO;
using System.Text;
using System.Collections.Generic;


enum LogTag
{
	RawOutgoing, RawIncoming,
	OutgoingSpeech, IncomingSpeech,
	OutgoingAction, IncomingAction,
	OutgoingNotice, IncomingNotice,
	
	Client, Error,
	Info, Useless,
	
	Topic,
	Mode, Name,
	Join, Part,
	Kick, Quit
}


class Chunk
{
	public readonly Style Style;
	public readonly string Text;
	
	public Chunk (string text) : this (Style.Default, text) { }
	public Chunk (Style format, string text) { Style = format; Text = text; }
}


class Entry
{
	public delegate void Action (Entry e);
	
	public ulong? Number = null;
	public readonly string Bullet;
	public readonly LogTag Tag = LogTag.Client;
	public readonly DateTime Time = DateTime.Now;
	public readonly List<Chunk> Output = new List<Chunk>();
	
	string plain = "";
	public string Plain { get { return plain; } }
	
	public void Add (string t)
	{
		Add(Style.Get(Tag.ToString()), t);
	}
	
	public void Add (Style f, string t)
	{
		if (t == null) return;
		if (true) t = t.StripFormatting();
		Output.Add(new Chunk(f, t));
		plain += t;
	}
	
	public Entry (LogTag tag)
	{
		switch (Tag = tag)
		{
			case LogTag.IncomingSpeech:
			case LogTag.IncomingAction:
			case LogTag.IncomingNotice:
			case LogTag.OutgoingSpeech:
			case LogTag.OutgoingAction:
			case LogTag.OutgoingNotice:

				Bullet = "►";
				
			break;
			
			case LogTag.Info: Bullet = "■"; break;
			case LogTag.Useless: Bullet = "-"; break;
			case LogTag.Error: Bullet = "×"; break;
			
			case LogTag.RawIncoming: Bullet = "↓"; break;
			case LogTag.RawOutgoing: Bullet = "↑"; break;
			
			default: Bullet = "●"; break;
		}
	}
}


[Flags] enum Unread
{
	None = 0,
	Message = 1,
	Important = 2
}

delegate void UnreadHandler (Unread u);


class Log
{
	public const int Limit = 512;
	public event Entry.Action Logged = (e) => {};
	
	public Log ()
	{
		Settings.Changed += SetFilePath;
	}
	
	
	readonly List<Entry> log = new List<Entry>();
	
	ulong counter = 0;
	
	public Entry[] GetEntries ()
	{
		lock (log)
		{
			return log.ToArray();
		}
	}
	
	
	string logFile = null;
	string logPath = null;
	
	public string LogFile
	{
		get { return logFile; }
		set { logFile = value; SetFilePath(); }
	}
	
	void SetFilePath ()
	{
		string root = Settings.Portable ? "Logs" : Settings.LogRoot;
		logPath = Environment.ExpandEnvironmentVariables(root) + "\\" + logFile;
		if (Settings.SaveLogs) Directory.CreateDirectory(Path.GetDirectoryName(logPath));
	}
	
	void WriteToFile (Entry e)
	{
		string line = "[" + e.Time.ToString("dd.MM.yy H:mm:ss") + "] " + e.Plain;
		using (StreamWriter w = File.AppendText(logPath)) w.WriteLine(line);
	}
	
	
	public Entry Push (Entry e)
	{
		lock (log)
		{
			log.Add(e);
			if (log.Count > Limit) log.RemoveAt(0);
			e.Number = counter++;
		}
		
		if (Settings.SaveLogs) WriteToFile(e);
		Logged(e);
		return e;
	}
	
	public Entry Push (LogTag tag, string line)
	{
		Entry e = new Entry(tag);
		e.Add(line);
		return Push(e);
	}
	
	public Entry Push (LogTag tag, string line, params string[] args)
	{
		Entry e = new Entry(tag);
		e.Add(Own.Line(line, args));
		return Push(e);
	}
	
	
	#region Unread
		
		bool nowReading = false;
		Unread unread = Unread.None;
		object unreadLock = new object();
		public event Action UnreadChanged = () => {};
		
		public bool NowReading
		{
			set
			{
				lock (unreadLock)
				{
					nowReading = value;
				}
			}
		}
		
		public Unread Unread
		{
			get
			{
				lock (unreadLock)
				{
					return unread;
				}
			}
			
			set
			{
				lock (unreadLock)
				{
					if (nowReading) value = Unread.None;
					if (unread == value) return;
					unread = value;
				}
				
				UnreadChanged();
			}
		}
		
	#endregion
}