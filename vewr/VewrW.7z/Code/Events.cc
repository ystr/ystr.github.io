bool CursorShown = true;
UINT_PTR CursorTimer = 0;

void SetShowCursor (bool on)
{
	if (CursorShown == on) return;
	ShowCursor(CursorShown = on);
}

void CALLBACK OnCursorDelayElapsed (HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	SetShowCursor(false);
	KillTimer(0, CursorTimer);
}

void HideCursorDelayed ()
{
	if (CursorTimer) KillTimer(0, CursorTimer);
	CursorTimer = SetTimer(0, 0, 100, OnCursorDelayElapsed);
}

void SetCursor (TCHAR* name)
{
	HCURSOR c = LoadCursor(0, name);
	SetClassLong(WinHandle, GCL_HCURSOR, (long)c);
	POINT p; GetCursorPos(&p); SetCursorPos(p.x, p.y);
}




void SetTitle (TCHAR* title)
{
	SendMessage(WinHandle, WM_SETTEXT, 0, (LPARAM)title);
}

void ApplyBackground ()
{
	long brush;
	
	if (Back < 0) brush = (long) CreateSolidBrush(GetSysColor(COLOR_3DFACE));
	else brush = (long) CreateSolidBrush(RGB(Backs[Back], Backs[Back], Backs[Back]));
	
	SetClassLong(WinHandle, GCL_HBRBACKGROUND, brush);
}

void ToggleFullScreen ()
{
	static struct {
		int Left, Top;
		int Xs, Ys;
		long Style;
		int Back;
	} Old;
	
	Blink = true;
	FullScreen = !FullScreen;
	X = Y = 0;
	
	if (FullScreen)
	{
		HideCursorDelayed();
		
		Old.Back = Back; Back = 0; ApplyBackground();
		Old.Style = GetWindowLong(WinHandle, GWL_STYLE);
		
		RECT orr; GetWindowRect(WinHandle, &orr);
		
		Old.Left = orr.left;
		Old.Top = orr.top;
		Old.Xs = orr.right - orr.left;
		Old.Ys = orr.bottom - orr.top;
		
		SetWindowLong(WinHandle, GWL_STYLE, Old.Style & ~(WS_CAPTION | WS_THICKFRAME));
		
		SetWindowPos (
			WinHandle, HWND_TOPMOST, 0, 0,
			GetSystemMetrics(SM_CXSCREEN),
			GetSystemMetrics(SM_CYSCREEN),
			SWP_FRAMECHANGED
		);
	}
	else
	{
		if (CursorTimer)
		{
			KillTimer(0, CursorTimer);
			CursorTimer = 0;
		}
		
		SetShowCursor(true);
		
		Back = Old.Back;
		SetWindowLong(WinHandle, GWL_STYLE, Old.Style);
		
		SetWindowPos (
			WinHandle, HWND_NOTOPMOST,
			Old.Left, Old.Top,
			Old.Xs, Old.Ys,
			SWP_FRAMECHANGED
		);
		
		ShowIcon();
	}
	
	Blink = false;
}

void SetFit (bool fit)
{
	Fit = fit;
	
	if (Fit) SetCursor(IDC_ARROW);
	else SetCursor(IDC_SIZEALL);
}

void ChangeFit (bool fit)
{
	SetFit(fit);
	SourceToScreen();
	ScreenToWindow();
}

void ToggleFit ()
{
	ChangeFit(!Fit);
}

void FromFit ()
{
	SetFit(false);
	
	float sor = (float) SourceWidth / (float) SourceHeight;
	float scr = (float) ScreenWidth / (float) ScreenHeight;
	
	bool w = (sor > 0);
	
	if ( (w && (scr < sor)) || (!w && (scr < sor))
	) Zoom = (float) ScreenWidth / (float) SourceWidth;
	else Zoom = (float) ScreenHeight / (float) SourceHeight;
}

void ChangeZoom (int de, int x, int y)
{
	if (Fit) FromFit();
	
	int cx = 0, cy = 0;
	
	if (
		x >= 0 && x < ScreenWidth &&
		y >= 0 && y < ScreenHeight
	) {
		cx = x - ScreenWidth / 2;
		cy = y - ScreenHeight / 2;
	}
	
	float mul = de > 0 ? cbrt(2) : 1.0 / cbrt(2);
	
	Zoom *= mul;
	
	X = (X + cx) * mul - cx;
	Y = (Y + cy) * mul - cy;
	
	SourceToScreen();
	ScreenToWindow();
}

void Step (int de)
{
	static int re = 0;
	
	if (re > FileCount) exit(1);
	
	Caret += de;
	
	if (Caret >= FileCount) Caret = 0;
	else if (Caret < 0) Caret = FileCount - 1;
	
	TCHAR cf[MAX_PATH];
	
	wcscpy(cf, Dir);
	wcscat(cf, L"\\");
	wcscat(cf, Files[Caret]);
	
	if (Load(cf))
	{
		re = 0;
		
		Frame = 0;
		ApplyAnimation();
		
		wcscpy(File, Files[Caret]);
		
		SourceToScreen();
		ScreenToWindow();
		
		SetTitle(File);
		
		if (!FullScreen) ShowIcon();
	}
	
	else { re++; Step(de); }
}

void ChangeBack ()
{
	Back++;
	
	if (Back >= (int)sizeof(Backs)) Back = 0;
	
	ApplyBackground();
	SourceToScreen();
	ScreenToWindow();
}

void ChangeSmoothing ()
{
	Smooth = !Smooth;
	SourceToScreen();
	ScreenToWindow();
}

void Pan (int x, int y)
{
	X += x; Y += y;
	
	SourceToScreen();
	ScreenToWindow();
}

void ToggleOnTop ()
{
	OnTop = !OnTop;
	
	if (OnTop) SetWindowPos(WinHandle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE); 
	else SetWindowPos(WinHandle, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE); 
}

LRESULT CALLBACK WndProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int mx = LOWORD(lParam);
	int my = HIWORD(lParam);
	
	int rx = mx - ScreenWidth / 2;
	//int ry = my - ScreenHeight / 2;
	
	bool alt = GetKeyState(VK_MENU) & 0x8000;
	bool ctl = GetKeyState(VK_CONTROL) & 0x8000;
	bool sht = GetKeyState(VK_SHIFT) & 0x8000;
	
	switch (uMsg)
	{
		case WM_RBUTTONUP: {
			if (rx > 0) Step(1);
			else if (rx < 0) Step(-1);
			return 0;
		};
		
		case WM_MBUTTONDOWN: ToggleFit(); return 0;
		case WM_LBUTTONDBLCLK: ToggleFullScreen(); return 0;
		
		case WM_MOUSEWHEEL: {
			POINT c = { mx, my }; ScreenToClient(hWnd, &c); // WM_MOUSEWHEEL sends screen coords
			ChangeZoom(GET_WHEEL_DELTA_WPARAM(wParam) / 120, c.x, c.y);
			return 0;
		}
		
		case WM_MOUSEMOVE:
		{
			if (FullScreen)
			{
				SetShowCursor(true);
				HideCursorDelayed();
			}
			
			static int prex = 0;
			static int prey = 0;
			static int pref = FullScreen;
			
			if (
				pref == FullScreen &&
				!Fit && wParam == MK_LBUTTON
			) Pan(prex - mx, prey - my);
			
			prex = mx;
			prey = my;
			pref = FullScreen;
			
			return 0;
		}
		
		case WM_SYSCHAR:
		{
			switch (wParam)
			{
				case VK_RETURN: FileInfo(Path); break;
			}
			
			return 0;
		}
		
		case WM_KEYDOWN:
		{
			switch (wParam)
			{
				case VK_TAB:
					if (Zoom == 1) X = Y = 0;
					Zoom = 1; ChangeFit(false);
				break;
				
				case VK_UP: if (sht) Pan(0, -8); else ChangeZoom(+1, -1, -1); break;
				case VK_DOWN: if (sht) Pan(0, +8); else ChangeZoom(-1, -1, -1); break;
				case VK_RIGHT: if (sht) Pan(+8, 0); else if (ctl) NextFrame(1); else Step(1); break;
				case VK_LEFT: if (sht) Pan(-8, 0); else if (ctl) NextFrame(-1); else Step(-1); break;
				
				case VK_SPACE: ToggleFit(); break;
				case VK_ESCAPE: PostQuitMessage(0); break;
				
				case 'B': ChangeBack(); break;
				case 'S': ChangeSmoothing(); break;
				case 'A': ToggleAnimation(); break;
				case 'T': ToggleOnTop(); break;
				
				case VK_RETURN:
					if (alt) FileInfo(Path);
					else ToggleFullScreen();
				break;
				
				case VK_DELETE:
					StopAnimation();
					delete Source; Source = 0;
					bool perm = false; if (sht) perm = true;
					Delete(Path, perm); Step(1);
				break;
			}
			
			return 0;
		}
		
		case WM_SIZE:
		{
			RECT cr; GetClientRect(WinHandle, &cr);
			ScreenWidth = cr.right; ScreenHeight = cr.bottom;
			SourceToScreen();
			return 0;
		}
		
		case WM_ERASEBKGND: if (!Blink) return 0; break;
		case WM_PAINT: ScreenToWindow(); return 0;
		case WM_DESTROY: PostQuitMessage(0); return 0;
		
		case WM_TIMER: NextFrame(1); return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
