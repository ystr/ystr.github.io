typedef struct { Xyz Point; Rgb8 Color; } Star;
typedef struct { Thing Thing; Star* Stars; fu16 StarsCount; } Cosmos;


bool RenderCosmos (Thing* t, const Pov* pov, Eye* eye)
{
	Cosmos* g = (Cosmos*) t;
	
	u8 a[3]; SetStarAlphas(a, eye->Expo);
	
	const Rect sclip = Lbrt (
		eye->To->Clip.L + 1, eye->To->Clip.B + 1,
		eye->To->Clip.R - 1, eye->To->Clip.T - 1
	);
	
	for EACH (const Star*, s, g->Stars, g->StarsCount)
	{
		Xyz p = LocProPov(s->Point, pov);
		Xy sp; if (!EyeV2S(&sp, eye, -1, p)) continue;
		DrawStar(eye->To, sp.X, sp.Y, a, s->Color);
	}
	
	return true;
}

bool CollectCosmos (Thing* t, const Pov* pov, Eye* eye)
{
	for (Thing** c = &t->Children; *c && (*c)->Next; c = &(*c)->Next)
	{
		Thing* c0 = *c;
		Thing* c1 = c0->Next;
		
		if (
			Qis(c0->Pos.Loc, pov->Loc) <
			Qis(c1->Pos.Loc, pov->Loc)
		) {
			*c = c1;
			
			c0->Next = c1->Next;
			c1->Next = c0;
		}
	}
	
	return true;
}


void InitFakeCosmos (Cosmos* g, Seed seed)
{
	InitThing(&g->Thing);
	
	g->Thing.Render = RenderCosmos;
	g->Thing.Collect = CollectCosmos;
	
	g->StarsCount = 1024;
	g->Stars = NEW(Star, g->StarsCount);
	
	static const real min = 1 PC;
	static const real max = 10 PC;
	
	for EACH (Star*, s, g->Stars, g->StarsCount)
	{
		real reldis = R0R(RN(&seed));
		s->Point = Spherand(min + reldis * (max - min), &seed);
		u8 bri = 1 + (1 - reldis) * 0x40;
		s->Color = RGB8(bri, bri, bri);
	}
}
