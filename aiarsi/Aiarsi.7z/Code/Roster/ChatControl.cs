using System;
using System.Drawing;
using System.Windows.Forms;

class ChatControl : RosterControl
{
	public readonly Chat Chat;
	
	public readonly new ServerControl Parent;
	RosterKnob watchKnob = new RosterKnob("W", "Watch");
	
	public ChatControl (ServerControl parent, Chat c, string name) : base (name)
	{
		Chat = c;
		Parent = parent;
		Frame[0] = watchKnob;
		
		watchKnob.Clicked += ToggleWatch;
		Chat.WatchChanged += SyncRevealWatch;
		Chat.Log.UnreadChanged += SyncRevealUnread;
		
		RevealUnread();
		RevealWatch();
	}
	
	protected override void Dispose (bool disposing)
	{
		Chat.WatchChanged -= SyncRevealWatch;
		Chat.Log.UnreadChanged -= SyncRevealUnread;
		base.Dispose(disposing);
	}
	
	void ToggleWatch ()
	{
		Chat.Watch = !Chat.Watch;
	}
	
	void SyncRevealWatch () { this.Sync(RevealWatch); }
	void RevealWatch ()
	{
		watchKnob.Checked = Chat.Watch;
	}
	
	void SyncRevealUnread () { this.Sync(RevealUnread); }
	void RevealUnread ()
	{
		FontStyle ts = FontStyle.Regular;
		if (Chat.Log.Unread.Has(Unread.Message)) ts |= FontStyle.Italic;
		if (Chat.Log.Unread.Has(Unread.Important)) ts |= FontStyle.Bold;
		TitleLable.Font = new Font(TitleLable.Font, ts);
	}
	
	public override void Key (KeyEventArgs e) { }
}