using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;


class ToolBar : ToolBase
{
	public readonly Face F;
	public readonly Editor E;
	public readonly Document D;
	
	bool more = false;
	public bool More {
		get { return more; }
		set {
			more = value;
			RevealMore();
			PositionSearch();
			PositionMarks();
			Reveal();
		}
	}
	
	FileMenu fileMenu;
	EditMenu editMenu;
	ViewMenu viewMenu;
	ConfigMenu configMenu;
	AboutMenu aboutMenu;
	MarksMenu marksMenu;
	
	Button saveButton = new Button("S", "Save", "Ctrl S");
	DropButton fileDrop = new DropButton("&File");
	DropButton editDrop = new DropButton("&Edit");
	DropButton viewDrop = new DropButton("&View");
	DropButton configDrop = new DropButton("&Options");
	DropButton aboutDrop = new DropButton("?");
	
	Button markButton = new Button("!", "Mark", "Ctrl Space");
	DropButton marksDrop = new DropButton("&Marks");
	
	Button unescapeButton = new Button(null, "\\", "Ctrl \\", "Unescape");
	Button caseButton = new Button(null, "Aa", "Ctrl [", "Case");
	Button wordsButton = new Button(null, "W", "Ctrl ]", "Words");
	Resizer searchResizer;
	Field searchField = new Field();
	Button searchButton = new Button("F", "Search", "F3");
	Button clearSearchButton = new Button("×", "Clear", "Ctrl Shift F");
	Button moreButton = new Button(null, "R", null, "Show Replace");
	Button lessButton = new Button(null, "-", "Ctrl Shift H", "Hide Replace");
	
	Resizer replaceResizer;
	Field replaceField = new Field();
	Button replaceButton = new Button("Replace");
	
	Menu contextMenu = new Menu();
	Row hideRow = new Row("Hide Toolbar", "F11");
	
	public ToolBar (Face f)
	{
		F = f;
		E = F.E;
		D = F.D;
		
		hideRow.Clicked += () => F.ShowToolbar.Value = false;
		contextMenu.Items.Add(hideRow);
		
		MouseUp += (o, e) =>
		{
			if (e.Button == MouseButtons.Right)
			{
				contextMenu.Show(this, e.X, e.Y);
			}
		};
		
		fileDrop.DropDown = fileMenu = new FileMenu(F);
		editDrop.DropDown = editMenu = new EditMenu(E);
		viewDrop.DropDown = viewMenu = new ViewMenu(F);
		configDrop.DropDown = configMenu = new ConfigMenu(F);
		aboutDrop.DropDown = aboutMenu = new AboutMenu();
		marksDrop.DropDown = marksMenu = new MarksMenu(E);
		
		Items.Add(saveButton);
		Items.Add(fileDrop);
		Items.Add(editDrop);
		Items.Add(viewDrop);
		Items.Add(configDrop);
		Items.Add(aboutDrop);
		
		caseButton.Clicked += () => E.SearchCaseInvariant = !E.SearchCaseInvariant;
		wordsButton.Clicked += () => E.SearchWords = !E.SearchWords;
		unescapeButton.Clicked += () => E.SearchUnescape = !E.SearchUnescape;
		
		#if WIN32
			new Field.Destroyer(searchField);
			new Field.Destroyer(replaceField);
		#endif
		
		searchField.Width = 128;
		searchResizer = new Resizer(searchField);
		searchResizer.Height = searchField.Height;
		
		replaceResizer = new Resizer(replaceField);
		replaceResizer.Height = replaceField.Height;
		
		searchResizer.Minimum = searchField.Height;
		replaceResizer.Minimum = replaceField.Height;
		
		searchResizer.Alignment = moreButton.Alignment =
		caseButton.Alignment = wordsButton.Alignment =
		searchButton.Alignment = clearSearchButton.Alignment =
		replaceButton.Alignment = replaceField.Alignment =
		replaceResizer.Alignment = lessButton.Alignment =
		searchField.Alignment = markButton.Alignment =
		marksDrop.Alignment = unescapeButton.Alignment = ToolStripItemAlignment.Right;
		
		Resize += (o, e) =>
		{
			if (ClientSize.Width == 0) return;
			
			PositionSearch();
			PositionMarks();
		};
		
		searchField.Control.Resize += (o, e) => PositionMarks();
		replaceField.Control.Resize += (o, e) => PositionMarks();
		
		saveButton.Clicked += () => F.Save();
		clearSearchButton.Clicked += () => E.Search = null;
		moreButton.Clicked += () => More = true;
		lessButton.Clicked += () => More = false;
		markButton.Clicked += () => E.ToggleMark();
		
		replaceField.Submitted += Replace;
		replaceButton.Clicked += Replace;
		
		searchField.TextChanged += (o, e) => E.Search = searchField.Text;
		
		searchField.Submitted += () =>
		{
			bool shift = (Control.ModifierKeys & Keys.Shift) == Keys.Shift;
			if (!E.SelectNextFound(shift ? -1 : +1)) SystemSounds.Beep.Play();
		};
		
		searchField.Control.KeyDown += (o, e) =>
		{
			if (e.KeyCode == Keys.Tab)
			{
				e.SuppressKeyPress = true;
				e.Handled = true;
			}
		};
		
		searchButton.Clicked += () =>
		{
			if (!E.SelectNextFound(+1)) SystemSounds.Beep.Play();
		};
		
		Items.Add(replaceButton);
		Items.Add(replaceField);
		Items.Add(replaceResizer);
		Items.Add(moreButton);
		Items.Add(lessButton);
		Items.Add(clearSearchButton);
		Items.Add(searchButton);
		Items.Add(searchField);
		Items.Add(searchResizer);
		Items.Add(unescapeButton);
		Items.Add(wordsButton);
		Items.Add(caseButton);
		Items.Add(marksDrop);
		Items.Add(markButton);
		
		E.ActualSearchChanged += RevealSearch;
		E.ActualSearchChanged += Reveal;
		E.SearchIncrementalChanged += Reveal;
		E.SearchWordsChanged += Reveal;
		E.SearchUnescapeChanged += Reveal;
		E.SearchCaseInvariantChanged += Reveal;
		E.CaretMoved += RevealMarks;
		D.MarksChanged += RevealMarks;
		D.MarksChangedInternally += RevealMarks;
		D.UnsavedChanged += Reveal;
		
		RevealMore();
		RevealMarks();
		RevealSearch();
		Reveal();
	}
	
	protected override bool ProcessCmdKey (ref Message m, Keys k)
	{
		if (
			m.HWnd == searchField.Control.Handle &&
			(k & Keys.KeyCode) == Keys.Tab &&
			(k & Keys.Shift) != Keys.Shift
		) {
			More = true;
			FocusReplace();
			return true;
		}
		
		return base.ProcessCmdKey(ref m, k);
	}
	
	protected override void Dispose (bool disposing)
	{
		E.SearchWordsChanged -= Reveal;
		E.SearchCaseInvariantChanged -= Reveal;
		D.UnsavedChanged -= Reveal;
		E.SearchIncrementalChanged -= Reveal;
		E.SearchUnescapeChanged -= Reveal;
		E.ActualSearchChanged -= RevealSearch;
		E.ActualSearchChanged -= Reveal;
		E.CaretMoved -= RevealMarks;
		D.MarksChanged -= RevealMarks;
		D.MarksChangedInternally -= RevealMarks;
		
		fileMenu.Dispose();
		editMenu.Dispose();
		viewMenu.Dispose();
		configMenu.Dispose();
		aboutMenu.Dispose();
		marksMenu.Dispose();
		contextMenu.Dispose();
		
		base.Dispose(disposing);
	}
	
	void RevealSearch ()
	{
		searchField.Set(E.Search);
	}
	
	void RevealMarks ()
	{
		markButton.Checked = D[E.Caret.Line].Marked;
		marksDrop.Enabled = D.Marks.Count > 0;
	}
	
	void Reveal ()
	{
		SuspendLayout();
		
		saveButton.Enabled = D.Unsaved;
		caseButton.Checked = !E.SearchCaseInvariant;
		wordsButton.Checked = E.SearchWords;
		unescapeButton.Checked = E.SearchUnescape;
		
		searchButton.Visible = !E.SearchIncremental || (E.SearchIncremental && E.Search == null);
		searchButton.Enabled = E.Search != null;
		
		clearSearchButton.Visible = !E.SearchIncremental || (E.SearchIncremental && E.Search != null);
		clearSearchButton.Enabled = E.ActualSearch != null;
		
		replaceButton.Enabled = E.Search != null;
		
		ResumeLayout();
	}
	
	void RevealMore ()
	{
		SuspendLayout();
		
		moreButton.Visible = !more;
		lessButton.Visible = more;
		replaceResizer.Visible = more;
		replaceField.Visible = more;
		replaceButton.Visible = more;
		
		ResumeLayout();
	}
	
	public void FocusSearch ()
	{
		searchField.SelectAll();
		searchField.Focus();
	}
	
	public void FocusReplace ()
	{
		replaceField.SelectAll();
		replaceField.Focus();
	}
	
	public void SearchSelected ()
	{
		if (E.Selected && E.SelectionStart.Line == E.SelectionEnd.Line)
		{
			searchField.Text = E.ExportSelected();
			if (!E.SearchIncremental) E.FindAll();
		}
		
		FocusSearch();
	}
	
	public void ReplaceSelected ()
	{
		More = true;
		
		if (E.Selected && E.SelectionStart.Line == E.SelectionEnd.Line)
		{
			searchField.Text = E.ExportSelected();
			FocusReplace();
		}
		else if (searchField.Focused) FocusReplace();
		else FocusSearch();
	}
	
	void PositionSearch ()
	{
		int free = ClientSize.Width - 16;
		
		free -= saveButton.Width;
		free -= fileDrop.Bounds.Width;
		free -= editDrop.Bounds.Width;
		free -= viewDrop.Bounds.Width;
		free -= configDrop.Bounds.Width;
		free -= aboutDrop.Bounds.Width;
		
		free -= markButton.Bounds.Width;
		free -= marksDrop.Bounds.Width;
		
		free -= caseButton.Bounds.Width;
		free -= wordsButton.Bounds.Width;
		free -= unescapeButton.Bounds.Width;
		free -= searchButton.Bounds.Width;
		free -= searchResizer.Bounds.Width;
		
		if (clearSearchButton.Visible) free -= clearSearchButton.Bounds.Width;
		
		if (more) {
			free -= lessButton.Bounds.Width;
			free -= replaceButton.Bounds.Width;
			free -= replaceResizer.Bounds.Width;
		} else {
			free -= moreButton.Bounds.Width;
		}
		
		if (more) searchResizer.Maximum = replaceResizer.Maximum = free / 2;
		else searchResizer.Maximum = free;
	}
	
	void PositionMarks ()
	{
		int left = aboutDrop.Bounds.Right;
		int right = caseButton.Bounds.Left;
		
		int size = markButton.Bounds.Width + marksDrop.Bounds.Width;
		marksDrop.Margin = new Padding(0, 0, (right - left) / 2 - size / 2, 0);
	}
	
	public new void Focus ()
	{
		base.Focus();
		fileDrop.Select();
	}
	
	void Replace ()
	{
		if (
			searchField.Text == "" || E.Replace (
				searchField.Text, replaceField.Text,
				E.SearchCaseInvariant, E.SearchWords, E.SearchUnescape
			) == 0
		) SystemSounds.Beep.Play();
		else {
			replaceField.Text = "";
			searchField.Text = "";
			E.Focus();
		}
	}
}
