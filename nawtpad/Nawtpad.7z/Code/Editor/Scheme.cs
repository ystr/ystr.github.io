using System;
using System.Collections.Generic;
using System.IO;


class Scheme
{
	static Style style = null;
	static public Action StyleChanged = null;
	static public Style Style
	{
		get { return style; }
		set {
			style = value;
			if (StyleChanged != null) StyleChanged();
		}
	}
	
	public readonly string ID;
	public readonly string Name;
	
	public Scheme (string id)
	{
		ID = id;
		Name = id;
		
		Stream ss = Own.Get("Schemes/" + id + ".scheme");
		if (ss == null) return;
		
		string raw = new StreamReader(ss).ReadToEnd();
		string[] lines = raw.SplitToLines();
		
		Name = lines[0];
		State state = null;
		
		string lineCommentStart = null;
		string lineCommentEnd = null;
		string streamCommentStart = null;
		string streamCommentEnd = null;
		
		foreach (string l in lines)
		{
			string line = l.Trim();
			
			if (line.StartsWith("`")) continue;
			else if (line.StartsWith("[") && line.EndsWith("]"))
			{
				string sid = line.Substring(1, line.Length - 2);
				state = states[sid] = new State();
				
				state.LineCommentStart = lineCommentStart;
				state.LineCommentEnd = lineCommentEnd;
				state.StreamCommentStart = streamCommentStart;
				state.StreamCommentEnd = streamCommentEnd;
			}
			else
			{
				string[] kv = line.Split('=', 2);
				
				if (kv.Length == 2)
				{
					string key = kv[0].Trim();
					string val = kv[1].Trim();
					
					switch (key)
					{
						case "LineComment": {
							LineCommentSupported = true;
							string[] sf = val.Split(' ');
							lineCommentStart = sf[0];
							if (sf.Length > 1) lineCommentEnd = sf[1];
							else lineCommentEnd = null;
						} break;
						
						case "StreamComment": {
							StreamCommentSupported = true;
							string[] sf = val.Split(' ');
							streamCommentStart = sf[0];
							streamCommentEnd = sf[1];
						} break;
						
						case "MatchingBraces": {
							ImportMatchingBraces(val);
						} break;
					}
				}
				
				if (
					state != null &&
					line.Length > 1
				) state.Add(new Condition(line));
			}
		}
	}
	
	#region Parsing
		
		readonly Dictionary<string, State> states = new Dictionary<string, State>();
		
		public void Prepare (Document d)
		{
			foreach (Line l in d) l.PassIn = l.PassOut = null;
			Parse(d, 0);
		}
		
		bool Match (Line line, int ci, string mtch, bool word, bool ignorecase)
		{
			if (word && ci > 0 && line.Meta[ci - 1].IsWordPart) return false;
			
			for (int mi = 0; ci < line.Length; ci++)
			{
				char com = line.Text[ci];
				if (ignorecase) com = char.ToLower(com);
				if (mtch[mi] != com) break;
				
				if (++mi >= mtch.Length)
				{
					if (word && ci + 1 < line.Length && line.Meta[ci + 1].IsWordPart) return false;
					return true;
				}
			}
			
			return false;
		}
		
		void ParseLine (Line line, Pass pass)
		{
			if (!states.ContainsKey(pass.Mode)) return;
			List<Condition> state = states[pass.Mode];
			
			int firstNonSpace = -1;
			
			for (int ci = 0; ci < line.Length;)
			{
				if (firstNonSpace < 0 && !line.Meta[ci].IsSpace)
				{
					firstNonSpace = ci;
				}
				
				foreach (Condition con in state)
				{
					int increment = 1;
					bool match = true;
					
					if (con.IfStrings.Count > 0)
					{
						match = false;
						
						foreach (string ms in con.IfStrings)
						{
							if (Match(line, ci, ms, con.Words, con.IgnoreCase))
							{
								increment = ms.Length;
								match = true; break;
							}
						}
					}
					
					foreach (string sf in con.IfSetFlags)
					{
						if (!pass.Flags.Contains(sf))
						{
							match = false;
							break;
						}
					}
					
					foreach (string nsf in con.IfNotSetFlags)
					{
						if (pass.Flags.Contains(nsf))
						{
							match = false;
							break;
						}
					}
					
					if (con.IfFirst) match &= (ci == 0);
					if (con.IfFirstNonSpace) match &= (firstNonSpace == ci);
					if (con.IfWordPart != null) match &= (con.IfWordPart == line.Meta[ci].IsWordPart);
					if (con.IfSpace != null) match &= (con.IfSpace == line.Meta[ci].IsSpace);
					if (con.IfNumber != null) match &= (con.IfNumber == line.Meta[ci].IsNumber);
					if (con.IfLast) match &= (ci == line.Length - increment);
					
					if (match)
					{
						foreach (string f in con.ThenSetFlags)
							if (!pass.Flags.Contains(f)) pass.Flags.Add(f);
						
						foreach (string f in con.ThenRemoveFlags)
							if (pass.Flags.Contains(f)) pass.Flags.Remove(f);
						
						if (con.ThenStylize != null)
							for (int i = 0; i < increment; i++, ci++)
								line.Meta[ci].Style = style[con.ThenStylize].Index;
						
						if (con.ThenTransfer != null)
							state = states[pass.Mode = con.ThenTransfer];
						
						break;
					}
				}
			}
		}
		
		public void Parse (Document d, int li)
		{
			Pass pass = li > 0 ? new Pass(d[li - 1].PassOut) : new Pass();
			
			for (;;)
			{
				Line line = d[li];
				line.PassIn = new Pass(pass);
				
				ParseLine(line, pass);
				
				line.PassOut = new Pass(pass);
				
				li++; if (li == d.Count) return;
				if (Pass.Equal(d[li].PassIn, pass)) return;
			}
		}
		
	#endregion
	
	#region BraceMatching
		
		readonly Dictionary<char, char> matchForward = new Dictionary<char, char>();
		readonly Dictionary<char, char> matchBack = new Dictionary<char, char>();
		
		void ImportMatchingBraces (string ser)
		{
			matchForward.Clear();
			matchBack.Clear();
			
			foreach (string p in ser.Split(' '))
			{
				if (p.Length != 2) continue;
				
				matchForward[p[0]] = p[1];
				matchBack[p[1]] = p[0];
			}
		}
		
		struct MatchData
		{
			public readonly CharMeta Self;
			public readonly char SelfChar;
			public readonly int Direction;
			public readonly char Match;
			
			public MatchData (char selfChar, CharMeta self, int dir, char match)
			{
				Self = self;
				SelfChar = selfChar;
				Direction = dir;
				Match = match;
			}
		}
		
		MatchData? FindMatch (char c, CharMeta g)
		{
			if (matchForward.ContainsKey(c)) return new MatchData(c, g, +1, matchForward[c]);
			else if (matchBack.ContainsKey(c)) return new MatchData(c, g, -1, matchBack[c]);
			else return null;
		}
		
		public BraceMatch? MatchBrace (Document d, Pos loc)
		{
			MatchData? data = null;
			
			if (d[loc.Line].Length == 0) return null;
			else if (loc.Char == 0) data = FindMatch(d[loc.Line].Text[loc.Char], d[loc.Line].Meta[loc.Char]);
			else if (loc.Char == d[loc.Line].Length) data = FindMatch(d[loc.Line].Text[--loc.Char], d[loc.Line].Meta[loc.Char]);
			else {
				data = FindMatch(d[loc.Line].Text[loc.Char], d[loc.Line].Meta[loc.Char]);
				if (data == null) data = FindMatch(d[loc.Line].Text[--loc.Char], d[loc.Line].Meta[loc.Char]);
			}
			
			if (data == null) return null;
			if (data.Value.Self.Style == style["Comment"].Index) return null;
			
			int li = loc.Line;
			int ci = loc.Char + data.Value.Direction;
			
			int count = 0;
			
			while (true)
			{
				while (ci >= 0 && ci < d[li].Length)
				{
					if (d[li].Meta[ci].Style == data.Value.Self.Style)
					{
						if (d[li].Text[ci] == data.Value.SelfChar) count += 1;
						else if (d[li].Text[ci] == data.Value.Match) {
							if (count > 0) count--;
							else return new BraceMatch(loc, new Pos(li, ci));
						}
					}
					
					ci += data.Value.Direction;
				}
				
				li += data.Value.Direction;
				
				if (data.Value.Direction < 0) {
					if (li < 0) break;
					ci = d[li].Length - 1;
				} else {
					if (li >= d.Count) break;
					ci = 0;
				}
			}
			
			return null;
		}
		
	#endregion
	
	#region Comments
		
		public readonly bool LineCommentSupported = false;
		public readonly bool StreamCommentSupported = false;
		
		public void LineComment (Document d, int lis, int lie)
		{
			bool decided = false;
			bool comment = false;
			
			State ls = states[d[lis].PassIn.Mode];
			
			for (int i = lis; i <= lie; ++i)
			{
				Line line = d[i];
				
				int si = line.FindIndented();
				if (si == -1) continue;
				
				bool scomd = si + ls.LineCommentStart.Length < line.Length
					&& line.Export(si, si + ls.LineCommentStart.Length) == ls.LineCommentStart;
				
				if (!decided) comment = !scomd;
				decided = true;
				
				if (!comment && scomd) d.Remove(new Pos(i, si), new Pos(i, si + ls.LineCommentStart.Length));
				else if (comment && !scomd) d.Insert(new Pos(i, si), ls.LineCommentStart);
				
				if (ls.LineCommentEnd == null) continue;
				int ei = line.Length - ls.LineCommentEnd.Length;
				
				bool ecomd = line.Length > ls.LineCommentEnd.Length
					&& line.Export(ei, line.Length) == ls.LineCommentEnd;
				
				if (!comment && ecomd) d.Remove(new Pos(i, ei), new Pos(i, ei + ls.LineCommentEnd.Length));
				else if (comment && !ecomd) d.Insert(new Pos(i, line.Length), ls.LineCommentEnd);
			}
		}
		
		public Range StreamComment (Document d, Pos s, Pos e)
		{
			Range re = new Range(s, e);
			
			State ls = states[d[s.Line].PassIn.Mode];
			
			re.Start = d.Insert(s, ls.StreamCommentStart);
			re.End.AdjustAfterAddition(s, re.Start);
			d.Insert(re.End, ls.StreamCommentEnd);
			
			return re;
		}
		
	#endregion
	
	#region Associations
		
		public void AssociateWith (Document d)
		{
			SetAssociation(ID, d.FileExtension);
		}
		
		public bool IsAssociatedWith (Document d)
		{
			return assocs.ContainsKey(ID) && assocs[ID].Contains(d.FileExtension);
		}
		
	#endregion
	
	#region Static
		
		static Dictionary<string, Scheme> Cache = new Dictionary<string, Scheme>();
		static Dictionary<string, List<string>> assocs = new Dictionary<string, List<string>>();
		
		public static List<string> ListSchemes ()
		{
			List<string> ids = new List<string>();
			const string schext = ".scheme";
			
			foreach (string file in Own.ListFiles("Schemes"))
				if (file.EndsWith(schext))
					ids.Add(file.Substring(0, file.Length - schext.Length));
			
			return ids;
		}
		
		public static string NameFromID (string id)
		{
			using (StreamReader r = new StreamReader(Own.Get("Schemes/" + id + ".scheme")))
			{
				return r.ReadLine().Trim();
			}
		}
		
		public static string AssocsFromID (string id)
		{
			using (StreamReader r = new StreamReader(Own.Get("Schemes/" + id + ".scheme")))
			{
				r.ReadLine();
				return r.ReadLine().Trim();
			}
		}
		
		public static void ImportAssocs (string pack)
		{
			foreach (string span in pack.Split('\x1E'))
			{
				string[] spl = span.Split('\x1F');
				if (spl.Length < 2) continue;
				
				string scheme = spl[0];
				if (!assocs.ContainsKey(scheme)) continue;
				
				for (int i = 1; i < spl.Length; i++)
				{
					SetAssociation(scheme, spl[i]);
				}
			}
		}
		
		public static string ExportAssocs ()
		{
			List<string> spans = new List<string>();
			
			foreach (KeyValuePair<string, List<string>> kv in assocs)
			{
				List<string> span = new List<string> { kv.Key };
				span.AddRange(kv.Value);
				spans.Add(string.Join("\x1F", span.ToArray()));
			}
			
			return string.Join("\x1E", spans.ToArray());
		}
		
		public static Scheme FromID (string id)
		{
			if (Cache.ContainsKey(id)) return Cache[id];
			else return Cache[id] = new Scheme(id);
		}
		
		public static Scheme Detect (Document d)
		{
			string ext = null;
			if (d.FilePath != null) ext = d.FileExtension;
			
			foreach (KeyValuePair<string, List<string>> ekv in assocs)
			{
				string sid = ekv.Key; List<string> exts = ekv.Value;
				if (exts.IndexOf(ext) != -1) return FromID(ekv.Key);
			}
			
			return FromID("Plain");
		}
		
		static void SetAssociation (string scheme, string ext)
		{
			RemoveExtension(ext);
			assocs[scheme].Add(ext);
		}
		
		static protected void RemoveExtension (string ext)
		{
			foreach (List<string> exts in assocs.Values)
			{
				if (exts.Contains(ext)) exts.Remove(ext);
			}
		}
		
		static Scheme ()
		{
			foreach (string sid in ListSchemes())
			{
				assocs[sid] = new List<string>();
				
				string ass = AssocsFromID(sid);
				if (String.IsNullOrEmpty(ass)) continue;
				
				assocs[sid].AddRange(ass.Split(' '));
			}
		}
		
	#endregion
}