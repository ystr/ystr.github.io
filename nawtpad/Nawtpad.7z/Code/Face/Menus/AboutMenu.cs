using System;
using System.Windows.Forms;

class AboutMenu : Menu
{
	Row helpRow = new Row("&Help", "F1");
	
	public AboutMenu ()
	{
		helpRow.Clicked += Face.Help;
		
		Items.Add(helpRow);
	}
}